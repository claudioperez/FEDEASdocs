
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DeformedElements</div>

--------------------------

# `DeformedElements`


## <a name="_name"></a>Purpose

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELMOPT is a data structure for plotting the deformed shape; it has the fields
       MAGF  = magnification factor of deformed shape (default = 10)
       LnStl = line style           of deformed shape (default = '-')
       LnWth = line width           of deformed shape (default = 1)
       LnClr = line color           of deformed shape (default = 'r' for red)</pre>
<!-- <div class="fragment"><pre class="comment">  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELMOPT is a data structure for plotting the deformed shape; it has the fields
       MAGF  = magnification factor of deformed shape (default = 10)
       LnStl = line style           of deformed shape (default = '-')
       LnWth = line width           of deformed shape (default = 1)
       LnClr = line color           of deformed shape (default = 'r' for red)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm_wDispIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm_wDispIntp</a>	deformed shape of 2d frame element with cubic polynomials</li><li><a href="../../Element_Library/Frame_Elements/DeformShape3dFrm" class="code" title="[XYZd,xyzd] = DeformShape3dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape3dFrm</a>	deformed shape of linear elastic, uniform, prismatic 3d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape3dFrm_wDispIntp" class="code" title="[XYZd,xyzd] = DeformShape3dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape3dFrm_wDispIntp</a>	deformed shape of 3d frame element with cubic polynomials</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvIntp</a>	deformed shape of 2d frame element from curvatures</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvShearIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvShearIntp</a>	deformed shape of 2d Timoshenko frame element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->