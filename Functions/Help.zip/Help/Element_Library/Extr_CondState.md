
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Extr_CondState</div>

--------------------------

# `Extr_CondState`


## <a name="_name"></a>Purpose

Summary of this function goes here


## <a name="_synopsis"></a>Synopsis

`[u,Du,DDu] = Extr_CondState(ElemState,rdof,cdof)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">UNTITLED Summary of this function goes here
   Detailed explanation goes here</pre>
<!-- <div class="fragment"><pre class="comment">UNTITLED Summary of this function goes here
   Detailed explanation goes here</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->