
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Extract_El2MatState</div>

--------------------------

# `Extract_El2MatState`


## <a name="_name"></a>Purpose

extract material state from element state


## <a name="_synopsis"></a>Synopsis

`MatState = Extract_El2MatState (mat,aeps,ElState,rd)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_EL2MATSTATE extract material state from element state
  MATSTATE = EXTRACT_EL2MATSTATE (MAT,AEPS,ELSTATE,RD)
  function extracts from data structure ELSTATE the necessary information
  for the element material, and returns it in data structure MATSTATE;
  it needs compatibility array AEPS to determine material strains from element displacements
  RD identifies the displacement DOFs to extract (default = all)</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_EL2MATSTATE extract material state from element state
  MATSTATE = EXTRACT_EL2MATSTATE (MAT,AEPS,ELSTATE,RD)
  function extracts from data structure ELSTATE the necessary information
  for the element material, and returns it in data structure MATSTATE;
  it needs compatibility array AEPS to determine material strains from element displacements
  RD identifies the displacement DOFs to extract (default = all)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/BeamColPanel" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanel</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/BeamColPanelO" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanelO</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeQuad" class="code" title="ElemResp = Inel4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeReQuad" class="code" title="ElemResp = Inel4to9nodeReQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeReQuad</a>	isoparametric 4-9 node quad element with inelastic material and reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel8nodeBrick" class="code" title="ElemResp = Inel8nodeBrick (action,el_no,xyz,ElemData,ElemState)">Inel8nodeBrick</a>	isoparametric 8 node brick element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelCST" class="code" title="ElemResp = InelCST (action,el_no,xyz,ElemData,ElemState)">InelCST</a>	constant strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Special_Elements/MaterialWrapper" class="code" title="ElemResp = MaterialWrapper (action,el_no,xyz,ElemData,ElemState)">MaterialWrapper</a>	wrapper element that passes on arguments to the material state determination</li><li><a href="../../Element_Library/Special_Elements/PointSDOFElem" class="code" title="ElemResp = PointSDOFElem (action,el_no,xyz,ElemData,ElemState)">PointSDOFElem</a>	POINTSDOFELEM</li><li><a href="../../Element_Library/Special_Elements/ShearBeam" class="code" title="ElemResp = ShearBeam (action,el_no,xyz,ElemData,ElemState)">ShearBeam</a>	POINTSDOFELEM</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->