
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Frame_Elements</a> &gt; Check3dFrmAxes</div>

--------------------------

# `Check3dFrmAxes`


## <a name="_name"></a>Purpose

check that y-axis is not co-linear with element chord


## <a name="_synopsis"></a>Synopsis

`y = Check3dFrmAxes (el,y,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CHECK3dFRMAXES check that y-axis is not co-linear with element chord
  Y = CHECK3dFRMAXES(EL,Y,XYZ)
  the function checks that the specified Y-axis for the element EL 
  with end node coordinates XYZ is not colinear with the element chord;
  if colinearity is detected, the function returns a unit vector in the global
  Y- or Z-axis and issues a warning message with information about the change;
  if not, the function returns the normalized vector Y</pre>
<!-- <div class="fragment"><pre class="comment">CHECK3dFRMAXES check that y-axis is not co-linear with element chord
  Y = CHECK3dFRMAXES(EL,Y,XYZ)
  the function checks that the specified Y-axis for the element EL 
  with end node coordinates XYZ is not colinear with the element chord;
  if colinearity is detected, the function returns a unit vector in the global
  Y- or Z-axis and issues a warning message with information about the change;
  if not, the function returns the normalized vector Y</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwDF" class="code" title="ElemResp = Dinel3dFrm_EBwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwDF</a>	Euler-Bernoulli 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwFF" class="code" title="ElemResp = Dinel3dFrm_EBwFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwFF</a>	3d-frame element with distributed inelasticity (iterative force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwMF" class="code" title="ElemResp = Dinel3dFrm_EBwMF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwMF</a>	3d-frame element with distributed inelasticity (mixed formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwiterMFCL" class="code" title="ElemResp = Dinel3dFrm_EBwiterMFCL (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwiterMFCL</a>	3d-frame element with distributed inelasticity (direct force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF" class="code" title="ElemResp = Dinel3dFrm_TwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF_FLI" class="code" title="ElemResp = Dinel3dFrm_TwDF_FLI (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF_FLI</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwdirDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirFF" class="code" title="ElemResp = Dinel3dFrm_TwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterFF" class="code" title="ElemResp = Dinel3dFrm_TwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE3dFrm" class="code" title="ElemResp = LE3dFrm (action,el_no,xyz,ElemData,ElemState)">LE3dFrm</a>	3d linear frame element under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->