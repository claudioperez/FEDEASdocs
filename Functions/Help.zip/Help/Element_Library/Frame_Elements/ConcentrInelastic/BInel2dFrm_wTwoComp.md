
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; BInel2dFrm_wTwoComp</div>

--------------------------

# `BInel2dFrm_wTwoComp`


## <a name="_name"></a>Purpose

two component 2d frame element (linear + linear-perfectly plastic)


## <a name="_synopsis"></a>Synopsis

`BElemResp = BInel2dFrm_wTwoComp (action,L,BElemData,BElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BINELP2dFRM_WTWOCOMP two component 2d frame element (linear + linear-perfectly plastic)
  BELEMRESP = BINELP2dFRM_WTWOCOMP (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of the two component basic frame element of length L  
  the element exhibits linear elastic axial response and elastic-linear hardening
  flexural response as the sum of two components in parallel:
  a linear elastic + linear-perfectly plastic
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in BELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure BELEMRESP stands for the following data object(s) for each ACTION:
  BELEMRESP = BELEMDATA    for action = 'chec'
  BELEMRESP = BELEMSTATE   for action = 'init'
  BELEMRESP = BELEMSTATE   for action = 'stif'
  BELEMRESP = BELEMSTATE   for action = 'forc'
  BELEMRESP = BELEMPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information; it has the fields
         E  = Young's Modulus
         A  = cross-sectional area
         I  = moment of inertia
         Mp = plastic moment capacity at plastic hinges near ends i, j ( Mp = [Mpi , Mpj] )
         Hr = ratio of linear elastic component to total stiffness (default = 0)
         YFtol = tolerance for yield criterion (default = 1e-12)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are
             vp = plastic element deformations   (3x1 array)</pre>
<!-- <div class="fragment"><pre class="comment">BINELP2dFRM_WTWOCOMP two component 2d frame element (linear + linear-perfectly plastic)
  BELEMRESP = BINELP2dFRM_WTWOCOMP (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of the two component basic frame element of length L  
  the element exhibits linear elastic axial response and elastic-linear hardening
  flexural response as the sum of two components in parallel:
  a linear elastic + linear-perfectly plastic
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in BELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure BELEMRESP stands for the following data object(s) for each ACTION:
  BELEMRESP = BELEMDATA    for action = 'chec'
  BELEMRESP = BELEMSTATE   for action = 'init'
  BELEMRESP = BELEMSTATE   for action = 'stif'
  BELEMRESP = BELEMSTATE   for action = 'forc'
  BELEMRESP = BELEMPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information; it has the fields
         E  = Young's Modulus
         A  = cross-sectional area
         I  = moment of inertia
         Mp = plastic moment capacity at plastic hinges near ends i, j ( Mp = [Mpi , Mpj] )
         Hr = ratio of linear elastic component to total stiffness (default = 0)
         YFtol = tolerance for yield criterion (default = 1e-12)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are
             vp = plastic element deformations   (3x1 array)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->