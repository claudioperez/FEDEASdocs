
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; BasicInel2dFrm_wLHNMYS_wHngOff</div>

--------------------------

# `BasicInel2dFrm_wLHNMYS_wHngOff`


## <a name="_name"></a>Purpose

2d elasto-plastic frame element with basic force interaction (q1-q2-q3)


## <a name="_synopsis"></a>Synopsis

`[q,k,ElemHist,ConvFlag] = BasicInel2dFrm_wLHNMYS_wHngOff (L,ElemData,v,ElemHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BASICINEL2dFRM_wLHNMYS 2d elasto-plastic frame element with basic force interaction (q1-q2-q3)
  [Q,K,ELEMHIST,CONVFLAG] = BASICINEL2dFRM_wLHNMYS (L,ELEMDATA,V,ELEMHIST)
  the function determines the 2d response of an elasto-plastic frame element of length L
  with basic force interaction (q1-q2-q3) according to resultant plasticity theory
  with the same general polynomial yield surface for the interaction of N-M at each end node;
  for given total element deformation V the function determines the corresponding basic
  element force vector Q and tangent stiffness matrix K

  ELEMDATA is a data structure with element property information; it has the fields
         E     = Young's Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Mp    = plastic moment capacity at end nodes i &amp; j ( Mp = [Mpi, Mpj] )
         Np    = plastic axial capacity of element
         GPYSC = coefficients for definining general polynomial yield surface (see below)


  the N-M interaction surface is described by a polynomial that is defined as follows
       f(p,m) = Sum_i (ci*(p^ai)*(m^bi))
      where p = q1/Np;
            m = q2/Mp for node i
              = q3/Mp for node j
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if YSCoeff = [1 2 0; 1 0 2; 3.5 2 2; -1 0 0];
                         f(p,m) = p^2 + m^2 + 3.5*p^2*m^2 - 1
  ELEMHIST is a data structure with element history information; it has two fields
         Past  = element history variables at last converged state
         Pres  = element history variables at current state
         these fields contain the following element history variable(s):
         vp   = plastic element deformation vector</pre>
<!-- <div class="fragment"><pre class="comment">BASICINEL2dFRM_wLHNMYS 2d elasto-plastic frame element with basic force interaction (q1-q2-q3)
  [Q,K,ELEMHIST,CONVFLAG] = BASICINEL2dFRM_wLHNMYS (L,ELEMDATA,V,ELEMHIST)
  the function determines the 2d response of an elasto-plastic frame element of length L
  with basic force interaction (q1-q2-q3) according to resultant plasticity theory
  with the same general polynomial yield surface for the interaction of N-M at each end node;
  for given total element deformation V the function determines the corresponding basic
  element force vector Q and tangent stiffness matrix K

  ELEMDATA is a data structure with element property information; it has the fields
         E     = Young's Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Mp    = plastic moment capacity at end nodes i &amp; j ( Mp = [Mpi, Mpj] )
         Np    = plastic axial capacity of element
         GPYSC = coefficients for definining general polynomial yield surface (see below)


  the N-M interaction surface is described by a polynomial that is defined as follows
       f(p,m) = Sum_i (ci*(p^ai)*(m^bi))
      where p = q1/Np;
            m = q2/Mp for node i
              = q3/Mp for node j
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if YSCoeff = [1 2 0; 1 0 2; 3.5 2 2; -1 0 0];
                         f(p,m) = p^2 + m^2 + 3.5*p^2*m^2 - 1
  ELEMHIST is a data structure with element history information; it has two fields
         Past  = element history variables at last converged state
         Pres  = element history variables at current state
         these fields contain the following element history variable(s):
         vp   = plastic element deformation vector</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../GPYS" class="code" title="[f,g,h] = GPYS (GPYSC,xyz,ScVec)">GPYS</a>	function value, gradient and Hessian of polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Inel2dFrm_wLHNMYS" class="code" title="ElemResp = Inel2dFrm_wLHNMYS (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLHNMYS</a>	2d linear elastic frame element with linear plastic hardening axial-flexure hinges</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->