
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; BasicInel3dFrm_wLHNMYS_wHngOff</div>

--------------------------

# `BasicInel3dFrm_wLHNMYS_wHngOff`


## <a name="_name"></a>Purpose

%


## <a name="_synopsis"></a>Synopsis

`[q,k,ElemHist,ConvFlag] = BasicInel3dFrm_wLHNMYS_wHngOff (L,ElemData,v,ElemHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">%</pre>
<!-- <div class="fragment"><pre class="comment">%</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../GPYS" class="code" title="[f,g,h] = GPYS (GPYSC,xyz,ScVec)">GPYS</a>	function value, gradient and Hessian of polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Inel3dFrm_wLHNMYS" class="code" title="ElemResp = Inel3dFrm_wLHNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wLHNMYS</a>	3d frame element with elastic-linear hardening plastic axial-flexure hinges</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->