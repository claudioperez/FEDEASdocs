
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; Create_PlasticLimitSurface</div>

--------------------------

# `Create_PlasticLimitSurface`


## <a name="_name"></a>Purpose

pologonal plastic limit surface for truss and 2d frame elements


## <a name="_synopsis"></a>Synopsis

`LimitSurf = Create_PlasticLimitSurface (ElemName,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_PLASTICLIMITSURFACE pologonal plastic limit surface for truss and 2d frame elements
  LIMITSURF = CREATE_PLASTLIMSURFACE(ELEMNAME,ELEMDATA)
  the function sets up the polygonal plastic limit surface for the element
  type ELEMNAME (only truss and 2d frame elements supported);
  the polygonal plastic surface depends on the plastic axial capacity NP
  and flexural capacity MP in ELEMDATA;
  LIMITSURF is an array with the plastic capacity values at the polygon corners;
  the field NMOPT of ELEMDATA determines the type of plastic surface;
  the current options are:
    'None' : no interaction between axial and flexural capacity
    'Dmnd' : diamond shaped polygon for plastic limit surface
    'AISC' : 8-sided polygon according to AISC specifications</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_PLASTICLIMITSURFACE pologonal plastic limit surface for truss and 2d frame elements
  LIMITSURF = CREATE_PLASTLIMSURFACE(ELEMNAME,ELEMDATA)
  the function sets up the polygonal plastic limit surface for the element
  type ELEMNAME (only truss and 2d frame elements supported);
  the polygonal plastic surface depends on the plastic axial capacity NP
  and flexural capacity MP in ELEMDATA;
  LIMITSURF is an array with the plastic capacity values at the polygon corners;
  the field NMOPT of ELEMDATA determines the type of plastic surface;
  the current options are:
    'None' : no interaction between axial and flexural capacity
    'Dmnd' : diamond shaped polygon for plastic limit surface
    'AISC' : 8-sided polygon according to AISC specifications</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->