
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; GenBInel2dFrm_wDmg</div>

--------------------------

# `GenBInel2dFrm_wDmg`


## <a name="_name"></a>Purpose

2d elasto-plastic, linear hardening basic frame element with hinge offsets


## <a name="_synopsis"></a>Synopsis

`BElemResp = GenBInel2dFrm_wDmg (action,L,BElemData,BElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BINELP2dFRM_WEPLHM 2d elasto-plastic, linear hardening basic frame element with hinge offsets
  BELEMRESP = BINELP2dFRM_WEPLHM (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of an elasto-plastic basic frame element of length L 
  with linear elastic axial response and elasto-plasic flexural response
  with linear isotropic and kinematic hardening at two plastic hinges
  that may be offset from the element ends (series model)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in BELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure BELEMRESP stands for the following data object(s) for each ACTION:
  BELEMRESP = BELEMDATA    for action = 'chec'
  BELEMRESP = BELEMSTATE   for action = 'init'
  BELEMRESP = BELEMSTATE   for action = 'stif'
  BELEMRESP = BELEMSTATE   for action = 'forc'
  BELEMRESP = BELEMPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information; it has the fields
         E   = Young's Modulus
         A   = cross-sectional area
         I   = moment of inertia
         Mp  = plastic moment capacity at plastic hinges near ends i, j ( Mp = [Mpi , Mpj] )
         Hir = isotropic hardening modulus ratio
         Hkr = kinematic hardening modulus ratio
         HngOff = offset location of plastic hinges as %L (default [0 0])
         w      = uniformly distributed element load [wx;wy];
         YFtol  = yield criterion tolerance (default = 1e-12)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are
             ehp   = plastic hinge   deformations   (2x1 array)
             Mbk   = back forces at flexural hinges (2x1 array)
             alpha = isotropic hardening variable   (2x1 array)</pre>
<!-- <div class="fragment"><pre class="comment">BINELP2dFRM_WEPLHM 2d elasto-plastic, linear hardening basic frame element with hinge offsets
  BELEMRESP = BINELP2dFRM_WEPLHM (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of an elasto-plastic basic frame element of length L 
  with linear elastic axial response and elasto-plasic flexural response
  with linear isotropic and kinematic hardening at two plastic hinges
  that may be offset from the element ends (series model)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in BELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure BELEMRESP stands for the following data object(s) for each ACTION:
  BELEMRESP = BELEMDATA    for action = 'chec'
  BELEMRESP = BELEMSTATE   for action = 'init'
  BELEMRESP = BELEMSTATE   for action = 'stif'
  BELEMRESP = BELEMSTATE   for action = 'forc'
  BELEMRESP = BELEMPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information; it has the fields
         E   = Young's Modulus
         A   = cross-sectional area
         I   = moment of inertia
         Mp  = plastic moment capacity at plastic hinges near ends i, j ( Mp = [Mpi , Mpj] )
         Hir = isotropic hardening modulus ratio
         Hkr = kinematic hardening modulus ratio
         HngOff = offset location of plastic hinges as %L (default [0 0])
         w      = uniformly distributed element load [wx;wy];
         YFtol  = yield criterion tolerance (default = 1e-12)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are
             ehp   = plastic hinge   deformations   (2x1 array)
             Mbk   = back forces at flexural hinges (2x1 array)
             alpha = isotropic hardening variable   (2x1 array)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->