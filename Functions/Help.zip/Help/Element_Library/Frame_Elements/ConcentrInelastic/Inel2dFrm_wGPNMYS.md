
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; Inel2dFrm_wGPNMYS</div>

--------------------------

# `Inel2dFrm_wGPNMYS`


## <a name="_name"></a>Purpose

2d frame element with elastic-plastic hardening axial-flexure hinges


## <a name="_synopsis"></a>Synopsis

`ElemResp = Inel2dFrm_wGPNMYS (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INEL2DFRM_GP 2d frame element with elastic-plastic hardening axial-flexure hinges
  ELEMRESP = INEL2DFRM_wGPNMYS (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of 2d one-component linear elastic frame element with plastic hardening axial-flexure hinges
  following concepts of generalized plasticity for element basic force resultants
  with General Closest Point Project (GCPP) Iteration for the N-M yield surface;
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'defo': report function handle for deformed shape
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = FunHandle   for action = 'defo'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom    = character variable for geometric transformation of node variables
                   (linear, PDelta or corotational) (default=linear)
         rho     = mass density
         A       = cross sectional area
         I       = moment of inertia
         E       = modulus of elasticity
         Np      = plastic axial capacity of element
         Mp      = plastic moment capacity of element
         GPYSC   = polynomial exponents for plastic surface (see help for function GPYS)
         w       = uniform element load ( w(1) = longitudinal, w(2) = transverse )
         JntOff  = rigid joint offsets in global X and Y at element ends;
                   column 1 for node i, column 2 for node j
         HngOff  = offsets of plastic hinge location at element ends ([0;0])
         LdIdx   = load history no for element loading in x-direction
         LdIdy   = load history no for element loading in y-direction
   additional parameters 
         delta   = radius of approaching bounding surface
         beta    = distance from yield surface
         Hir     = isotropic hardening parameter (ratio)
         Hkr     = kinematic hardening parameter (ratio)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMPOST is a data structure with element response information for post-processing in fields
         v     = element deformations
         vp    = plastic deformations
         q     = element basic forces
         fn    = Phi_n from last convergent state
         alfan = isotropic hardening parameter alfa from last convergent state
         an    = kinematic hardening parameter a from last convergent state
         w     = current value of distributed element load</pre>
<!-- <div class="fragment"><pre class="comment">INEL2DFRM_GP 2d frame element with elastic-plastic hardening axial-flexure hinges
  ELEMRESP = INEL2DFRM_wGPNMYS (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of 2d one-component linear elastic frame element with plastic hardening axial-flexure hinges
  following concepts of generalized plasticity for element basic force resultants
  with General Closest Point Project (GCPP) Iteration for the N-M yield surface;
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'defo': report function handle for deformed shape
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = FunHandle   for action = 'defo'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom    = character variable for geometric transformation of node variables
                   (linear, PDelta or corotational) (default=linear)
         rho     = mass density
         A       = cross sectional area
         I       = moment of inertia
         E       = modulus of elasticity
         Np      = plastic axial capacity of element
         Mp      = plastic moment capacity of element
         GPYSC   = polynomial exponents for plastic surface (see help for function GPYS)
         w       = uniform element load ( w(1) = longitudinal, w(2) = transverse )
         JntOff  = rigid joint offsets in global X and Y at element ends;
                   column 1 for node i, column 2 for node j
         HngOff  = offsets of plastic hinge location at element ends ([0;0])
         LdIdx   = load history no for element loading in x-direction
         LdIdy   = load history no for element loading in y-direction
   additional parameters 
         delta   = radius of approaching bounding surface
         beta    = distance from yield surface
         Hir     = isotropic hardening parameter (ratio)
         Hkr     = kinematic hardening parameter (ratio)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMPOST is a data structure with element response information for post-processing in fields
         v     = element deformations
         vp    = plastic deformations
         q     = element basic forces
         fn    = Phi_n from last convergent state
         alfan = isotropic hardening parameter alfa from last convergent state
         an    = kinematic hardening parameter a from last convergent state
         w     = current value of distributed element load</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li><li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../GPYS" class="code" title="[f,g,h] = GPYS (GPYSC,xyz,ScVec)">GPYS</a>	function value, gradient and Hessian of polynomial yield surface</li><li><a href="../../../../Element_Library/Frame_Elements/Mass4Prism2dFrm" class="code" title="ElemMass = Mass4Prism2dFrm (xyz,ElemData)">Mass4Prism2dFrm</a>	consistent mass matrix for prismatic 2d frame element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li><li><a href="../../../../Geometry/kg_2dFrm" class="code" title="kg = kg_2dFrm (option,xyz,u,q)">kg_2dFrm</a>	geometric stiffness matrix for 2-node 2d frame element for different options</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->