
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">ConcentrInelastic</a> &gt; Inel2dFrm_wOneComp_wDmgDo</div>

--------------------------

# `Inel2dFrm_wOneComp_wDmgDo`


## <a name="_name"></a>Purpose

=========================================================================================


## <a name="_synopsis"></a>Synopsis

`ElemResp = Inel2dFrm_wOneComp_wDmgOfs (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">  =========================================================================================
  FEDEASLab - Release 3.1, July 2010
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2010. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  -----------------------------------------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">  =========================================================================================
  FEDEASLab - Release 3.1, July 2010
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2010. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  -----------------------------------------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li><li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../../../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../../../Element_Library/Frame_Elements/Mass4Prism2dFrm" class="code" title="ElemMass = Mass4Prism2dFrm (xyz,ElemData)">Mass4Prism2dFrm</a>	consistent mass matrix for prismatic 2d frame element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li><li><a href="../../../../Geometry/kg_2dFrm" class="code" title="kg = kg_2dFrm (option,xyz,u,q)">kg_2dFrm</a>	geometric stiffness matrix for 2-node 2d frame element for different options</li><li><a href="../../../../Material_Library/DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->