
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Frame_Elements</a> &gt; Damage4Beam</div>

--------------------------

# `Damage4Beam`


## <a name="_name"></a>Purpose




## <a name="_synopsis"></a>Synopsis

`DmgState = Damage4Beam (Data,DmgState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"></pre>
<!-- <div class="fragment"><pre class="comment"></pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Material_Library/DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneComp_wDmgOfs" class="code" title="ElemResp = Inel2dFrm_wOneComp_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneComp_wDmgOfs</a>	one component 2d frame element with rigid-linear hardening end hinges</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_wMDamg" class="code" title="ElemResp = Dinel2dFrm_wMDamg (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_wMDamg</a>	inelastic 2d frame element with damage plasticity for flexure</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->