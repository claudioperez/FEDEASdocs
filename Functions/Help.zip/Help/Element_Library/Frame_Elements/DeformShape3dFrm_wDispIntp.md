
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Frame_Elements</a> &gt; DeformShape3dFrm_wDispIntp</div>

--------------------------

# `DeformShape3dFrm_wDispIntp`


## <a name="_name"></a>Purpose

deformed shape of 3d frame element with cubic polynomials


## <a name="_synopsis"></a>Synopsis

`[XYZd,xyzd] = DeformShape3dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFORMSHAPE3dFRM_wDISPINTP deformed shape of 3d frame element with cubic polynomials
  [XYZd,xyzd] = DEFORMSHAPE3dFRM_wDISPINTP (XYZ,ELEMDATA,U,V,MAGF,NSUB)
  The function returns the global coordinates of the magnified deformed shape
  of a 3d frame element under large end displacements in array XYZd,
  and the local coordinates of the magnified deformed shape in array xyzd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, and the end displacements in vector U.
  Optional arguments are the end deformations V for elements with releases
  or plastic hinges, the magnification factor MAGF (default=10) and the
  number of intermediate points NSUB (default=100) for the deformed shape.
  The function uses Hermite cubic interpolation polynomials for the
  transverse displacements.</pre>
<!-- <div class="fragment"><pre class="comment">DEFORMSHAPE3dFRM_wDISPINTP deformed shape of 3d frame element with cubic polynomials
  [XYZd,xyzd] = DEFORMSHAPE3dFRM_wDISPINTP (XYZ,ELEMDATA,U,V,MAGF,NSUB)
  The function returns the global coordinates of the magnified deformed shape
  of a 3d frame element under large end displacements in array XYZd,
  and the local coordinates of the magnified deformed shape in array xyzd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, and the end displacements in vector U.
  Optional arguments are the end deformations V for elements with releases
  or plastic hinges, the magnification factor MAGF (default=10) and the
  number of intermediate points NSUB (default=100) for the deformed shape.
  The function uses Hermite cubic interpolation polynomials for the
  transverse displacements.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Geometry/DefGeom_3dFrm" class="code" title="[L,T] = DefGeom_3dFrm (xyz,GeomData,u)">DefGeom_3dFrm</a>	determines current length and corotational triad of 2-node, 3d frame element</li><li><a href="../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../Geometry/Large3du2v_Frm" class="code" title="[v,vthetaI,vthetaJ] = Large3du2v_Frm (xyz,GeomData,u)">Large3du2v_Frm</a>	determine 3d frame element deformations from end displacements</li><li><a href="../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/DeformedElements" class="code" title="">DeformedElements</a>	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->