
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; AddessiCiampi</div>

--------------------------

# `AddessiCiampi`


## <a name="_name"></a>Purpose

locations and weights of quadrature integration scheme defined by IntTyp


## <a name="_synopsis"></a>Synopsis

`[xIP,wIP] = AddessiCiampi (nIP,Options)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> ADDESSICIAMPI locations and weights of quadrature integration scheme defined by IntTyp
               with regularization by Addessi &amp; Ciampi 2007
 [XIP,WIP] = ADDESSICIAMPI (NIP)
  function determines the locations in the interval [-1 +1] and the weights
  of the quadrature integration scheme defined by IntTyp for N integration points;
  the regularization method by Addessi &amp; Ciampi 2007 is followed,
  considering the numbers nI and nJ of points in the end parts of the interval [-1 +1];
  the end parts of the interval have lengths so that the end quadrature
  points have weight equal to LcI and LcJ respectively in the interval [0;L] 
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     nI  = no of integration points in the end part close to coordinate -1
     nJ  = no of integration points in the end part close to coordinate +1
     nC  = no of integration points in the central part
     LcI = weight of the point close to coordinate -1 (in [0;L] unit) -
           set equal to 0. if only the LcJ want to be used
     LcJ = weight of the point close to coordinate +1 (in [0;L] unit)
           set equal to 0. if only the LcI want to be used
     L   = total length of the element (in [0;L] unit)
     IntTyp = function name for integration type in each part of the interval (default = Lobatto)</pre>
<!-- <div class="fragment"><pre class="comment"> ADDESSICIAMPI locations and weights of quadrature integration scheme defined by IntTyp
               with regularization by Addessi &amp; Ciampi 2007
 [XIP,WIP] = ADDESSICIAMPI (NIP)
  function determines the locations in the interval [-1 +1] and the weights
  of the quadrature integration scheme defined by IntTyp for N integration points;
  the regularization method by Addessi &amp; Ciampi 2007 is followed,
  considering the numbers nI and nJ of points in the end parts of the interval [-1 +1];
  the end parts of the interval have lengths so that the end quadrature
  points have weight equal to LcI and LcJ respectively in the interval [0;L] 
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     nI  = no of integration points in the end part close to coordinate -1
     nJ  = no of integration points in the end part close to coordinate +1
     nC  = no of integration points in the central part
     LcI = weight of the point close to coordinate -1 (in [0;L] unit) -
           set equal to 0. if only the LcJ want to be used
     LcJ = weight of the point close to coordinate +1 (in [0;L] unit)
           set equal to 0. if only the LcI want to be used
     L   = total length of the element (in [0;L] unit)
     IntTyp = function name for integration type in each part of the interval (default = Lobatto)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->