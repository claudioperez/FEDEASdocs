
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; BDinel2dFrm_wEBwDF</div>

--------------------------

# `BDinel2dFrm_wEBwDF`


## <a name="_name"></a>Purpose

% -------- function BDinel2dFrm_wEBwDF -----------------------------------------------------


## <a name="_synopsis"></a>Synopsis

`BElemResp = BDinel2dFrm_wEBwDF (action,L,BElemData,BElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">% -------- function BDinel2dFrm_wEBwDF -----------------------------------------------------
BDINEL2dFRM_wEBwDF 2d
  BELEMRESP = BDINEL2dFRM_wEBwDF (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of 


  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = BELEMDATA    for action = 'chec'
  ELEMRESP = BELEMSTATE   for action = 'init'
  ELEMRESP = BELEMSTATE   for action = 'stif'
  ELEMRESP = BELEMSTATE   for action = 'forc'

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information
         it has the following fields (default values in parentheses):
                        
         w   = uniform element load ( w(1) = longitudinal, w(2) = transverse ) ( [0;0] )
         HngOff = offsets of plastic hinge location at element ends i, j       ( [0 0] )

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are</pre>
<!-- <div class="fragment"><pre class="comment">% -------- function BDinel2dFrm_wEBwDF -----------------------------------------------------
BDINEL2dFRM_wEBwDF 2d
  BELEMRESP = BDINEL2dFRM_wEBwDF (ACTION,L,BELEMDATA,BELEMSTATE)
  the function determines the 2d response of 


  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report basic element forces
           'stif': report basic element stiffness matrix and basic element forces
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = BELEMDATA    for action = 'chec'
  ELEMRESP = BELEMSTATE   for action = 'init'
  ELEMRESP = BELEMSTATE   for action = 'stif'
  ELEMRESP = BELEMSTATE   for action = 'forc'

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMDATA is a data structure with basic element property information
         it has the following fields (default values in parentheses):
                        
         w   = uniform element load ( w(1) = longitudinal, w(2) = transverse ) ( [0;0] )
         HngOff = offsets of plastic hinge location at element ends i, j       ( [0 0] )

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  BELEMSTATE is a data structure with the current basic element state; it has the fields
         v     = vector of total element deformations
         k     = basic element stiffness matrix; updated under ACTION = 'stif'
         q     = basic element forces; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         the element history variables of this element are</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li><li><a href="../Extract_BasicEl2SecState" class="code" title="SecState = Extract_BasicEl2SecState (sec,ae,ElState)">Extract_BasicEl2SecState</a>	extract section state from basic element state</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->