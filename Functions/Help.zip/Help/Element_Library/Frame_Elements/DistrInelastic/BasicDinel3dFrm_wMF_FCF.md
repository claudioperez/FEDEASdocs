
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; BasicDinel3dFrm_wMF_FCF</div>

--------------------------

# `BasicDinel3dFrm_wMF_FCF`


## <a name="_name"></a>Purpose

of mixed formulation by Chin-Long Lee


## <a name="_synopsis"></a>Synopsis

`[q,f,ElemHist,ConvFlag] = BasicDinel3dFrm_wMF_FCF (ndm,L,ElemData,w,v,DDv,ElemHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> implementation of mixed formulation by Chin-Long Lee</pre>
<!-- <div class="fragment"><pre class="comment"> implementation of mixed formulation by Chin-Long Lee</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Dinel3dFrm_EBwMF" class="code" title="ElemResp = Dinel3dFrm_EBwMF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwMF</a>	3d-frame element with distributed inelasticity (mixed formulation)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->