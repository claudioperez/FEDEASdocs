
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Compute_SecDisp3dFrm_EBwFF</div>

--------------------------

# `Compute_SecDisp3dFrm_EBwFF`


## <a name="_name"></a>Purpose

extract section state from element state for Force Formulation element


## <a name="_synopsis"></a>Synopsis

`u = Compute_SecDisp3dFrm_EBwFF(sec,L,nIP,xIP,ElemPost,ue)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> COMPUTE_SECDISP3dFRM_EBwFF extract section state from element state for Force Formulation element
   u = COMPUTE_SECDISP3dFRM_EBwFF (SEC,NIP,XIP,ELEMPOST,UE)
   function extracts from data structure ELEMSTATE the necessary information
   for computing the section SEC displacement, and returns these displacement in a 6x1 vector U;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</pre>
<!-- <div class="fragment"><pre class="comment"> COMPUTE_SECDISP3dFRM_EBwFF extract section state from element state for Force Formulation element
   u = COMPUTE_SECDISP3dFRM_EBwFF (SEC,NIP,XIP,ELEMPOST,UE)
   function extracts from data structure ELEMSTATE the necessary information
   for computing the section SEC displacement, and returns these displacement in a 6x1 vector U;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->