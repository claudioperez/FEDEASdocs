
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; DebugBasicDinel2dFrm_wFF</div>

--------------------------

# `DebugBasicDinel2dFrm_wFF`


## <a name="_name"></a>Purpose

element properties


## <a name="_synopsis"></a>Synopsis

`[q,f,Debug] = DebugBasicDinel2dFrm_wFF (ndm,L,ElemData,w,DDv,ElemHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> extract element properties</pre>
<!-- <div class="fragment"><pre class="comment"> extract element properties</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../DebugDinel2dFrm" class="code" title="Debug = DebugDinel2dFrm (xyz,ElemData,ElemState,Option)">DebugDinel2dFrm</a>	</li><li><a href="../Dinel2dFrm_EBwFF" class="code" title="ElemResp = Dinel2dFrm_EBwFF (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_EBwFF</a>	2d-frame element with distributed inelasticity (force formulation)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->