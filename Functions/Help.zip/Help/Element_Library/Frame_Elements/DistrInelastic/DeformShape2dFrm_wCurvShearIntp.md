
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; DeformShape2dFrm_wCurvShearIntp</div>

--------------------------

# `DeformShape2dFrm_wCurvShearIntp`


## <a name="_name"></a>Purpose

deformed shape of 2d Timoshenko frame element


## <a name="_synopsis"></a>Synopsis

`[XYd,xyd] = DeformShape2dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFORMSHAPE2dFRM_wCURVSHEARINTP deformed shape of 2d Timoshenko frame element
  DEFORMSHAPE2dFRM_wCURVSHEARINTP (XYZ,ELEMDATA,U,EPOST,MAGF,NSUB)
  The function returns the global coordinates of the magnified deformed shape
  of a 2d frame element under large end displacements in array XYd,
  and the local coordinates of the magnified deformed shape in array xyd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, the end displacements in vector U,
  and the data structure EPOST with information about the curvatures KAPPA along
  the element axis in field Sec{iP}.e(2), and the shear section deformations GAMMA
  along the element axis in field Sec{iP}.e(3).
  Optional arguments are the magnification factor MAGF (default=10)
  and the number of intermediate points NSUB (default=100) for the deformed shape.
  The function determines the transverse displacements by integration of
  the curvatures including the shear section deformations (Timoshenko beam)</pre>
<!-- <div class="fragment"><pre class="comment">DEFORMSHAPE2dFRM_wCURVSHEARINTP deformed shape of 2d Timoshenko frame element
  DEFORMSHAPE2dFRM_wCURVSHEARINTP (XYZ,ELEMDATA,U,EPOST,MAGF,NSUB)
  The function returns the global coordinates of the magnified deformed shape
  of a 2d frame element under large end displacements in array XYd,
  and the local coordinates of the magnified deformed shape in array xyd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, the end displacements in vector U,
  and the data structure EPOST with information about the curvatures KAPPA along
  the element axis in field Sec{iP}.e(2), and the shear section deformations GAMMA
  along the element axis in field Sec{iP}.e(3).
  Optional arguments are the magnification factor MAGF (default=10)
  and the number of intermediate points NSUB (default=100) for the deformed shape.
  The function determines the transverse displacements by integration of
  the curvatures including the shear section deformations (Timoshenko beam)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Geometry/DefGeom_2dFrm" class="code" title="[L,T] = DefGeom_2dFrm (xyz)">DefGeom_2dFrm</a>	determines current length and corotational diad of 2-node, 2d frame element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li><li><a href="../../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/DeformedElements" class="code" title="">DeformedElements</a>	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->