
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Dinel2dFrm_wMFwSecInv</div>

--------------------------

# `Dinel2dFrm_wMFwSecInv`


## <a name="_name"></a>Purpose

DINEL2dFRM_wMFWSECINV


## <a name="_synopsis"></a>Synopsis

`ElemResp = Dinel2dFrm_wMFwSecInv (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DINEL2dFRM_wMFWSECINV 
  ELEMRESP = DINEL2dFRM_wMFWSECINV (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of 2D frame element with distributed
           inelasticity for any type of section and material under linear
           and nonlinear geometry;
           iterative Mixed Formulation with small deformations
           (Add-in Sherman-Morrison-Woodbury formula for updating k w/ singular ks)
           reference:
           Spacone/Filippou/Taucer IJSDEE, Vol.25, No.7, July 1996, pp. 711-725
  
  Built from the template NLiterFF2dFrm_NLG (FEDEASLab - Release 2.6, July 2004)
  Modified by Chin-Long Lee since June 6, 2005
  -----------------------------------------------------------------------------------------
  Add-in Sherman-Morrison formula to calculate                                 June 6, 2005
    element stiffness k with singular section stiffnesses ks
    Changes:
      1. storing ks instead of fs (since fs does not exist for singular
         ks).
      2. change original DDv0 to DDvp for consistency, DDv0 is used in
         another place if necessary
      3. store sp instead of calculate it in every iteration

  Implement formulations derived since June 9, 2005                           June 17, 2005
  Continue Implementation                                                     June 19, 2005
  Continue Implementation                                                     June 20, 2005
    Rename and remove some parameters
      1. no more DDvp, DDep, DDsp, etc, but using vr0 and su concept
  Change the tolerance criteria                                               June 22, 2005
    so that the increment DDe is run at least once.
  Reprogram the qv function                                                 August 15, 2005
    for removal of some bugs
  Use Eigendecomposition instead of SVD                                  September 27, 2005
    SVD is incorrect for softening stiffness as it
    only provides +ve singular values.
  Revise the criteria of convergence check based on                       November 21, 2005
    well defined energy norm
  Instead of the Sherman-Morrison formula, use the                        February 17, 2006
    Sherman-Morrison-Woodbury formula to calculate  
    element stiffness k with singular section stiffnesses ks
    in progress...
  Rewrite it for mixed-formulation developed in                           February 20, 2006
    my CE299 report
    store only q and e for state variable, the element and
    section stiffness are calculated instead.
    rename u (vector) to Z (vectors), s-scalar to L (diag matrix)
    rename ubar (vector) to Zb (vectors), sbar-scalar to Lb (diag matrix)
    Try grouping small matrices into big matrices to avoid for loop
  Finalization ...                                                        February 26, 2006
  Revise name for CE221 S06 (not to be disclosed)                            March 20, 2006
  Fixing bifurcation...                                                      March 24, 2006
    Testing pseudoinverse...
  If Cb is singular, use the SM formula for update k one                     March 25, 2006
    rank by one rank
  Implement pseudoinverse for bifurcation...                                 March 30, 2006
  Rename from NLiterMFwSMW2DFrm_qv to NL2dFrm_iterMixFormSMW_qv                  2006/06/04
    Use weighted sum for calculating the energy norm for convergence check.
    This program is implemented for FEDEASLab 2.6 dated 2005/03/25
    so ndm and 'stif' are needed when passing the arguments to section
  Renamed from NL2dFrm_iterMixFormSMW_qv to NL2dFrm_iterMixFormSMWEP_qv          2006/09/17
    A new q-v function that has elastic-plastic split in the section stiffness to 
    remove the possible singularity of fo
    It is referred as the second algorithm in the current writing.
    The original algorithm is referred as the first algorithm.
    Scale zbar and sdbar with sqrt(w) to resolve oscillation due to weight effect
    in lambda.
  Remove the check iteration if already converge                                 2006/09/19
    make convswitch unnecessary.
  Eigendecomposition is done for ksp instead of fsp (it is conceptually wrong)   2007/05/28
  Rename from NL2dFrm_iterMixFormSMWEP_qv to NL2dFrm_iterMixFormSecInv_qv        2007/09/06
    To make this qv file for both with and without elastic-plastic split
    Fix the calculation of DDW and make consistent with paper for all symbols
    Do with any number of independent variable for section deformations and 
    element forces (can include more than axial strain and curvature)
    Tidy the program for better understanding
  Tidied by Prof. Filippou for FEDEASLab v2.7                                    2008/01
  Removed Su_tol that is used to check Su                                        2008/01/24
  Algorithm is rewritten to combine iterative and non-iterative versions such    2009/08/03
    that both versions are controlled by Wtol
    (template: Beam3dSlip10bar_FFSpline.m)
    renamed as Dinel2dFrm_wMFwSecInv.m, &amp; qvbistep procedure is skipped.
  -----------------------------------------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">DINEL2dFRM_wMFWSECINV 
  ELEMRESP = DINEL2dFRM_wMFWSECINV (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of 2D frame element with distributed
           inelasticity for any type of section and material under linear
           and nonlinear geometry;
           iterative Mixed Formulation with small deformations
           (Add-in Sherman-Morrison-Woodbury formula for updating k w/ singular ks)
           reference:
           Spacone/Filippou/Taucer IJSDEE, Vol.25, No.7, July 1996, pp. 711-725
  
  Built from the template NLiterFF2dFrm_NLG (FEDEASLab - Release 2.6, July 2004)
  Modified by Chin-Long Lee since June 6, 2005
  -----------------------------------------------------------------------------------------
  Add-in Sherman-Morrison formula to calculate                                 June 6, 2005
    element stiffness k with singular section stiffnesses ks
    Changes:
      1. storing ks instead of fs (since fs does not exist for singular
         ks).
      2. change original DDv0 to DDvp for consistency, DDv0 is used in
         another place if necessary
      3. store sp instead of calculate it in every iteration

  Implement formulations derived since June 9, 2005                           June 17, 2005
  Continue Implementation                                                     June 19, 2005
  Continue Implementation                                                     June 20, 2005
    Rename and remove some parameters
      1. no more DDvp, DDep, DDsp, etc, but using vr0 and su concept
  Change the tolerance criteria                                               June 22, 2005
    so that the increment DDe is run at least once.
  Reprogram the qv function                                                 August 15, 2005
    for removal of some bugs
  Use Eigendecomposition instead of SVD                                  September 27, 2005
    SVD is incorrect for softening stiffness as it
    only provides +ve singular values.
  Revise the criteria of convergence check based on                       November 21, 2005
    well defined energy norm
  Instead of the Sherman-Morrison formula, use the                        February 17, 2006
    Sherman-Morrison-Woodbury formula to calculate  
    element stiffness k with singular section stiffnesses ks
    in progress...
  Rewrite it for mixed-formulation developed in                           February 20, 2006
    my CE299 report
    store only q and e for state variable, the element and
    section stiffness are calculated instead.
    rename u (vector) to Z (vectors), s-scalar to L (diag matrix)
    rename ubar (vector) to Zb (vectors), sbar-scalar to Lb (diag matrix)
    Try grouping small matrices into big matrices to avoid for loop
  Finalization ...                                                        February 26, 2006
  Revise name for CE221 S06 (not to be disclosed)                            March 20, 2006
  Fixing bifurcation...                                                      March 24, 2006
    Testing pseudoinverse...
  If Cb is singular, use the SM formula for update k one                     March 25, 2006
    rank by one rank
  Implement pseudoinverse for bifurcation...                                 March 30, 2006
  Rename from NLiterMFwSMW2DFrm_qv to NL2dFrm_iterMixFormSMW_qv                  2006/06/04
    Use weighted sum for calculating the energy norm for convergence check.
    This program is implemented for FEDEASLab 2.6 dated 2005/03/25
    so ndm and 'stif' are needed when passing the arguments to section
  Renamed from NL2dFrm_iterMixFormSMW_qv to NL2dFrm_iterMixFormSMWEP_qv          2006/09/17
    A new q-v function that has elastic-plastic split in the section stiffness to 
    remove the possible singularity of fo
    It is referred as the second algorithm in the current writing.
    The original algorithm is referred as the first algorithm.
    Scale zbar and sdbar with sqrt(w) to resolve oscillation due to weight effect
    in lambda.
  Remove the check iteration if already converge                                 2006/09/19
    make convswitch unnecessary.
  Eigendecomposition is done for ksp instead of fsp (it is conceptually wrong)   2007/05/28
  Rename from NL2dFrm_iterMixFormSMWEP_qv to NL2dFrm_iterMixFormSecInv_qv        2007/09/06
    To make this qv file for both with and without elastic-plastic split
    Fix the calculation of DDW and make consistent with paper for all symbols
    Do with any number of independent variable for section deformations and 
    element forces (can include more than axial strain and curvature)
    Tidy the program for better understanding
  Tidied by Prof. Filippou for FEDEASLab v2.7                                    2008/01
  Removed Su_tol that is used to check Su                                        2008/01/24
  Algorithm is rewritten to combine iterative and non-iterative versions such    2009/08/03
    that both versions are controlled by Wtol
    (template: Beam3dSlip10bar_FFSpline.m)
    renamed as Dinel2dFrm_wMFwSecInv.m, &amp; qvbistep procedure is skipped.
  -----------------------------------------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li><li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li><li><a href="../../../../Geometry/kg_2dFrm" class="code" title="kg = kg_2dFrm (option,xyz,u,q)">kg_2dFrm</a>	geometric stiffness matrix for 2-node 2d frame element for different options</li><li><a href="../../../../Utilities/Interpolation/Lagrange" class="code" title="lp = Lagrange (degree,deriv,xi)">Lagrange</a>	Lagrange interpolation polynomials in interval -1<xi<1</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->