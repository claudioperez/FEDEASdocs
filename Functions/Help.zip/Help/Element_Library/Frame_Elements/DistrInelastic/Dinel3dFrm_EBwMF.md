
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Dinel3dFrm_EBwMF</div>

--------------------------

# `Dinel3dFrm_EBwMF`


## <a name="_name"></a>Purpose

3d-frame element with distributed inelasticity (mixed formulation)


## <a name="_synopsis"></a>Synopsis

`ElemResp = Dinel3dFrm_EBwMF (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DINEL3dFRM_EBwMF 3d-frame element with distributed inelasticity (mixed formulation)
  ELEMRESP = DINEL3dFRM_EBwMF (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of 3d frame element with distributed inelasticity for any
           type of section and material under linear and nonlinear geometry;
           mixed three-field formulation with small deformations
           reference: Taylor/Filippou/Saritas/Auriccchio, SEMM Report 2002-12
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'defo': report function handle for deformed shape
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = FunHandle   for action = 'defo'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ  is an Boolean array of size NDF x NEN,
        where NDF = number of DOFs/node, NEN = number of nodes,
        with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
        Geom    = character variable for geometric transformation of node variables
                  (linear, PDelta or corotational) (default=linear)
        w       = uniform element loads
        JntOff  = rigid joint offsets in global X and Y at element ends;
                  column 1 for node i, column 2 for node j
        nIP     = number of integration points
        IntTyp  = function name for element integration
        Tol     = incremental work tolerance for state convergence (1e-16)
        MaxIter = maximum number of iterations for state convergence (15)
        SubDivNo= number of element deformation subdivisions (5)
        SecName = function name for section s-e response
        SecData{i} = section property data at integration point i (see function with SecName)
        LdIdx   = load history no for element loading in x-direction
        LdIdy   = load history no for element loading in y-direction
        LdIdz   = load history no for element loading in z-direction
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
        u     = vector of total element displacements in global reference
        Du    = vector of element displacement increments from last convergence
        DDu   = vector of element displacement increments from last iteration
        ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
        p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
        Past  = element history variables at last converged state
        Pres  = current element history variables
        lamda = row vector of current load factor(s)
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMPOST is a data structure with element response information for post-processing in fields
        v     = element deformations
        q     = element basic forces
        Sec{i}= section response information at integration point i (see function with SecName)</pre>
<!-- <div class="fragment"><pre class="comment">DINEL3dFRM_EBwMF 3d-frame element with distributed inelasticity (mixed formulation)
  ELEMRESP = DINEL3dFRM_EBwMF (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of 3d frame element with distributed inelasticity for any
           type of section and material under linear and nonlinear geometry;
           mixed three-field formulation with small deformations
           reference: Taylor/Filippou/Saritas/Auriccchio, SEMM Report 2002-12
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'defo': report function handle for deformed shape
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = FunHandle   for action = 'defo'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ  is an Boolean array of size NDF x NEN,
        where NDF = number of DOFs/node, NEN = number of nodes,
        with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
        Geom    = character variable for geometric transformation of node variables
                  (linear, PDelta or corotational) (default=linear)
        w       = uniform element loads
        JntOff  = rigid joint offsets in global X and Y at element ends;
                  column 1 for node i, column 2 for node j
        nIP     = number of integration points
        IntTyp  = function name for element integration
        Tol     = incremental work tolerance for state convergence (1e-16)
        MaxIter = maximum number of iterations for state convergence (15)
        SubDivNo= number of element deformation subdivisions (5)
        SecName = function name for section s-e response
        SecData{i} = section property data at integration point i (see function with SecName)
        LdIdx   = load history no for element loading in x-direction
        LdIdy   = load history no for element loading in y-direction
        LdIdz   = load history no for element loading in z-direction
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
        u     = vector of total element displacements in global reference
        Du    = vector of element displacement increments from last convergence
        DDu   = vector of element displacement increments from last iteration
        ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
        p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
        Past  = element history variables at last converged state
        Pres  = current element history variables
        lamda = row vector of current load factor(s)
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMPOST is a data structure with element response information for post-processing in fields
        v     = element deformations
        q     = element basic forces
        Sec{i}= section response information at integration point i (see function with SecName)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ElementLoading" class="code" title="wC = ElementLoading (w0,lamda,LdId)">ElementLoading</a>	determines current distributed element load value</li><li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../../../../Element_Library/Frame_Elements/Check3dFrmAxes" class="code" title="y = Check3dFrmAxes (el,y,xyz)">Check3dFrmAxes</a>	check that y-axis is not co-linear with element chord</li><li><a href="../BasicDinel3dFrm_wMF_FCF" class="code" title="[q,f,ElemHist,ConvFlag] = BasicDinel3dFrm_wMF_FCF (ndm,L,ElemData,w,v,DDv,ElemHist)">BasicDinel3dFrm_wMF_FCF</a>	of mixed formulation by Chin-Long Lee</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/GeomTran_3dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_3dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_3dFrm</a>	kinematic matrices and deformations for a 2-node 3d frame element</li><li><a href="../../../../Geometry/kg_3dFrm" class="code" title="kg = kg_3dFrm (option,xyz,GeomData,u,q,ElLoad)">kg_3dFrm</a>	geometric stiffness matrix for 2-node 3d frame element different options</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->