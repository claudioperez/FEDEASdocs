
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; DinelBasicEB3dFrm_wMF</div>

--------------------------

# `DinelBasicEB3dFrm_wMF`


## <a name="_name"></a>Purpose

stiffness matrix and resisting forces in basic system


## <a name="_synopsis"></a>Synopsis

`[q,k,ElemHist,ConvFlag] = DinelBasicEB3dFrm_wMF (ndm,L,ElemData,w,v,ElemHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> determine stiffness matrix and resisting forces in basic system</pre>
<!-- <div class="fragment"><pre class="comment"> determine stiffness matrix and resisting forces in basic system</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->