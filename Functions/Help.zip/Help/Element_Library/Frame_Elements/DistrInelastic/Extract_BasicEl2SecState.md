
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Extract_BasicEl2SecState</div>

--------------------------

# `Extract_BasicEl2SecState`


## <a name="_name"></a>Purpose

extract section state from basic element state


## <a name="_synopsis"></a>Synopsis

`SecState = Extract_BasicEl2SecState (sec,ae,ElState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_BASICEL2SECSTATE extract section state from basic element state
  SECSTATE = EXTRACT_BASICEL2SECSTATE (SEC,AE,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for section SEC, and returns it in data structure SECSTATE;
  it needs compatibility array AE to determine section from element deformations</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_BASICEL2SECSTATE extract section state from basic element state
  SECSTATE = EXTRACT_BASICEL2SECSTATE (SEC,AE,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for section SEC, and returns it in data structure SECSTATE;
  it needs compatibility array AE to determine section from element deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../BDinel2dFrm_wEBwDF" class="code" title="BElemResp = BDinel2dFrm_wEBwDF (action,L,BElemData,BElemState)">BDinel2dFrm_wEBwDF</a>	% -------- function BDinel2dFrm_wEBwDF -----------------------------------------------------</li><li><a href="../Dinel2dFrm_EBwDF" class="code" title="ElemResp = Dinel2dFrm_EBwDF (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_EBwDF</a>	2d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel2dFrm_TwDF" class="code" title="ElemResp = Dinel2dFrm_TwDF (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_TwDF</a>	Timoshenko 2d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel3dFrm_EBwDF" class="code" title="ElemResp = Dinel3dFrm_EBwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwDF</a>	Euler-Bernoulli 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel3dFrm_TwDF" class="code" title="ElemResp = Dinel3dFrm_TwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel3dFrm_TwDF_FLI" class="code" title="ElemResp = Dinel3dFrm_TwDF_FLI (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF_FLI</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel3dFrm_TwdirDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwdirDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../../../Element_Library/Special_Elements/PointHinge" class="code" title="ElemResp = PointHinge (action,el_no,xyz,ElemData,ElemState)">PointHinge</a>	2d/3d plastic hinge element with ndm deformation modes for any section and material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->