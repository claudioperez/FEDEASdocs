
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Extract_El2SecDispFF_T3D</div>

--------------------------

# `Extract_El2SecDispFF_T3D`


## <a name="_name"></a>Purpose

extract section state from element state for Force Formulation element


## <a name="_synopsis"></a>Synopsis

`u = Extract_El2SecDispFF_T3D(sec,L,nIP,xIP,wIP,ElemPost,ue)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> EXTRACT_EL2SECDISPFF extract section state from element state for Force Formulation element
   u = EXTRACT_EL2SECDISPFF (SEC,NIP,XIP,WIP,ELEMPOST,UE)
   function extracts from data structure ELEMSTATE the necessary information
   for computing the section SEC displacement, and returns these displacement in a 6x1 vector U;</pre>
<!-- <div class="fragment"><pre class="comment"> EXTRACT_EL2SECDISPFF extract section state from element state for Force Formulation element
   u = EXTRACT_EL2SECDISPFF (SEC,NIP,XIP,WIP,ELEMPOST,UE)
   function extracts from data structure ELEMSTATE the necessary information
   for computing the section SEC displacement, and returns these displacement in a 6x1 vector U;</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Interpolation/lagrangepoly" class="code" title="[P,R,S] = lagrangepoly(X,Y,XX)">lagrangepoly</a>	 Lagrange interpolation polynomial fitting a set of points</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->