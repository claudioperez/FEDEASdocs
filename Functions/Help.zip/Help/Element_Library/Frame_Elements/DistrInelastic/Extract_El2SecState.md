
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Extract_El2SecState</div>

--------------------------

# `Extract_El2SecState`


## <a name="_name"></a>Purpose

extract section state from element state


## <a name="_synopsis"></a>Synopsis

`SecState = Extract_El2SecState (sec,ae,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_EL2SECSTATE extract section state from element state
  SECSTATE = EXTRACT_EL2SECSTATE (SEC,AE,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for section SEC, and returns it in data structure SECSTATE;
  it needs compatibility array AE to determine section from element deformations</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_EL2SECSTATE extract section state from element state
  SECSTATE = EXTRACT_EL2SECSTATE (SEC,AE,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for section SEC, and returns it in data structure SECSTATE;
  it needs compatibility array AE to determine section from element deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/Special_Elements/SectionWrapper" class="code" title="ElemResp = SectionWrapper (action,el_no,xyz,ElemData,ElemState)">SectionWrapper</a>	wrapper element that passes on arguments to the section state determination</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->