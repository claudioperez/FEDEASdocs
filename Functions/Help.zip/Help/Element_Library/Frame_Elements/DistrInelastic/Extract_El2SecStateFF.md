
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Extract_El2SecStateFF</div>

--------------------------

# `Extract_El2SecStateFF`


## <a name="_name"></a>Purpose

extract section state from element state for Force Formulation element


## <a name="_synopsis"></a>Synopsis

`SecState = Extract_El2SecStateFF (sec,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> EXTRACT_EL2SECSTATEFF extract section state from element state for Force Formulation element
   SECSTATE = EXTRACT_EL2SECSTATEFF (SEC,ELEMSTATE)
   function extracts from data structure ELEMSTATE the necessary information
   for section SEC, and returns it in data structure SECSTATE;</pre>
<!-- <div class="fragment"><pre class="comment"> EXTRACT_EL2SECSTATEFF extract section state from element state for Force Formulation element
   SECSTATE = EXTRACT_EL2SECSTATEFF (SEC,ELEMSTATE)
   function extracts from data structure ELEMSTATE the necessary information
   for section SEC, and returns it in data structure SECSTATE;</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../Dinel3dFrm_TwdirFF" class="code" title="ElemResp = Dinel3dFrm_TwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../Dinel3dFrm_TwiterFF" class="code" title="ElemResp = Dinel3dFrm_TwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->