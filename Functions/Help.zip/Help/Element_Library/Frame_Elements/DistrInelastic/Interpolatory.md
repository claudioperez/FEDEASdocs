
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Interpolatory</div>

--------------------------

# `Interpolatory`


## <a name="_name"></a>Purpose

locations and weights of interpolatory quadrature integration scheme


## <a name="_synopsis"></a>Synopsis

`[xIP,wIP] = Interpolatory (nIP)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> INTERPOLATORY locations and weights of interpolatory quadrature integration scheme
               (Scott 2008)
 [XIP,WIP] = INTERPOLATORY (NIP)
  function determines the locations in the interval [-1;+1] and the weights
  of the interpolatory quadrature integration scheme for N integration points;
  the regularization method is computed, considering the numbers n of points in the interval [-1;+1];
  the end quadrature points have weight equal to LcI and LcJ respectively in the interval [0;L]
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     n   = no of integration points in the element
     LcI = weight of the point close to coordinate -1 (in [0;L] unit)
     LcI = weight of the point close to coordinate +1 (in [0;L] unit)
     L   = total length of the element (in [0;L] unit)</pre>
<!-- <div class="fragment"><pre class="comment"> INTERPOLATORY locations and weights of interpolatory quadrature integration scheme
               (Scott 2008)
 [XIP,WIP] = INTERPOLATORY (NIP)
  function determines the locations in the interval [-1;+1] and the weights
  of the interpolatory quadrature integration scheme for N integration points;
  the regularization method is computed, considering the numbers n of points in the interval [-1;+1];
  the end quadrature points have weight equal to LcI and LcJ respectively in the interval [0;L]
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     n   = no of integration points in the element
     LcI = weight of the point close to coordinate -1 (in [0;L] unit)
     LcI = weight of the point close to coordinate +1 (in [0;L] unit)
     L   = total length of the element (in [0;L] unit)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Quadrature/Lobatto" class="code" title="[xIP,wIP] = Lobatto (nIP)">Lobatto</a>	locations and weights of Gauss-Lobatto integration scheme</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->