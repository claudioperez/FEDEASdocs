
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Mass4Taper2dFrm_wDF</div>

--------------------------

# `Mass4Taper2dFrm_wDF`


## <a name="_name"></a>Purpose

consistent mass matrix for tapered 2d frame element with displ interpolation


## <a name="_synopsis"></a>Synopsis

`ElemMass = Mass4Taper2dFrm_wDF (xyz,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MASS4TAPER2dFRM_wDF consistent mass matrix for tapered 2d frame element with displ interpolation</pre>
<!-- <div class="fragment"><pre class="comment">MASS4TAPER2dFRM_wDF consistent mass matrix for tapered 2d frame element with displ interpolation</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Utilities/Interpolation/Hermite" class="code" title="hp = Hermite (degree,deriv,xi)">Hermite</a>	Hermite interpolation polynomials in interval -1<xi<1</li><li><a href="../../../../Utilities/Interpolation/Lagrange" class="code" title="lp = Lagrange (degree,deriv,xi)">Lagrange</a>	Lagrange interpolation polynomials in interval -1<xi<1</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wVarIDF" class="code" title="ElemResp = LE2dFrm_wVarIDF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wVarIDF</a>	2d LE frame element with variable cross section under linear or NL geometry</li><li><a href="../../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wVarIFF" class="code" title="ElemResp = LE2dFrm_wVarIFF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wVarIFF</a>	2d LE frame element with variable cross section under linear or NL geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->