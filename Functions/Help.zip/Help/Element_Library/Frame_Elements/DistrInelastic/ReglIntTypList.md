
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; ReglIntTypList</div>

--------------------------

# `ReglIntTypList`


## <a name="_name"></a>Purpose

ReglIntTypList()


## <a name="_synopsis"></a>Synopsis

`ReglList = ReglIntTypList()`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> ReglIntTypList()

 Provide the list REGLLIST of all the integration types that can be
 used for the regularization of force based elements, and that need to
 have the length of the element L as a field of the structure nIP
 (together with the number n of the quadrature points)</pre>
<!-- <div class="fragment"><pre class="comment"> ReglIntTypList()

 Provide the list REGLLIST of all the integration types that can be
 used for the regularization of force based elements, and that need to
 have the length of the element L as a field of the structure nIP
 (together with the number n of the quadrature points)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../Dinel3dFrm_TwdirFF" class="code" title="ElemResp = Dinel3dFrm_TwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../Dinel3dFrm_TwiterFF" class="code" title="ElemResp = Dinel3dFrm_TwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../WarpShpFun4Elem" class="code" title="[xWP,Nwx,DNwx] = WarpShpFun4Elem (ElemData)">WarpShpFun4Elem</a>	computes the 1d shape functions for section with warping</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->