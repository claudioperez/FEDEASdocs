
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; Scott</div>

--------------------------

# `Scott`


## <a name="_name"></a>Purpose

locations and weights of Gauss-Lobatto integration scheme


## <a name="_synopsis"></a>Synopsis

`[xIP,wIP] = Scott (nIP)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> SCOTT locations and weights of Gauss-Lobatto integration scheme
               with regularization by Scott 2008
 [XIP,WIP] = SCOTT (NIP)
  function determines the locations in the interval [-1 +1] and the weights
  of the Gauss-Lobatto integration scheme for N integration points;
  the regularization method by Scott 2008 is followed, considering the numbers
  n of points in the interval [-1 +1] and the distances dxI and dxJ of the
  2 added points from the respective ends of the interval;
  the end quadrature points have weight equal to LcI and LcJ respectively in the interval [0;L]
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     n   = no of integration points in the element (except the 2 added)
     LcI = weight of the point close to coordinate -1 (in [0 L] unit)
     LcI = weight of the point close to coordinate +1 (in [0 L] unit)
     L   = total length of the element (in [0 L] unit)
     dxI = distance of first  added point from the coordinate -1 (in [0;L] unit)
     dxJ = distance of second added point from the coordinate +1 (in [0;L] unit)</pre>
<!-- <div class="fragment"><pre class="comment"> SCOTT locations and weights of Gauss-Lobatto integration scheme
               with regularization by Scott 2008
 [XIP,WIP] = SCOTT (NIP)
  function determines the locations in the interval [-1 +1] and the weights
  of the Gauss-Lobatto integration scheme for N integration points;
  the regularization method by Scott 2008 is followed, considering the numbers
  n of points in the interval [-1 +1] and the distances dxI and dxJ of the
  2 added points from the respective ends of the interval;
  the end quadrature points have weight equal to LcI and LcJ respectively in the interval [0;L]
  the locations are reported in vector XIP and the weights in vector WIP
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  nIP is a data structure containing:
     n   = no of integration points in the element (except the 2 added)
     LcI = weight of the point close to coordinate -1 (in [0 L] unit)
     LcI = weight of the point close to coordinate +1 (in [0 L] unit)
     L   = total length of the element (in [0 L] unit)
     dxI = distance of first  added point from the coordinate -1 (in [0;L] unit)
     dxJ = distance of second added point from the coordinate +1 (in [0;L] unit)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Quadrature/Lobatto" class="code" title="[xIP,wIP] = Lobatto (nIP)">Lobatto</a>	locations and weights of Gauss-Lobatto integration scheme</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->