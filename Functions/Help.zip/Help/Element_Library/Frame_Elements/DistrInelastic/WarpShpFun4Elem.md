
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Frame_Elements</a> &gt; <a href="../">DistrInelastic</a> &gt; WarpShpFun4Elem</div>

--------------------------

# `WarpShpFun4Elem`


## <a name="_name"></a>Purpose

computes the 1d shape functions for section with warping


## <a name="_synopsis"></a>Synopsis

`[xWP,Nwx,DNwx] = WarpShpFun4Elem (ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">WARPSHPFUN4ELEM computes the 1d shape functions for section with warping
  dofs defined by the number ElemData.nWP and the type ElemData.WarpTyp

  xWP  is a nWP vector containing the coordinate of the warping sections along the element
  Nwx  is a [1 x nWP] cell array of functions handle with the Nw^x functions
  DNwx is a [1 x nWP] cell array of functions handle with the x derivative of the Nw^x functions</pre>
<!-- <div class="fragment"><pre class="comment">WARPSHPFUN4ELEM computes the 1d shape functions for section with warping
  dofs defined by the number ElemData.nWP and the type ElemData.WarpTyp

  xWP  is a nWP vector containing the coordinate of the warping sections along the element
  Nwx  is a [1 x nWP] cell array of functions handle with the Nw^x functions
  DNwx is a [1 x nWP] cell array of functions handle with the x derivative of the Nw^x functions</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../ReglIntTypList" class="code" title="ReglList = ReglIntTypList()">ReglIntTypList</a>	ReglIntTypList()</li><li><a href="../../../../Utilities/Interpolation/lagrangepoly" class="code" title="[P,R,S] = lagrangepoly(X,Y,XX)">lagrangepoly</a>	 Lagrange interpolation polynomial fitting a set of points</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->