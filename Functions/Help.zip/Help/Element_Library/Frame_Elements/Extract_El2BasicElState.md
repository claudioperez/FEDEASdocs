
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Frame_Elements</a> &gt; Extract_El2BasicElState</div>

--------------------------

# `Extract_El2BasicElState`


## <a name="_name"></a>Purpose

extract basic element state from element state


## <a name="_synopsis"></a>Synopsis

`BasicElState = Extract_El2BasicElState (ag,ElState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_EL2BASICELSTATE extract basic element state from element state
  BASICELSTATE = EXTRACT_EL2BASICELSTATE (AG,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for the state of the basic element and returns it in data structure BASICELSTATE;
  it needs compatibility array AG to determine the element deformations from displacements</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_EL2BASICELSTATE extract basic element state from element state
  BASICELSTATE = EXTRACT_EL2BASICELSTATE (AG,ELSTATE)
  function extracts from data structure ELSTATE the necessary information
  for the state of the basic element and returns it in data structure BASICELSTATE;
  it needs compatibility array AG to determine the element deformations from displacements</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Special_Elements/PointHinge" class="code" title="ElemResp = PointHinge (action,el_no,xyz,ElemData,ElemState)">PointHinge</a>	2d/3d plastic hinge element with ndm deformation modes for any section and material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->