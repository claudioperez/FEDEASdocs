---
title: Linear
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Linear`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Linear

<table>
<tr><td><a href="LE2dFrm">LE2dFrm</a></td><td>2d LE frame element under linear or nonlinear geometry </td></tr><tr><td><a href="LE2dFrm_w2ndOrdDF">LE2dFrm_w2ndOrdDF</a></td><td>2d LE frame element with moderate deformations under linear or NL geometry </td></tr><tr><td><a href="LE2dFrm_w2ndOrdFF">LE2dFrm_w2ndOrdFF</a></td><td>2d LE frame element with moderate deformations under linear or NL geometry </td></tr><tr><td><a href="LE2dFrm_wPdelta">LE2dFrm_wPdelta</a></td><td>2d linear elastic frame element with P-delta effect under linear or nonlinear geometry </td></tr><tr><td><a href="LE2dFrm_wVarIDF">LE2dFrm_wVarIDF</a></td><td>2d LE frame element with variable cross section under linear or NL geometry </td></tr><tr><td><a href="LE2dFrm_wVarIFF">LE2dFrm_wVarIFF</a></td><td>2d LE frame element with variable cross section under linear or NL geometry </td></tr><tr><td><a href="LE3dFrm">LE3dFrm</a></td><td>3d linear frame element under linear or nonlinear geometry </td></tr><tr><td><a href="LETruss">LETruss</a></td><td>2d/3d linear truss element under linear or nonlinear geometry </td></tr><tr><td><a href="LETrussC">LETrussC</a></td><td>2d/3d linear truss element under linear or nonlinear geometry </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->