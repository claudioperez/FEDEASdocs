
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Frame_Elements</a> &gt; Mass4Prism2dFrm</div>

--------------------------

# `Mass4Prism2dFrm`


## <a name="_name"></a>Purpose

consistent mass matrix for prismatic 2d frame element


## <a name="_synopsis"></a>Synopsis

`ElemMass = Mass4Prism2dFrm (xyz,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MASS4PRISM2dFRM consistent mass matrix for prismatic 2d frame element</pre>
<!-- <div class="fragment"><pre class="comment">MASS4PRISM2dFRM consistent mass matrix for prismatic 2d frame element</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm" class="code" title="ElemResp = Inel2dFrm (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm</a>	inelastic 2d frame element with different basic element types</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wDmg" class="code" title="ElemResp = Inel2dFrm_wDmg (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wDmg</a>	inelastic 2d frame element with damage plasticity</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wDmgnOff" class="code" title="ElemResp = Inel2dFrm_wDmg (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wDmgnOff</a>	inelastic 2d frame element with damage plasticity</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wGPNMYS" class="code" title="ElemResp = Inel2dFrm_wGPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wGPNMYS</a>	2d frame element with elastic-plastic hardening axial-flexure hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLHNMYS" class="code" title="ElemResp = Inel2dFrm_wLHNMYS (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLHNMYS</a>	2d linear elastic frame element with linear plastic hardening axial-flexure hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLHNMYS_wDmgOfs" class="code" title="ElemResp = Inel2dFrm_wLHNMYS_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLHNMYS_wDmgOfs</a>	=========================================================================================</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLHNMYS_wMR" class="code" title="ElemResp = Inel2dFrm_wLHNMYS_wMR (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLHNMYS_wMR</a>	2d linear elastic frame element with linear plastic hardening axial-flexure hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLPPM" class="code" title="ElemResp = Inel2dFrm_wLPPM (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLPPM</a>	2d frame linear elastic element perfectly plastic flexural response</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLPPNMYS" class="code" title="ElemResp = Inel2dFrm_wLPPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLPPNMYS</a>	2d linear elastic frame element with perfectly plastic axial-flexure hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wMDamg" class="code" title="ElemResp = Inel2dFrm_wMDamg (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wMDamg</a>	inelastic 2d frame element with damage plasticity for flexure</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wMDamgv1" class="code" title="ElemResp = Inel2dFrm_wMDamg (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wMDamgv1</a>	inelastic 2d frame element with damage plasticity for flexure</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wNMDamg" class="code" title="ElemResp = Inel2dFrm_wNMDamg (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wNMDamg</a>	inelastic 2d frame element with damage plasticity for flexure</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneComp" class="code" title="ElemResp = Inel2dFrm_wOneComp (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneComp</a>	one component 2d frame element with rigid-linear hardening end hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneCompN" class="code" title="ElemResp = Inel2dFrm_wOneCompN (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneCompN</a>	one component 2d frame element with rigid-linear hardening end hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneComp_wDmgDo" class="code" title="ElemResp = Inel2dFrm_wOneComp_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneComp_wDmgDo</a>	=========================================================================================</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneComp_wDmgOfs" class="code" title="ElemResp = Inel2dFrm_wOneComp_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneComp_wDmgOfs</a>	one component 2d frame element with rigid-linear hardening end hinges</li><li><a href="../../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wTwoComp" class="code" title="ElemResp = Inel2dFrm_wTwoComp (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wTwoComp</a>	two component 2d frame element (linear + linear-perfectly plastic)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_wMDamg" class="code" title="ElemResp = Dinel2dFrm_wMDamg (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_wMDamg</a>	inelastic 2d frame element with damage plasticity for flexure</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm" class="code" title="ElemResp = LE2dFrm (action,el_no,xyz,ElemData,ElemState)">LE2dFrm</a>	2d LE frame element under linear or nonlinear geometry</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wPdelta" class="code" title="ElemResp = LE2dFrm_wPdelta (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wPdelta</a>	2d linear elastic frame element with P-delta effect under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->