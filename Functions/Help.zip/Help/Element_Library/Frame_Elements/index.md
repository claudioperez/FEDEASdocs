---
title: Frame Elements
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Frame Elements`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Frame Elements

<table>
<tr><td><a href="Check3dFrmAxes">Check3dFrmAxes</a></td><td>check that y-axis is not co-linear with element chord </td></tr><tr><td><a href="Damage4Beam">Damage4Beam</a></td><td> </td></tr><tr><td><a href="DeformShape2dFrm">DeformShape2dFrm</a></td><td>deformed shape of linear elastic, uniform, prismatic 2d frame element </td></tr><tr><td><a href="DeformShape2dFrm_wDispIntp">DeformShape2dFrm_wDispIntp</a></td><td>deformed shape of 2d frame element with cubic polynomials </td></tr><tr><td><a href="DeformShape3dFrm">DeformShape3dFrm</a></td><td>deformed shape of linear elastic, uniform, prismatic 3d frame element </td></tr><tr><td><a href="DeformShape3dFrm_wDispIntp">DeformShape3dFrm_wDispIntp</a></td><td>deformed shape of 3d frame element with cubic polynomials </td></tr><tr><td><a href="Extract_El2BasicElState">Extract_El2BasicElState</a></td><td>extract basic element state from element state </td></tr><tr><td><a href="Mass4Prism2dFrm">Mass4Prism2dFrm</a></td><td>consistent mass matrix for prismatic 2d frame element </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="ConcentrInelastic">ConcentrInelastic</a></li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="DistrInelastic">DistrInelastic</a></li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Linear">Linear</a></li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->