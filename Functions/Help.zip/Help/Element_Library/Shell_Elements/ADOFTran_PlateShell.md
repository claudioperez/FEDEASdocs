
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; ADOFTran_PlateShell</div>

--------------------------

# `ADOFTran_PlateShell`


## <a name="_name"></a>Purpose

transforms active dof array from local to global reference for plate and shell elements


## <a name="_synopsis"></a>Synopsis

`arsz = ADOFTran_PlateShell (arsz,el_no,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ADOFTRAN_PLATESHELL transforms active dof array from local to global reference for plate and shell elements
  ARSZ = ADOFTRAN_PLATESHELL (ARSZ,EL_NO,XYZ)
  the function transforms the size array ARSZ with the active dofs of
  plate and shell elements from the local to the global reference system</pre>
<!-- <div class="fragment"><pre class="comment">ADOFTRAN_PLATESHELL transforms active dof array from local to global reference for plate and shell elements
  ARSZ = ADOFTRAN_PLATESHELL (ARSZ,EL_NO,XYZ)
  the function transforms the size array ARSZ with the active dofs of
  plate and shell elements from the local to the global reference system</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlate" class="code" title="ElemResp = LE4nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlate</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinPlate" class="code" title="ElemResp = LE4to9nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinPlate</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->