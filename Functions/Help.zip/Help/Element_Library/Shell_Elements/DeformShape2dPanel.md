
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; DeformShape2dPanel</div>

--------------------------

# `DeformShape2dPanel`


## <a name="_name"></a>Purpose

deformed shape of of 2d beam-column panel element


## <a name="_synopsis"></a>Synopsis

`[XYd,xyd] = DeformShape2dPanel (xyz,ElemData,u,~,MAGF)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFORMSHAPE2dPANEL deformed shape of of 2d beam-column panel element
  [XYd,xyd] = DEFORMSHAPE2DPANEL (ELEMDATA,XYZ,U,~,MAGF);
  The function returns the global coordinates of the magnified deformed shape
  of a 2d beam-column panel element under large end displacements in array XYd,
  and the local coordinates of the magnified deformed shape in array xyd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, and the end displacements in vector U.
  Optional argument is the magnification factor MAGF (default=10)</pre>
<!-- <div class="fragment"><pre class="comment">DEFORMSHAPE2dPANEL deformed shape of of 2d beam-column panel element
  [XYd,xyd] = DEFORMSHAPE2DPANEL (ELEMDATA,XYZ,U,~,MAGF);
  The function returns the global coordinates of the magnified deformed shape
  of a 2d beam-column panel element under large end displacements in array XYd,
  and the local coordinates of the magnified deformed shape in array xyd.
  Input arguments are the end node coordinates in array XYZ, the element
  properties in cell array ELEMDATA, and the end displacements in vector U.
  Optional argument is the magnification factor MAGF (default=10)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->