---
title: Inelastic
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Inelastic`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Inelastic

<table>
<tr><td><a href="BeamColPanel">BeamColPanel</a></td><td>2, 3 or 4-node beam-column panel zone element with inelastic material </td></tr><tr><td><a href="BeamColPanelO">BeamColPanelO</a></td><td>2, 3 or 4-node beam-column panel zone element with inelastic material </td></tr><tr><td><a href="Inel4nodeMindlinReShellwITC">Inel4nodeMindlinReShellwITC</a></td><td>isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC </td></tr><tr><td><a href="Inel4nodeMindlinShellwITC">Inel4nodeMindlinShellwITC</a></td><td>isoparametric inelastic 4 node quad Mindlin layer shell element with ITC </td></tr><tr><td><a href="Inel4to9nodeMindlinReShell">Inel4to9nodeMindlinReShell</a></td><td>inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers </td></tr><tr><td><a href="Inel4to9nodeMindlinShell">Inel4to9nodeMindlinShell</a></td><td>isoparametric 4-9 node quad layer shell element with inelastic material </td></tr><tr><td><a href="Inel4to9nodeQuad">Inel4to9nodeQuad</a></td><td>isoparametric 4-9 node quadrilateral element with inelastic material </td></tr><tr><td><a href="Inel4to9nodeReQuad">Inel4to9nodeReQuad</a></td><td>isoparametric 4-9 node quad element with inelastic material and reinforcing layers </td></tr><tr><td><a href="Inel8nodeBrick">Inel8nodeBrick</a></td><td>isoparametric 8 node brick element with inelastic material </td></tr><tr><td><a href="InelCST">InelCST</a></td><td>constant strain triangle with inelastic material under plane stress/strain </td></tr><tr><td><a href="InelDKT">InelDKT</a></td><td>inelastic discrete Kirchhoff triangle for plate bending </td></tr><tr><td><a href="InelLST">InelLST</a></td><td>linear strain triangle with inelastic material under plane stress/strain </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->