
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Shell_Elements</a> &gt; <a href="../">Linear</a> &gt; LE9nodeQuad</div>

--------------------------

# `LE9nodeQuad`


## <a name="_name"></a>Purpose

isoparametric 9 node quadrilateral element with linear elastic material


## <a name="_synopsis"></a>Synopsis

`ElemResp = LE9nodeQuad (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LE9NODEQUAD isoparametric 9 node quadrilateral element with linear elastic material
 ELEMRESP = LE9NODEQUAD (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of isoparametric 9-node quadrilateral element with linear elastic material under plane stress/strain; 
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'stre': integration point stress projection to nodes
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = STRSREC     for action = 'stre'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom  = character variable for geometric transformation of node variables
                (linear or corotational) (default=linear)
         t     = element thickness (default t=1)
         b     = element body forces (default b=[0;0] )
         nIP   = number of integration points (default nIP =3)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         Tr0        = transformation matrix from local to global coordinates
         Mat{i}.xyz = coordinates   of integration point i
         Mat{i}.eps = strain tensor at integration point i
         Mat{i}.sig = stress tensor at integration point i
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STRSREC is a data structure with nodal stress information in field(s)
         sigNd = nodal stresses</pre>
<!-- <div class="fragment"><pre class="comment">LE9NODEQUAD isoparametric 9 node quadrilateral element with linear elastic material
 ELEMRESP = LE9NODEQUAD (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of isoparametric 9-node quadrilateral element with linear elastic material under plane stress/strain; 
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'stre': integration point stress projection to nodes
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = STRSREC     for action = 'stre'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom  = character variable for geometric transformation of node variables
                (linear or corotational) (default=linear)
         t     = element thickness (default t=1)
         b     = element body forces (default b=[0;0] )
         nIP   = number of integration points (default nIP =3)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         Tr0        = transformation matrix from local to global coordinates
         Mat{i}.xyz = coordinates   of integration point i
         Mat{i}.eps = strain tensor at integration point i
         Mat{i}.sig = stress tensor at integration point i
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STRSREC is a data structure with nodal stress information in field(s)
         sigNd = nodal stresses</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../../../../Element_Library/Shell_Elements/TransformStr2GL" class="code" title="[epsi,sig] = TransformStr2GL (ndm,Tr0,epsi,sig)">TransformStr2GL</a>	transformation of strain and stress tensors from local to global reference system</li><li><a href="../../../../Element_Library/Shell_Elements/shape2d" class="code" title="[N,dNdx,J] = shape2d (nat,xyz,nodix)">shape2d</a>	shape functions for 4-9 node quadrilateral element</li><li><a href="../../../../Geometry/DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../../../../Geometry/GeomTran_QuadMemb" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadMemb (option,xyz,u,Du,DDu)">GeomTran_QuadMemb</a>	kinematic matrices and local displacements for a quadrilateral membrane element</li><li><a href="../../../../Geometry/kg_QuadMemb" class="code" title="kg = kg_QuadMemb (option,xyz,u,pl)">kg_QuadMemb</a>	geometric stiffness matrix for quadrilateral membrane element for different options</li><li><a href="../../../../Utilities/Quadrature/Gauss2d" class="code" title="[xIP,wIP] = Gauss2d (nIP)">Gauss2d</a>	Gauss integration rule in two dimensions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->