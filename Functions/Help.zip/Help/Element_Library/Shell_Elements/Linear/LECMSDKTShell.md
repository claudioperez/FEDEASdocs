
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Shell_Elements</a> &gt; <a href="../">Linear</a> &gt; LECMSDKTShell</div>

--------------------------

# `LECMSDKTShell`


## <a name="_name"></a>Purpose

linear elastic 3-node triangle with constant mebrane strain + DK bending


## <a name="_synopsis"></a>Synopsis

`ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> LECMSDKTSHELL linear elastic 3-node triangle with constant mebrane strain + DK bending      
 ELEMRESP = LECMSDKTSHELL (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of linear elastic 3-node triangle with constant mebrane strain + DK bending;
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'stre': integration point stress projection to nodes
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = STRSREC     for action = 'stre'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom  = character variable for geometric transformation of node variables
                (linear or corotational) (default=linear)
         t     = element thickness (default t=1)
         b     = element body forces (default b=[0;0] )
         w     = transverse element load (default w=0)
         nIP   = number of integration points (default nIP=3)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         Tr0         = transformation matrix from local to global coordinates
         Mat{i}.xyz  = coordinates           of membrane integration point i
         Mat{i}.eps  = strain tensor         at membrane integration point i
         Mat{i}.sig  = stress tensor         at membrane integration point i
         Mat{i}.Fxyz = coordinates           of flexural integration point i
         Mat{i}.M    = bending moment tensor at flexural integration point i
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STRSREC is a data structure with nodal stress information in field(s)
         sigNd = membrane forces
         MomNd = nodal moments</pre>
<!-- <div class="fragment"><pre class="comment"> LECMSDKTSHELL linear elastic 3-node triangle with constant mebrane strain + DK bending      
 ELEMRESP = LECMSDKTSHELL (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  response of linear elastic 3-node triangle with constant mebrane strain + DK bending;
  the element accounts for linear and nonlinear geometry for the nodal dof transformations; 
  depending on the value of the character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO, end node coordinates XYZ,
  and material and loading properties in the data structure ELEMDATA.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in ELEMRESP:
  ACTION = 'size': report size of element arrays
           'chec': check element property data for omissions and assign default values
           'init': initialize element history variables
           'forc': report element resisting forces
           'stif': report element stiffness matrix and resisting forces
           'mass': report lumped mass vector and consistent mass matrix
           'post': report post-processing information
           'stre': integration point stress projection to nodes
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure ELEMRESP stands for the following data object(s) for each ACTION:
  ELEMRESP = ARSZ        for action = 'size' 
  ELEMRESP = ELEMDATA    for action = 'chec'
  ELEMRESP = ELEMSTATE   for action = 'init'
  ELEMRESP = ELEMSTATE   for action = 'stif'
  ELEMRESP = ELEMSTATE   for action = 'forc'
  ELEMRESP = ELEMMASS    for action = 'mass'
  ELEMRESP = ELEMPOST    for action = 'post'
  ELEMRESP = STRSREC     for action = 'stre'
  ELEMRESP is empty      for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         Geom  = character variable for geometric transformation of node variables
                (linear or corotational) (default=linear)
         t     = element thickness (default t=1)
         b     = element body forces (default b=[0;0] )
         w     = transverse element load (default w=0)
         nIP   = number of integration points (default nIP=3)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         Tr0         = transformation matrix from local to global coordinates
         Mat{i}.xyz  = coordinates           of membrane integration point i
         Mat{i}.eps  = strain tensor         at membrane integration point i
         Mat{i}.sig  = stress tensor         at membrane integration point i
         Mat{i}.Fxyz = coordinates           of flexural integration point i
         Mat{i}.M    = bending moment tensor at flexural integration point i
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STRSREC is a data structure with nodal stress information in field(s)
         sigNd = membrane forces
         MomNd = nodal moments</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/ExtrReshu" class="code" title="[u,Du,DDu] = ExtrReshu (State,ndf,nen)">ExtrReshu</a>	extracts displacements and increments from State and reshapes into array</li><li><a href="../../../../Element_Library/Shell_Elements/Tint2d" class="code" title="[xIP,wIP] = Tint2d (nIP)">Tint2d</a>	integration rule over triangular area</li><li><a href="../../../../Element_Library/Shell_Elements/TranDK" class="code" title="T = TranDK (xyz)">TranDK</a>	transformation matrix for discrete Kirchhoff triangle constraints</li><li><a href="../../../../Element_Library/Shell_Elements/TransformMtensor2GL" class="code" title="Mg = TransformMtensor2GL (Tr0,Mv)">TransformMtensor2GL</a>	transformation of moment tensor from plane to global reference system</li><li><a href="../../../../Element_Library/Shell_Elements/TransformStr2GL" class="code" title="[epsi,sig] = TransformStr2GL (ndm,Tr0,epsi,sig)">TransformStr2GL</a>	transformation of strain and stress tensors from local to global reference system</li><li><a href="../../../../Element_Library/Shell_Elements/shapeCST" class="code" title="[N, dNdx ,J] = shapeCST (xi,xyz)">shapeCST</a>	shape functions for 3 node constant strain triangle</li><li><a href="../../../../Element_Library/Shell_Elements/shapeDKT" class="code" title="[N,dNdx,J] = shapeDKT (xi,xyz)">shapeDKT</a>	shape functions for 6-dof 3-node discrete Kirchhoff triangle</li><li><a href="../../../../Geometry/DefGeom_Tri" class="code" title="[xl,T]= DefGeom_Tri (xyz)">DefGeom_Tri</a>	determines local coordinates and corotational triad of triangular element</li><li><a href="../../../../Geometry/GeomTran_TriPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriPlate (option,xyz,u,Du,DDu)">GeomTran_TriPlate</a>	kinematic matrices and local displacements for a triangular plate element</li><li><a href="../../../../Geometry/kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->