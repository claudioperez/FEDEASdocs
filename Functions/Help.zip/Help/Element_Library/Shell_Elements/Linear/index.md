---
title: Linear
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Linear`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Linear

<table>
<tr><td><a href="LE4nodeMindlinPlate">LE4nodeMindlinPlate</a></td><td>linear elastic isoparametric 4-node quadrilateral Mindlin plate element </td></tr><tr><td><a href="LE4nodeMindlinPlatewITC">LE4nodeMindlinPlatewITC</a></td><td>linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC </td></tr><tr><td><a href="LE4nodeMindlinShellwITC">LE4nodeMindlinShellwITC</a></td><td>linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC </td></tr><tr><td><a href="LE4nodeQuad">LE4nodeQuad</a></td><td>isoparametric 4-node quadrilateral element with linear elastic material </td></tr><tr><td><a href="LE4nodeQuadwIM">LE4nodeQuadwIM</a></td><td>isoparametric 4-node quad element with linear elastic material and incompatible bending modes </td></tr><tr><td><a href="LE4to9nodeMindlinPlate">LE4to9nodeMindlinPlate</a></td><td>linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element </td></tr><tr><td><a href="LE4to9nodeMindlinShell">LE4to9nodeMindlinShell</a></td><td>linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element </td></tr><tr><td><a href="LE4to9nodeQuad">LE4to9nodeQuad</a></td><td>isoparametric 4-9 node quadrilateral element with linear elastic material </td></tr><tr><td><a href="LE8nodeBrick">LE8nodeBrick</a></td><td>isoparametric 8 node brick element with linear elastic material </td></tr><tr><td><a href="LE9nodeQuad">LE9nodeQuad</a></td><td>isoparametric 9 node quadrilateral element with linear elastic material </td></tr><tr><td><a href="LECMSDKTShell">LECMSDKTShell</a></td><td>linear elastic 3-node triangle with constant mebrane strain + DK bending </td></tr><tr><td><a href="LECMSDKTShell_wDDOF">LECMSDKTShell_wDDOF</a></td><td>linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF </td></tr><tr><td><a href="LECST">LECST</a></td><td>constant strain triangle with linear elastic material under plane stress/strain </td></tr><tr><td><a href="LEDKT">LEDKT</a></td><td>discrete Kirchhoff 3-node triangle for plate bending with linear elastic material </td></tr><tr><td><a href="LELST">LELST</a></td><td>linear strain triangle with linear elastic material under plane stress/strain </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->