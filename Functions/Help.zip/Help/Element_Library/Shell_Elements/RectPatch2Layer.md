
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; RectPatch2Layer</div>

--------------------------

# `RectPatch2Layer`


## <a name="_name"></a>Purpose

integration points and weights for 1d-integration of rectangular patch


## <a name="_synopsis"></a>Synopsis

`[yfib,wfib] = RectPatch2Layer (patcoor,IntTyp,nlayer)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RECTPATCH2LAYER integration points and weights for 1d-integration of rectangular patch
  [YFIB,WFIB] = RECTPATCH2LAYER (PATCOOR,INTTYP,NLAYER)
  function determines locations in vector YFIB and integration weights in vector WFIB
  for 1d integration of a rectangular patch for the integration scheme
  in character array INTTYP and the number of integration points in NLAYER;
  the dimension of the rectangular patch is supplied by specifying the
  coordinates of opposite corners in array PATCOOR ([y1 z1 (+ve quadrant);y2 z2 (-ve quadrant)])
  (NOTE: right handed local coordinate system x-y-z!)
  INTTYP can be either 'Midpoint', 'Gauss', Lobatto' or 'Trap'</pre>
<!-- <div class="fragment"><pre class="comment">RECTPATCH2LAYER integration points and weights for 1d-integration of rectangular patch
  [YFIB,WFIB] = RECTPATCH2LAYER (PATCOOR,INTTYP,NLAYER)
  function determines locations in vector YFIB and integration weights in vector WFIB
  for 1d integration of a rectangular patch for the integration scheme
  in character array INTTYP and the number of integration points in NLAYER;
  the dimension of the rectangular patch is supplied by specifying the
  coordinates of opposite corners in array PATCOOR ([y1 z1 (+ve quadrant);y2 z2 (-ve quadrant)])
  (NOTE: right handed local coordinate system x-y-z!)
  INTTYP can be either 'Midpoint', 'Gauss', Lobatto' or 'Trap'</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->