
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; RectPatch2Layer_Alt</div>

--------------------------

# `RectPatch2Layer_Alt`


## <a name="_name"></a>Purpose

integration points and weights for 1d-integration of rectangular patch


## <a name="_synopsis"></a>Synopsis

`[yfib,wfib] = RectPatch2Layer_Alt (patcoor,IntTyp,nlayer)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RECTPATCH2LAYER integration points and weights for 1d-integration of rectangular patch
  [YFIB,WFIB] = RECTPATCH2LAYER (PATCOOR,INTTYP,NLAYER)
  function determines locations in vector YFIB and integration weights in vector WFIB
  for 1d integration of a rectangular patch for the integration scheme
  in character array INTTYP and the number of integration points in NLAYER;
  the dimension of the rectangular patch is supplied by specifying the
  coordinates of opposite corners in array PATCOOR ([y1 z1 (top right);y2 z2 (bottom left)])
  (NOTE: right handed local coordinate system x-y-z!)
  INTTYP can be either 'Midpoint', 'Gauss', Lobatto' or 'Trap'</pre>
<!-- <div class="fragment"><pre class="comment">RECTPATCH2LAYER integration points and weights for 1d-integration of rectangular patch
  [YFIB,WFIB] = RECTPATCH2LAYER (PATCOOR,INTTYP,NLAYER)
  function determines locations in vector YFIB and integration weights in vector WFIB
  for 1d integration of a rectangular patch for the integration scheme
  in character array INTTYP and the number of integration points in NLAYER;
  the dimension of the rectangular patch is supplied by specifying the
  coordinates of opposite corners in array PATCOOR ([y1 z1 (top right);y2 z2 (bottom left)])
  (NOTE: right handed local coordinate system x-y-z!)
  INTTYP can be either 'Midpoint', 'Gauss', Lobatto' or 'Trap'</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/Quadrature/Gauss" class="code" title="[xIP,wIP] = Gauss (nIP)">Gauss</a>	locations and weights of Gauss-Legendre integration scheme</li><li><a href="../../../Utilities/Quadrature/Lobatto" class="code" title="[xIP,wIP] = Lobatto (nIP)">Lobatto</a>	locations and weights of Gauss-Lobatto integration scheme</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->