
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; Tint2d</div>

--------------------------

# `Tint2d`


## <a name="_name"></a>Purpose

integration rule over triangular area


## <a name="_synopsis"></a>Synopsis

`[xIP,wIP] = Tint2d (nIP)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TINT2D integration rule over triangular area
  [XIP,WIP] = TINT2D (NIP) locations and weights of integration over triangular area   
  the function returns the locations in area coordinates and weights of integration
  over triangular are for NIP integration points;
  the locations are reported in (nIPx3) array XIP and the weights in row vector WIP</pre>
<!-- <div class="fragment"><pre class="comment">TINT2D integration rule over triangular area
  [XIP,WIP] = TINT2D (NIP) locations and weights of integration over triangular area   
  the function returns the locations in area coordinates and weights of integration
  over triangular are for NIP integration points;
  the locations are reported in (nIPx3) array XIP and the weights in row vector WIP</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelCST" class="code" title="ElemResp = InelCST (action,el_no,xyz,ElemData,ElemState)">InelCST</a>	constant strain triangle with inelastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECST" class="code" title="ElemResp = LECST (action,el_no,xyz,ElemData,ElemState)">LECST</a>	constant strain triangle with linear elastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LELST" class="code" title="ElemResp = LELST (action,el_no,xyz,ElemData,ElemState)">LELST</a>	linear strain triangle with linear elastic material under plane stress/strain</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->