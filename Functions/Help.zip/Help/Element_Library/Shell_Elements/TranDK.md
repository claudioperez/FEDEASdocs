
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; TranDK</div>

--------------------------

# `TranDK`


## <a name="_name"></a>Purpose

transformation matrix for discrete Kirchhoff triangle constraints


## <a name="_synopsis"></a>Synopsis

`T = TranDK (xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANDK transformation matrix for discrete Kirchhoff triangle constraints
  T = TRANDK (XYZ)
  the function sets up the 12x9 transformation matrix T from the 12 rotation dofs at the nodes
  and midsides of a 3-node triangle to the 9 nodal dofs;
  References: R.D. Cook et al, Concepts and Applications of FE Analysis, 3rd ed, pp. 328-332
  J-L Batoz, et al, A Study of Three-Node Triangular Plate Bending Elements, IJNME (1980), pp. 1771-1812</pre>
<!-- <div class="fragment"><pre class="comment">TRANDK transformation matrix for discrete Kirchhoff triangle constraints
  T = TRANDK (XYZ)
  the function sets up the 12x9 transformation matrix T from the 12 rotation dofs at the nodes
  and midsides of a 3-node triangle to the 9 nodal dofs;
  References: R.D. Cook et al, Concepts and Applications of FE Analysis, 3rd ed, pp. 328-332
  J-L Batoz, et al, A Study of Three-Node Triangular Plate Bending Elements, IJNME (1980), pp. 1771-1812</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->