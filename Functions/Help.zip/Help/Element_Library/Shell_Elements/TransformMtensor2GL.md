
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; TransformMtensor2GL</div>

--------------------------

# `TransformMtensor2GL`


## <a name="_name"></a>Purpose

transformation of moment tensor from plane to global reference system


## <a name="_synopsis"></a>Synopsis

`Mg = TransformMtensor2GL (Tr0,Mv)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSFORMMTENSOR2GL transformation of moment tensor from plane to global reference system
  MG = TRANSFORMMTENSOR2GL (TR0,MV) function to transform the moment tensor
  from the plane to the global reference system; the plane moment tensor MV
  is supplied in vector form with component order xx,yy,xy and is returned
  in vector form MG with component order XX,YY,ZZ,XY,YZ,XZ in the global reference system X-Y-Z;
  TR0 is the rotation matrix from the global to the local reference</pre>
<!-- <div class="fragment"><pre class="comment">TRANSFORMMTENSOR2GL transformation of moment tensor from plane to global reference system
  MG = TRANSFORMMTENSOR2GL (TR0,MV) function to transform the moment tensor
  from the plane to the global reference system; the plane moment tensor MV
  is supplied in vector form with component order xx,yy,xy and is returned
  in vector form MG with component order XX,YY,ZZ,XY,YZ,XZ in the global reference system X-Y-Z;
  TR0 is the rotation matrix from the global to the local reference</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlate" class="code" title="ElemResp = LE4nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlate</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinPlate" class="code" title="ElemResp = LE4to9nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinPlate</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinShell" class="code" title="ElemResp = LE4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinShell</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->