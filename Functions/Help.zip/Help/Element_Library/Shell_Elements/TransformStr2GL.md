
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; TransformStr2GL</div>

--------------------------

# `TransformStr2GL`


## <a name="_name"></a>Purpose

transformation of strain and stress tensors from local to global reference system


## <a name="_synopsis"></a>Synopsis

`[epsi,sig] = TransformStr2GL (ndm,Tr0,epsi,sig)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSFORMSTR2GL transformation of strain and stress tensors from local to global reference system
  [EPSI,SIG] = TRANSFORMSTR2GL (NDM,TR0,EPSI,SIG) function to transform the strain and stress
  tensors from the local to the global reference system; the strain EPSI and stress SIG are
  supplied in vector form with component order xx,yy,zz,xy,yz,xz and
  returned in vector form with component order XX,YY,ZZ,XY,YZ,XZ;
  NDM is the model dimension and TR0 is the rotation matrix from the global to the local reference;
  the function accounts for the case of a 2d plane stress or strain field in a 3d model</pre>
<!-- <div class="fragment"><pre class="comment">TRANSFORMSTR2GL transformation of strain and stress tensors from local to global reference system
  [EPSI,SIG] = TRANSFORMSTR2GL (NDM,TR0,EPSI,SIG) function to transform the strain and stress
  tensors from the local to the global reference system; the strain EPSI and stress SIG are
  supplied in vector form with component order xx,yy,zz,xy,yz,xz and
  returned in vector form with component order XX,YY,ZZ,XY,YZ,XZ;
  NDM is the model dimension and TR0 is the rotation matrix from the global to the local reference;
  the function accounts for the case of a 2d plane stress or strain field in a 3d model</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeQuad" class="code" title="ElemResp = Inel4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeReQuad" class="code" title="ElemResp = Inel4to9nodeReQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeReQuad</a>	isoparametric 4-9 node quad element with inelastic material and reinforcing layers</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelCST" class="code" title="ElemResp = InelCST (action,el_no,xyz,ElemData,ElemState)">InelCST</a>	constant strain triangle with inelastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeQuad" class="code" title="ElemResp = LE4nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuad</a>	isoparametric 4-node quadrilateral element with linear elastic material</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeQuadwIM" class="code" title="ElemResp = LE4nodeQuadwIM (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuadwIM</a>	isoparametric 4-node quad element with linear elastic material and incompatible bending modes</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinShell" class="code" title="ElemResp = LE4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinShell</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4to9nodeQuad" class="code" title="ElemResp = LE4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with linear elastic material</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE9nodeQuad" class="code" title="ElemResp = LE9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE9nodeQuad</a>	isoparametric 9 node quadrilateral element with linear elastic material</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECST" class="code" title="ElemResp = LECST (action,el_no,xyz,ElemData,ElemState)">LECST</a>	constant strain triangle with linear elastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LELST" class="code" title="ElemResp = LELST (action,el_no,xyz,ElemData,ElemState)">LELST</a>	linear strain triangle with linear elastic material under plane stress/strain</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->