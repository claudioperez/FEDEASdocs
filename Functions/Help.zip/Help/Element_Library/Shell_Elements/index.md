---
title: Shell Elements
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Shell Elements`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Shell Elements

<table>
<tr><td><a href="ADOFTran_PlateShell">ADOFTran_PlateShell</a></td><td>transforms active dof array from local to global reference for plate and shell elements </td></tr><tr><td><a href="DeformShape2dPanel">DeformShape2dPanel</a></td><td>deformed shape of of 2d beam-column panel element </td></tr><tr><td><a href="RectPatch2Layer">RectPatch2Layer</a></td><td>integration points and weights for 1d-integration of rectangular patch </td></tr><tr><td><a href="RectPatch2Layer_Alt">RectPatch2Layer_Alt</a></td><td>integration points and weights for 1d-integration of rectangular patch </td></tr><tr><td><a href="Tint2d">Tint2d</a></td><td>integration rule over triangular area </td></tr><tr><td><a href="TranDK">TranDK</a></td><td>transformation matrix for discrete Kirchhoff triangle constraints </td></tr><tr><td><a href="TransformMtensor2GL">TransformMtensor2GL</a></td><td>transformation of moment tensor from plane to global reference system </td></tr><tr><td><a href="TransformStr2GL">TransformStr2GL</a></td><td>transformation of strain and stress tensors from local to global reference system </td></tr><tr><td><a href="shape2d">shape2d</a></td><td>shape functions for 4-9 node quadrilateral element </td></tr><tr><td><a href="shape2dPanel">shape2dPanel</a></td><td>shape functions for 4 node beam-column panel element </td></tr><tr><td><a href="shape2dQT">shape2dQT</a></td><td>shape functions for 4-9 node quadrilateral element and 3-6 node triangle </td></tr><tr><td><a href="shape3d">shape3d</a></td><td>shape functions for 8 node solid (brick) element </td></tr><tr><td><a href="shapeBhat">shapeBhat</a></td><td>shape function Bhat </td></tr><tr><td><a href="shapeCST">shapeCST</a></td><td>shape functions for 3 node constant strain triangle </td></tr><tr><td><a href="shapeDKT">shapeDKT</a></td><td>shape functions for 6-dof 3-node discrete Kirchhoff triangle </td></tr><tr><td><a href="shapeLST">shapeLST</a></td><td>shape functions for 6 node linear strain triangle </td></tr><tr><td><a href="shapeMN">shapeMN</a></td><td>shape functions for 4-node panel element with mid-edge nodes </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Inelastic">Inelastic</a></li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Linear">Linear</a></li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->