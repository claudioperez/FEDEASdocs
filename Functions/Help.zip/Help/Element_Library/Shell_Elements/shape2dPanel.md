
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shape2dPanel</div>

--------------------------

# `shape2dPanel`


## <a name="_name"></a>Purpose

shape functions for 4 node beam-column panel element


## <a name="_synopsis"></a>Synopsis

`[N,dNdx] = shape2dPanel (nat,xyz,Dx,Dy)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPE2DPANEL shape functions for 4 node beam-column panel element
  [N,dNdx] = SHAPE2DPANEL (NAT,XYZ) shape functions for 4 node beam-column panel element

  Input Parameters
  ----------------
  nat  = [ xi eta ] natural coordinates of point of interest
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape function values for point of interest
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i</pre>
<!-- <div class="fragment"><pre class="comment">SHAPE2DPANEL shape functions for 4 node beam-column panel element
  [N,dNdx] = SHAPE2DPANEL (NAT,XYZ) shape functions for 4 node beam-column panel element

  Input Parameters
  ----------------
  nat  = [ xi eta ] natural coordinates of point of interest
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape function values for point of interest
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/BeamColPanel" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanel</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->