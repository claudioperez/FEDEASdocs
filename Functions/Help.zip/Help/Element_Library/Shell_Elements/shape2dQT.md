
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shape2dQT</div>

--------------------------

# `shape2dQT`


## <a name="_name"></a>Purpose

shape functions for 4-9 node quadrilateral element and 3-6 node triangle


## <a name="_synopsis"></a>Synopsis

`[N,dNdx,J] = shape2dQT (option,nat,xyz,nodix)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> SHAPE2DQT shape functions for 4-9 node quadrilateral element and 3-6 node triangle
  [N,dNdx,J] = SHAPE2DQT (NAT,XYZ,NODIX) shape functions for 4-9 node quadrilateral element and 3-6 node triangle

  Input Parameters
  ----------------
  option = 'T' for triangle
  nat    = [ xi eta ] natural coordinates of element
  xyz    = nodal coordinates for element (row i for node i)
  nodix  = node index, e.g. [1:4 7 8] if nodes 1 through 4 (always), 7 and 8 are present 
  ----------------
  Return Variables
  ----------------
  N     = shape functions in natural coordinates
  dNdx  = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J     = Jacobian of transformation from geometric to natural coordinates</pre>
<!-- <div class="fragment"><pre class="comment"> SHAPE2DQT shape functions for 4-9 node quadrilateral element and 3-6 node triangle
  [N,dNdx,J] = SHAPE2DQT (NAT,XYZ,NODIX) shape functions for 4-9 node quadrilateral element and 3-6 node triangle

  Input Parameters
  ----------------
  option = 'T' for triangle
  nat    = [ xi eta ] natural coordinates of element
  xyz    = nodal coordinates for element (row i for node i)
  nodix  = node index, e.g. [1:4 7 8] if nodes 1 through 4 (always), 7 and 8 are present 
  ----------------
  Return Variables
  ----------------
  N     = shape functions in natural coordinates
  dNdx  = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J     = Jacobian of transformation from geometric to natural coordinates</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->