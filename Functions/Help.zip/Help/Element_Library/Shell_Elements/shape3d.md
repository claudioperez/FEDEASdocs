
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shape3d</div>

--------------------------

# `shape3d`


## <a name="_name"></a>Purpose

shape functions for 8 node solid (brick) element


## <a name="_synopsis"></a>Synopsis

`[N,dNdx,J] = shape3d (nat,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPE3D shape functions for 8 node solid (brick) element
  [N,dNdx,J] = SHAPE3D (NAT,XYZ) shape functions for 8 node solid (brick) element

  Input Parameters
  ----------------
  nat  = [ xi eta zeta ] natural coordinates in element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates
  ------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">SHAPE3D shape functions for 8 node solid (brick) element
  [N,dNdx,J] = SHAPE3D (NAT,XYZ) shape functions for 8 node solid (brick) element

  Input Parameters
  ----------------
  nat  = [ xi eta zeta ] natural coordinates in element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates
  ------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel8nodeBrick" class="code" title="ElemResp = Inel8nodeBrick (action,el_no,xyz,ElemData,ElemState)">Inel8nodeBrick</a>	isoparametric 8 node brick element with inelastic material</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE8nodeBrick" class="code" title="ElemResp = LE8nodeBrick (action,el_no,xyz,ElemData,ElemState)">LE8nodeBrick</a>	isoparametric 8 node brick element with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->