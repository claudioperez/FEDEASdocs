
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shapeBhat</div>

--------------------------

# `shapeBhat`


## <a name="_name"></a>Purpose

shape function Bhat


## <a name="_synopsis"></a>Synopsis

`[Bhat,G,J] = shapeBhat(npd,nat,wIP,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPEBHAT shape function Bhat</pre>
<!-- <div class="fragment"><pre class="comment">SHAPEBHAT shape function Bhat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../shape2d" class="code" title="[N,dNdx,J] = shape2d (nat,xyz,nodix)">shape2d</a>	shape functions for 4-9 node quadrilateral element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->