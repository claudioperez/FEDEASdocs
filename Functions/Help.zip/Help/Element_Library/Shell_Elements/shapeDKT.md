
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shapeDKT</div>

--------------------------

# `shapeDKT`


## <a name="_name"></a>Purpose

shape functions for 6-dof 3-node discrete Kirchhoff triangle


## <a name="_synopsis"></a>Synopsis

`[N,dNdx,J] = shapeDKT (xi,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPEDKT shape functions for 6-dof 3-node discrete Kirchhoff triangle
  [N,dNdx,J] = SHAPEDKT (XI,XYZ) shape functions for 6-dof 3-node discrete Kirchhoff triangle

  Input Parameters
  ----------------
  nat  = [ xi(1:3 ] natural coordinates of element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates</pre>
<!-- <div class="fragment"><pre class="comment">SHAPEDKT shape functions for 6-dof 3-node discrete Kirchhoff triangle
  [N,dNdx,J] = SHAPEDKT (XI,XYZ) shape functions for 6-dof 3-node discrete Kirchhoff triangle

  Input Parameters
  ----------------
  nat  = [ xi(1:3 ] natural coordinates of element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->