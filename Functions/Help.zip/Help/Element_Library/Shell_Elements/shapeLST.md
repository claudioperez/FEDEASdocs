
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shapeLST</div>

--------------------------

# `shapeLST`


## <a name="_name"></a>Purpose

shape functions for 6 node linear strain triangle


## <a name="_synopsis"></a>Synopsis

`[N,dNdx,J] = shapeLST (xi,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPELST shape functions for 6 node linear strain triangle
  [N,dNdx,J] = SHAPELST(XI,XYZ) shape functions for 6 node linear strain triangle

  Input Parameters
  ----------------
  xi   = natural (area) coordinates of element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates</pre>
<!-- <div class="fragment"><pre class="comment">SHAPELST shape functions for 6 node linear strain triangle
  [N,dNdx,J] = SHAPELST(XI,XYZ) shape functions for 6 node linear strain triangle

  Input Parameters
  ----------------
  xi   = natural (area) coordinates of element
  xyz  = nodal coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N    = shape functions in natural coordinates
  dNdx = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J    = Jacobian of transformation from geometric to natural coordinates</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../../Element_Library/Shell_Elements/Linear/LELST" class="code" title="ElemResp = LELST (action,el_no,xyz,ElemData,ElemState)">LELST</a>	linear strain triangle with linear elastic material under plane stress/strain</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->