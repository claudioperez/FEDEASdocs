
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Shell_Elements</a> &gt; shapeMN</div>

--------------------------

# `shapeMN`


## <a name="_name"></a>Purpose

shape functions for 4-node panel element with mid-edge nodes


## <a name="_synopsis"></a>Synopsis

`[N,dNdx,J] = shapeMN (nat,xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHAPEMN shape functions for 4-node panel element with mid-edge nodes
  [N,dNdx,J] = SHAPEMN (NAT,XYZ,NODIX) shape functions for 4-node panel element with mid-edge nodes

  Input Parameters
  ----------------
  nat   = [ xi eta ] natural coordinates of point of interest
  xyz   = node coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N     = shape function values for point of interest
  dNdx  = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J     = Jacobian of transformation from geometric to natural coordinates

  Reference: T.J.R. Hughes, The Finite Element Method, pp. 135</pre>
<!-- <div class="fragment"><pre class="comment">SHAPEMN shape functions for 4-node panel element with mid-edge nodes
  [N,dNdx,J] = SHAPEMN (NAT,XYZ,NODIX) shape functions for 4-node panel element with mid-edge nodes

  Input Parameters
  ----------------
  nat   = [ xi eta ] natural coordinates of point of interest
  xyz   = node coordinates for element (row i for node i)
  ----------------
  Return Variables
  ----------------
  N     = shape function values for point of interest
  dNdx  = dNdx(i,j) = derivative of shape function j with respect to geometric coordinate x_i
  J     = Jacobian of transformation from geometric to natural coordinates

  Reference: T.J.R. Hughes, The Finite Element Method, pp. 135</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->