
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Special_Elements</a> &gt; PointHinge</div>

--------------------------

# `PointHinge`


## <a name="_name"></a>Purpose

2d/3d plastic hinge element with ndm deformation modes for any section and material


## <a name="_synopsis"></a>Synopsis

`ElemResp = PointHinge (action,el_no,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">POINTHINGE 2d/3d plastic hinge element with ndm deformation modes for any section and material
  ELEMRESP = POINTHINGE (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of a 2d/3d plastic hinge element with ndm deformation modes
           for any type of section and material
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'size' function reports size of element arrays in variable ARSZ
           'chec' function checks element property data for omissions
                  and returns default values in ELEMDATA
           'init' function returns element history variables in ELEMSTATE
           'forc' function returns element resisting forces in ELEMSTATE
           'stif' function returns element stiffness matrix and resisting forces in ELEMSTATE
           'post' function returns data structure ELEMPOST with post-processing information
  depending on value of character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO and end node coordinates XYZ;
  the data structure ELEMDATA supplies the element property data.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure ELEMRESP stands for the following data object depending on value of ACTION 
  ELEMRESP = ARSZ       for action = 'size' 
  ELEMRESP = ELEMDATA   for action = 'chec'
  ELEMRESP = ELEMSTATE  for action = 'init'
  ELEMRESP = ELEMSTATE  for action = 'stif'
  ELEMRESP = ELEMSTATE  for action = 'forc'
  ELEMRESP = ELEMPOST   for action = 'post'
  ELEMRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         v     = element deformations
         q     = element basic forces
         Sec   = section response information for post-processing (see section function with SecName)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         SecName = function for section s-e response
         SecData = section property data (see section function with SecName)</pre>
<!-- <div class="fragment"><pre class="comment">POINTHINGE 2d/3d plastic hinge element with ndm deformation modes for any section and material
  ELEMRESP = POINTHINGE (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)
  function determines the response of a 2d/3d plastic hinge element with ndm deformation modes
           for any type of section and material
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'size' function reports size of element arrays in variable ARSZ
           'chec' function checks element property data for omissions
                  and returns default values in ELEMDATA
           'init' function returns element history variables in ELEMSTATE
           'forc' function returns element resisting forces in ELEMSTATE
           'stif' function returns element stiffness matrix and resisting forces in ELEMSTATE
           'post' function returns data structure ELEMPOST with post-processing information
  depending on value of character variable ACTION the function returns information
  in data structure ELEMRESP for the element with number EL_NO and end node coordinates XYZ;
  the data structure ELEMDATA supplies the element property data.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure ELEMRESP stands for the following data object depending on value of ACTION 
  ELEMRESP = ARSZ       for action = 'size' 
  ELEMRESP = ELEMDATA   for action = 'chec'
  ELEMRESP = ELEMSTATE  for action = 'init'
  ELEMRESP = ELEMSTATE  for action = 'stif'
  ELEMRESP = ELEMSTATE  for action = 'forc'
  ELEMRESP = ELEMPOST   for action = 'post'
  ELEMRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ARSZ   is an Boolean array of size NDF x NEN,
         where NDF = number of DOFs/node, NEN = number of nodes,
         with unit values corresponding to the active element DOFs
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMSTATE is a data structure with the current element state; it has the fields
         u     = vector of total element displacements in global reference
         Du    = vector of element displacement increments from last convergence
         DDu   = vector of element displacement increments from last iteration
         ke    = element stiffness matrix in global reference; updated under ACTION = 'stif'
         p     = element resisting force vector in global reference; updated under ACTION = 'stif' or 'forc'
         Past  = element history variables at last converged state
         Pres  = current element history variables
         lamda = row vector of current load factor(s)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMPOST is a data structure with element response information for post-processing in fields
         v     = element deformations
         q     = element basic forces
         Sec   = section response information for post-processing (see section function with SecName)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ELEMDATA is a data structure with element property information in fields
         SecName = function for section s-e response
         SecData = section property data (see section function with SecName)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Extract_BasicEl2SecState" class="code" title="SecState = Extract_BasicEl2SecState (sec,ae,ElState)">Extract_BasicEl2SecState</a>	extract section state from basic element state</li><li><a href="../../../Element_Library/Frame_Elements/Extract_El2BasicElState" class="code" title="BasicElState = Extract_El2BasicElState (ag,ElState)">Extract_El2BasicElState</a>	extract basic element state from element state</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->