---
title: Special Elements
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Special Elements`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Special Elements

<table>
<tr><td><a href="MaterialWrapper">MaterialWrapper</a></td><td>wrapper element that passes on arguments to the material state determination </td></tr><tr><td><a href="PointHinge">PointHinge</a></td><td>2d/3d plastic hinge element with ndm deformation modes for any section and material </td></tr><tr><td><a href="PointSDOFElem">PointSDOFElem</a></td><td>POINTSDOFELEM </td></tr><tr><td><a href="Sample_Element">Sample_Element</a></td><td>sample element </td></tr><tr><td><a href="SectWrapNMFrcDsp">SectWrapNMFrcDsp</a></td><td> </td></tr><tr><td><a href="SectionWrapper">SectionWrapper</a></td><td>wrapper element that passes on arguments to the section state determination </td></tr><tr><td><a href="ShearBeam">ShearBeam</a></td><td>POINTSDOFELEM </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->