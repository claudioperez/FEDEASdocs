
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 A_matrix</div>

--------------------------

# `A_matrix`


## <a name="_name"></a>Purpose

kinematic matrix of structural model with 2d/3d truss and 2d frame elements


## <a name="_synopsis"></a>Synopsis

`A = A_matrix (Model)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">A_MATRIX kinematic matrix of structural model with 2d/3d truss and 2d frame elements
  A = A_MATRIX (MODEL)
  the function forms the kinematic matrix A for all degrees of freedom (DOFs) and
  all element deformations of the structural model specified in data structure MODEL; 
  this version is limited to 2d/3d truss and 2d frame elements</pre>
<!-- <div class="fragment"><pre class="comment">A_MATRIX kinematic matrix of structural model with 2d/3d truss and 2d frame elements
  A = A_MATRIX (MODEL)
  the function forms the kinematic matrix A for all degrees of freedom (DOFs) and
  all element deformations of the structural model specified in data structure MODEL; 
  this version is limited to 2d/3d truss and 2d frame elements</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li><li><a href="../../Solution_Library/Static_Analysis/Event2Event_NLAnalysis" class="code" title="[lamdah,Qh,Ufh,Vph,Iph] = Event2Event_NLAnalysis (opt,Model,ElemData,Loading,ConvPar)">Event2Event_NLAnalysis</a>	event-to-event incremental analysis with linear or P-DELTA geometry</li><li><a href="../../Solution_Library/Static_Analysis/Incipient_Collapse_State" class="code" title="[Qc,Uf,Vpl] = Incipient_Collapse_State (Model,ElemData,Loading)">Incipient_Collapse_State</a>	STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis" class="code" title="[lamdac,Qc,DUf,DVpl] = PlasticAnalysis (Model,ElemData,Loading,LPOpt)">PlasticAnalysis</a>	collapse load factor, basic forces, and collapse mechanism by plastic analysis</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis_wUBT" class="code" title="[lamdac,DUf,DVhp] = PlasticAnalysis_wUBT (Af,Qpl,Pref,Pcf,Options)">PlasticAnalysis_wUBT</a>	collapse load factor and deformation increments by upper bound theorem of plastic analysis</li><li><a href="../../Utilities/PostProcessing/Get_Veps" class="code" title=" Veps = Get_Veps (Model,Uf,Vpl)">Get_Veps</a>	determine the elastic deformations from the displacements and plastic deformations</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->