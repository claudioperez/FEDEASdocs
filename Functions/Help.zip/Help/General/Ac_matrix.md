
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Ac_matrix</div>

--------------------------

# `Ac_matrix`


## <a name="_name"></a>Purpose

function sets up constraint transformation matrix Ac


## <a name="_synopsis"></a>Synopsis

`[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">AC_MATRIX function sets up constraint transformation matrix Ac
  [AC,ACF,IDE] = AC_MATRIX (MODEL,ELEMDATA,INDDOF)
  the function sets up the constraint transformation matrix AC for all dofs
  and ACF for the free dofs of the structural model in data structure MODEL;
  the independent dofs can be specified in the optional index vector INDDOF;
  the function also returns the index IDE of non-zero element deformations</pre>
<!-- <div class="fragment"><pre class="comment">AC_MATRIX function sets up constraint transformation matrix Ac
  [AC,ACF,IDE] = AC_MATRIX (MODEL,ELEMDATA,INDDOF)
  the function sets up the constraint transformation matrix AC for all dofs
  and ACF for the free dofs of the structural model in data structure MODEL;
  the independent dofs can be specified in the optional index vector INDDOF;
  the function also returns the index IDE of non-zero element deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../A_matrix" class="code" title="A = A_matrix (Model)">A_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../Constrain_A_matrix" class="code" title="[Ac,inddof] = Constrain_A_matrix (A,conid,itdof)">Constrain_A_matrix</a>	constraint matrix for linear kinematic constraints</li><li><a href="../../Utilities/General/D_index" class="code" title="ied = D_index (Model)">D_index</a>	cell array of indices into structure arrays for non-zero element deformations</li><li><a href="../../Utilities/General/H_index" class="code" title="iced = H_index (Model,ElemData)">H_index</a>	cell array of indices into structure arrays for continuous element deformations</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis" class="code" title="[lamdac,Qc,DUf,DVpl] = PlasticAnalysis (Model,ElemData,Loading,LPOpt)">PlasticAnalysis</a>	collapse load factor, basic forces, and collapse mechanism by plastic analysis</li><li><a href="../../Utilities/Plotting/Structure/Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../../Utilities/Plotting/Structure/Plot_DeformedSurface" class="code" title="Plot_DeformedSurface (Model,U,MPlOpt)">Plot_DeformedSurface</a>	plots the deformed surface of 3d plate and shell models</li><li><a href="../../Utilities/Plotting/Structure/Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../../Utilities/Plotting/Structure/Plot_OpenPlasticHinges" class="code" title="Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)">Plot_OpenPlasticHinges</a>	display plastic hinge locations in original or deformed configuration</li><li><a href="../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->