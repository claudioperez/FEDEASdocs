
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Add_Action</div>

--------------------------

# `Add_Action`


## <a name="_name"></a>Purpose

performs requested action on group of elements


## <a name="_synopsis"></a>Synopsis

`Resp = Add_Action (action,Model,ElemData,State,ElemList)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ADD_ACTION performs requested action on group of elements
  RESP = ADD_ACTION (ACTION,MODEL,ELEMDATA,STATE,ELEMLIST)
  function performs requested action on group of elements in structural model
  as specified in ELEMLIST (default is all elements)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION is supplied by the user
  ACTION  = currently empty
  depending on the value of character variable ACTION the function returns information
  in data structure RESP for the structure with information in data structure MODEL;
  cell array ELEMDATA supplies the element property data 
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure RESP stands for following data structure depending on value of ACTION 
  RESP = currently empty
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STATE is a data structure with information about the current state of the structure in fields
       lamda   = row vector of current load factor(s)
       U       = global dof total displacement vector
       DU      = global dof displacement increments from last convergencey
       DDU     = global dof displacement increments from last iteration
       Udot    = global dof velocity vector
       Udotdot = global dof acceleration vector
       Kf      = structure stiffness matrix at free dofs; returned along with U under action = 'stif'
       Kfd     = structure stiffness matrix coupling free and restrained dofs
       Pr      = structure resisting force vector; returned along with U under action = 'stif' or 'forc'
       Past    = data structure of         element history variables at last convergence in cell array Elem
       Pres    = data structure of current element history variables                     in cell array Elem
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMDATA is a cell array with element property information</pre>
<!-- <div class="fragment"><pre class="comment">ADD_ACTION performs requested action on group of elements
  RESP = ADD_ACTION (ACTION,MODEL,ELEMDATA,STATE,ELEMLIST)
  function performs requested action on group of elements in structural model
  as specified in ELEMLIST (default is all elements)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION is supplied by the user
  ACTION  = currently empty
  depending on the value of character variable ACTION the function returns information
  in data structure RESP for the structure with information in data structure MODEL;
  cell array ELEMDATA supplies the element property data 
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure RESP stands for following data structure depending on value of ACTION 
  RESP = currently empty
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STATE is a data structure with information about the current state of the structure in fields
       lamda   = row vector of current load factor(s)
       U       = global dof total displacement vector
       DU      = global dof displacement increments from last convergencey
       DDU     = global dof displacement increments from last iteration
       Udot    = global dof velocity vector
       Udotdot = global dof acceleration vector
       Kf      = structure stiffness matrix at free dofs; returned along with U under action = 'stif'
       Kfd     = structure stiffness matrix coupling free and restrained dofs
       Pr      = structure resisting force vector; returned along with U under action = 'stif' or 'forc'
       Past    = data structure of         element history variables at last convergence in cell array Elem
       Pres    = data structure of current element history variables                     in cell array Elem
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMDATA is a cell array with element property information</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../Structure_Full" class="code" title="Resp = Structure_Full (action,Model,ElemData,State,ElemList)">Structure_Full</a>	performs requested action on group of elements</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->