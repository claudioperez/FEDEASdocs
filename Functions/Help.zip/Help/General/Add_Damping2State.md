
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Add_Damping2State</div>

--------------------------

# `Add_Damping2State`


## <a name="_name"></a>Purpose

setup damping matrix of structural model as field of data structure STATE


## <a name="_synopsis"></a>Synopsis

`State = Add_Damping2State (type,Model,State,zeta,mode)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ADD_DAMPING2STATE setup damping matrix of structural model as field of data structure STATE
  STATE = ADD_DAMPING2STATE (TYPE,MODEL,STATE,ZETA,MODE)
  the function sets up the structural damping matrix C as a field of data structure STATE
  the free DOF stiffness matrix is supplied in the field Kf of STATE
  and the free DOF lumped mass vector in the field Ml of MODEL;
  the damping matrix is calibrated so that the mode numbers in row vector MODE have
  the damping ratios specified in the row vector ZETA;
  the character variable TYPE should be either 'StifProp', 'Caughey' or 'Modal'
  Note: Caughey with one mode reduces to a mass proportional damping matrix and
        with two modes reduces to Rayleigh damping;
        for more than 2 modes Caughey damping works only if Ml is fully populated;
        Modal damping refers to the method of superposing modal damping matrices by
        Wilson/Penzien; reference: Chopra, Dynamics of Structures, 2nd edition, pp. 455-463</pre>
<!-- <div class="fragment"><pre class="comment">ADD_DAMPING2STATE setup damping matrix of structural model as field of data structure STATE
  STATE = ADD_DAMPING2STATE (TYPE,MODEL,STATE,ZETA,MODE)
  the function sets up the structural damping matrix C as a field of data structure STATE
  the free DOF stiffness matrix is supplied in the field Kf of STATE
  and the free DOF lumped mass vector in the field Ml of MODEL;
  the damping matrix is calibrated so that the mode numbers in row vector MODE have
  the damping ratios specified in the row vector ZETA;
  the character variable TYPE should be either 'StifProp', 'Caughey' or 'Modal'
  Note: Caughey with one mode reduces to a mass proportional damping matrix and
        with two modes reduces to Rayleigh damping;
        for more than 2 modes Caughey damping works only if Ml is fully populated;
        Modal damping refers to the method of superposing modal damping matrices by
        Wilson/Penzien; reference: Chopra, Dynamics of Structures, 2nd edition, pp. 455-463</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Create_Damping" class="code" title="C = Create_Damping (type,Kf,Ml,zeta,mode)">Create_Damping</a>	setup damping matrix of structural model</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->