
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 B_matrix</div>

--------------------------

# `B_matrix`


## <a name="_name"></a>Purpose

equilibrium matrix of structural model with 2d/3d truss and 2d frame elements


## <a name="_synopsis"></a>Synopsis

`B = B_matrix (Model)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">B_MATRIX equilibrium matrix of structural model with 2d/3d truss and 2d frame elements
  B = B_MATRIX (MODEL)
  the function forms the equilibrium matrix B for all degrees of freedom (DOFs) and
  all basic forces of the structural model specified in data structure MODEL;
  this version is limited to 2d/3d truss and 2d frame elements</pre>
<!-- <div class="fragment"><pre class="comment">B_MATRIX equilibrium matrix of structural model with 2d/3d truss and 2d frame elements
  B = B_MATRIX (MODEL)
  the function forms the equilibrium matrix B for all degrees of freedom (DOFs) and
  all basic forces of the structural model specified in data structure MODEL;
  this version is limited to 2d/3d truss and 2d frame elements</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Bbar_matrix" class="code" title="[Bbar,Bvbar,ind_x] = Bbar_matrix (Model,ElemData)">Bbar_matrix</a>	function for determining force influence matrices of structural model</li><li><a href="../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_GeneralForceMethod" class="code" title="">S_GeneralForceMethod</a>	script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis_wBx" class="code" title="[lamdac,Qc,Qx] = PlasticAnalysis_wBx (Bf,Qpl,Pref,Pcf,Options)">PlasticAnalysis_wBx</a>	collapse load factor and basic element forces by lower bound theorem of plastic analysis</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis_wLBT" class="code" title="[lamdac,Qc] = PlasticAnalysis_wLBT (Bf,Qpl,Pref,Pcf,Options)">PlasticAnalysis_wLBT</a>	collapse load factor and basic element forces by lower bound theorem of plastic analysis</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->