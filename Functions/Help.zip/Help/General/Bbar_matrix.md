
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Bbar_matrix</div>

--------------------------

# `Bbar_matrix`


## <a name="_name"></a>Purpose

function for determining force influence matrices of structural model


## <a name="_synopsis"></a>Synopsis

`[Bbar,Bvbar,ind_x] = Bbar_matrix (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BBAR_MATRIX function for determining force influence matrices of structural model
  [BBAR,BVBAR,IND_X] = BBAR_MATRIX (MODEL,ELEMDATA)
  the function determines the force influence matrix BBAR for the applied nodal forces,
  and the force influence matrix BVBAR for the initial element deformations
  of the structural model in data structure MODEL
  with element property information in cell array ELEMDATA;
  IND_X is the redundant force index vector into the basic forces of the structure;
  instead of Model and ElemData the input arguments can be the static matrix BF and
  the collection of flexibility coefficient matrices FS, respectively</pre>
<!-- <div class="fragment"><pre class="comment">BBAR_MATRIX function for determining force influence matrices of structural model
  [BBAR,BVBAR,IND_X] = BBAR_MATRIX (MODEL,ELEMDATA)
  the function determines the force influence matrix BBAR for the applied nodal forces,
  and the force influence matrix BVBAR for the initial element deformations
  of the structural model in data structure MODEL
  with element property information in cell array ELEMDATA;
  IND_X is the redundant force index vector into the basic forces of the structure;
  instead of Model and ElemData the input arguments can be the static matrix BF and
  the collection of flexibility coefficient matrices FS, respectively</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../B_matrix" class="code" title="B = B_matrix (Model)">B_matrix</a>	equilibrium matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../BbariBbarx_matrix" class="code" title="[Bbari,Bbarx,ind_x] = BbariBbarx_matrix (Bf,ind_r,ind_rng)">BbariBbarx_matrix</a>	force influence matrices of primary structure from equilibrium matrix Bf</li><li><a href="../Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../../Utilities/General/H_index" class="code" title="iced = H_index (Model,ElemData)">H_index</a>	cell array of indices into structure arrays for continuous element deformations</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->