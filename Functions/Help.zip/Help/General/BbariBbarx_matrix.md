
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 BbariBbarx_matrix</div>

--------------------------

# `BbariBbarx_matrix`


## <a name="_name"></a>Purpose

force influence matrices of primary structure from equilibrium matrix Bf


## <a name="_synopsis"></a>Synopsis

`[Bbari,Bbarx,ind_x] = BbariBbarx_matrix (Bf,ind_r,ind_rng)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BBARIBBARX_MATRIX force influence matrices of primary structure from equilibrium matrix Bf
  [BBARI,BBARX,IND_X] = BBARIBBARX_MATRIX (BF,IND_R,IND_RNG)
  the function determines the force influence matrices BBARI and BBARX
  of the primary structure from the equilibrium matrix BF;
  the optional argument IND_R specifies the index for the selected redundant basic forces;
  the optional argument IND_RNG selects the redundant basic forces among those in the group;
  BBARI is the force influence matrix for the applied forces at the free dofs,
  and BBARX is the force influence matrix for the redundant basic forces;
  IND_X is the redundant force index vector into the basic forces of the structure</pre>
<!-- <div class="fragment"><pre class="comment">BBARIBBARX_MATRIX force influence matrices of primary structure from equilibrium matrix Bf
  [BBARI,BBARX,IND_X] = BBARIBBARX_MATRIX (BF,IND_R,IND_RNG)
  the function determines the force influence matrices BBARI and BBARX
  of the primary structure from the equilibrium matrix BF;
  the optional argument IND_R specifies the index for the selected redundant basic forces;
  the optional argument IND_RNG selects the redundant basic forces among those in the group;
  BBARI is the force influence matrix for the applied forces at the free dofs,
  and BBARX is the force influence matrix for the redundant basic forces;
  IND_X is the redundant force index vector into the basic forces of the structure</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Bbar_matrix" class="code" title="[Bbar,Bvbar,ind_x] = Bbar_matrix (Model,ElemData)">Bbar_matrix</a>	function for determining force influence matrices of structural model</li><li><a href="../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../Solution_Library/Static_Analysis/Incipient_Collapse_State" class="code" title="[Qc,Uf,Vpl] = Incipient_Collapse_State (Model,ElemData,Loading)">Incipient_Collapse_State</a>	STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis_wBx" class="code" title="[lamdac,Qc,Qx] = PlasticAnalysis_wBx (Bf,Qpl,Pref,Pcf,Options)">PlasticAnalysis_wBx</a>	collapse load factor and basic element forces by lower bound theorem of plastic analysis</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->