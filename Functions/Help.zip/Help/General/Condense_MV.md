
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Condense_MV</div>

--------------------------

# `Condense_MV`


## <a name="_name"></a>Purpose

condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom


## <a name="_synopsis"></a>Synopsis

`[Kfc,Pfc] = Condense_MV (Kf,idr,Pf)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CONDENSE_MV condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom
  [KFC,PFC] = CONDENSE_MV (KF,IDR,PF)
  function condenses free dof stiffness matrix KF and applied force vector PF
  to a reduced set of dofs as specified in list or row vector IDR;
  the condensed stiffness matrix is KFC and the initial force vector is PFC</pre>
<!-- <div class="fragment"><pre class="comment">CONDENSE_MV condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom
  [KFC,PFC] = CONDENSE_MV (KF,IDR,PF)
  function condenses free dof stiffness matrix KF and applied force vector PF
  to a reduced set of dofs as specified in list or row vector IDR;
  the condensed stiffness matrix is KFC and the initial force vector is PFC</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwdirDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Material_Library/2dMaterials/InelJ2PwLH2dMat" class="code" title="MatResp = InelJ2PwLH2dMat (action,MatNo,MatData,MatState)">InelJ2PwLH2dMat</a>	inelastic 2d material with J2 plasticity under linear kinematic and isotropic hardening</li><li><a href="../../Material_Library/2dMaterials/InelPlnStrs2dMat" class="code" title="MatResp = InelPlnStrs2dMat (action,MatNo,MatData,MatState)">InelPlnStrs2dMat</a>	 inelastic material under plane stress in x-y</li><li><a href="../../Material_Library/2dMaterials/LEIso2dMat" class="code" title="MatResp = LEIso2dMat (action,MatNo,MatData,MatState)">LEIso2dMat</a>	linear elastic, isotropic 2d material model under general plane stress or strain conditions</li><li><a href="../../Material_Library/3dMaterials/Inel3dMatwConstr" class="code" title="MatResp = Inel3dMatwConstr (action,MatNo,MatData,MatState)">Inel3dMatwConstr</a>	3d inelastic material under stress constraints (condensation)</li><li><a href="../../Material_Library/3dMaterials/InelRe3dMatwConstr" class="code" title="MatResp = InelRe3dMatwConstr (action,MatNo,MatData,MatState)">InelRe3dMatwConstr</a>	3d inelastic material with smeared reinforcement under stress constraints</li><li><a href="../../Material_Library/3dMaterials/LEIsoConstr3dMat" class="code" title="MatResp = LEIsoConstr3dMat (action,MatNo,MatData,MatState)">LEIsoConstr3dMat</a>	linear elastic, isotropic 3d material model with stress or strain constraints</li><li><a href="../../Section_Library/MatSDwConstr" class="code" title="MatState = MatSDwConstr (ifib,MatName,MatData,MatState)">MatSDwConstr</a>	state determination of 3d material under constraints</li><li><a href="../../Section_Library/MatSDwDirConstr" class="code" title="MatState = MatSDwDirConstr (ifib,MatName,MatData,MatState)">MatSDwDirConstr</a>	state determination of 3d material under constraints without iterations</li><li><a href="../../Section_Library/MatSDwDirConstrPaolo" class="code" title="MatState = MatSDwDirConstr (ifib,MatName,MatData,MatState)">MatSDwDirConstrPaolo</a>	</li><li><a href="../../Section_Library/MatSDwIterConstr" class="code" title="MatState = MatSDwIterConstr (ifib,MatName,MatData,MatState)">MatSDwIterConstr</a>	state determination of 3d material under constraints with iterations</li><li><a href="../../Solution_Library/Transient_Analysis/EigenMode" class="code" title="[omega,Ueig] = EigenMode (Kf,M,nmod)">EigenMode</a>	determines eigenfrequencies and eigenmodes of structural model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->