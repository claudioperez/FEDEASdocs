
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Constrain_A_matrix</div>

--------------------------

# `Constrain_A_matrix`


## <a name="_name"></a>Purpose

constraint matrix for linear kinematic constraints


## <a name="_synopsis"></a>Synopsis

`[Ac,inddof] = Constrain_A_matrix (A,conid,itdof)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CONSTRAIN_A_MATRIX constraint matrix for linear kinematic constraints
  [AC,INDDOF] = CONSTRAIN_A_MATRIX (A,CONID,ITDOF)
  the function sets up the constraint matrix AC for structural model dofs
  from the linear constraints corresponding to rows CONID of kinematic matrix A;
  if vector ITDOF is present, it specifies dofs to be included as independent; 
  vector INDDOF returns the independent dof indices to the original set of global dofs</pre>
<!-- <div class="fragment"><pre class="comment">CONSTRAIN_A_MATRIX constraint matrix for linear kinematic constraints
  [AC,INDDOF] = CONSTRAIN_A_MATRIX (A,CONID,ITDOF)
  the function sets up the constraint matrix AC for structural model dofs
  from the linear constraints corresponding to rows CONID of kinematic matrix A;
  if vector ITDOF is present, it specifies dofs to be included as independent; 
  vector INDDOF returns the independent dof indices to the original set of global dofs</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->