
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_Damping</div>

--------------------------

# `Create_Damping`


## <a name="_name"></a>Purpose

setup damping matrix of structural model


## <a name="_synopsis"></a>Synopsis

`C = Create_Damping (type,Kf,Ml,zeta,mode)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_DAMPING setup damping matrix of structural model
  C = CREATE_DAMPING (TYPE,KF,ML,ZETA,MODE)
  function sets up damping matrix C according to character variable TYPE
  for a structure with free dof stiffness matrix KF and free dof lumped mass vector ML;
  the damping matrix is calibrated so that the mode numbers in row vector MODE have
  damping ratios as specified in row vector ZETA;
  the character variable TYPE should be either 'StifProp', 'Caughey' or 'Modal'
  Note: Caughey with one mode reduces to a mass proportional damping matrix and
        with two modes reduces to Rayleigh damping;
        for more than 2 modes Caughey damping works only if Ml is fully populated;
        Modal damping refers to the method of superposing modal damping matrices by
        Wilson/Penzien; reference: Chopra, Dynamics of Structures, 2nd edition, pp. 455-463</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_DAMPING setup damping matrix of structural model
  C = CREATE_DAMPING (TYPE,KF,ML,ZETA,MODE)
  function sets up damping matrix C according to character variable TYPE
  for a structure with free dof stiffness matrix KF and free dof lumped mass vector ML;
  the damping matrix is calibrated so that the mode numbers in row vector MODE have
  damping ratios as specified in row vector ZETA;
  the character variable TYPE should be either 'StifProp', 'Caughey' or 'Modal'
  Note: Caughey with one mode reduces to a mass proportional damping matrix and
        with two modes reduces to Rayleigh damping;
        for more than 2 modes Caughey damping works only if Ml is fully populated;
        Modal damping refers to the method of superposing modal damping matrices by
        Wilson/Penzien; reference: Chopra, Dynamics of Structures, 2nd edition, pp. 455-463</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Transient_Analysis/EigenMode" class="code" title="[omega,Ueig] = EigenMode (Kf,M,nmod)">EigenMode</a>	determines eigenfrequencies and eigenmodes of structural model</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Add_Damping2State" class="code" title="State = Add_Damping2State (type,Model,State,zeta,mode)">Add_Damping2State</a>	setup damping matrix of structural model as field of data structure STATE</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->