
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_Loading</div>

--------------------------

# `Create_Loading`


## <a name="_name"></a>Purpose

create data structure Loading with reference vector(s) for applied forces and imposed displacements


## <a name="_synopsis"></a>Synopsis

`Loading = Create_Loading (Model,Pe,Ue)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_LOADING create data structure Loading with reference vector(s) for applied forces and imposed displacements
  LOADING = CREATE_LOADING (MODEL,PE,UE)
  the function sets up the data structure LOADING with the array of applied force patterns
  at the free dofs of the model in field Pref and the array of imposed displacement patterns
  at the restrained dofs of the model in field Uref; model information is specified
  in data structure MODEL and the applied forces and imposed displacements are
  specified in arrays PE and UE, respectively;
  in arrays PE and UE rows correspond to node numbers and columns to dof direction
  Example: PE(3,:,1) = [10 0 50]; applied forces at node 3 in X,Y and Z direction for force pattern 1
           UE(5,2,3) = 0.02;      imposed displacement in Y-direction at node 5 for displacement pattern 3</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_LOADING create data structure Loading with reference vector(s) for applied forces and imposed displacements
  LOADING = CREATE_LOADING (MODEL,PE,UE)
  the function sets up the data structure LOADING with the array of applied force patterns
  at the free dofs of the model in field Pref and the array of imposed displacement patterns
  at the restrained dofs of the model in field Uref; model information is specified
  in data structure MODEL and the applied forces and imposed displacements are
  specified in arrays PE and UE, respectively;
  in arrays PE and UE rows correspond to node numbers and columns to dof direction
  Example: PE(3,:,1) = [10 0 50]; applied forces at node 3 in X,Y and Z direction for force pattern 1
           UE(5,2,3) = 0.02;      imposed displacement in Y-direction at node 5 for displacement pattern 3</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_MomCurvAnalysis" class="code" title="">S_MomCurvAnalysis</a>	script for moment-curvature analysis under constant axial force</li><li><a href="../../Solution_Library/Scripts/S_NMAnalysis" class="code" title="">S_NMAnalysis</a>	script for incremental application of N-M pair on section</li><li><a href="../../Solution_Library/Scripts/S_NMAnalysiswSepLoadHist" class="code" title="">S_NMAnalysiswSepLoadHist</a>	script for application N and M with separate load histories</li><li><a href="../../Solution_Library/Static_Analysis/MomntCurvAnalysis" class="code" title="[eHist,sHist,Post] = MomntCurvAnalysis (SecName,SecData,LoadData)">MomntCurvAnalysis</a>	moment-curvature analysis of section under constant or variable normal force</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->