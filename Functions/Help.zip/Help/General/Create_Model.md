
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_Model</div>

--------------------------

# `Create_Model`


## <a name="_name"></a>Purpose

creates data structure Model from node coordinates, connectivity and boundary conditions


## <a name="_synopsis"></a>Synopsis

`Model = Create_Model (XYZ,CON,BOUN,ElemName)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_MODEL creates data structure Model from node coordinates, connectivity and boundary conditions
  MODEL = CREATE_MODEL (XYZ,CON,BOUN,ELEMNAME)
  function creates data structure MODEL with model information from the array of
  node coordinates XYZ (rows correspond to node numbers and columns to dofs),
  the cell array of element connectivity CON (rows correspond to element numbers),
  the array of boundary conditions BOUN (rows correspond to node numbers and columns to dofs),
  and the cell array of element names ELEMNAME (rows correspond to element numbers)
  Example: XYZ  (3,:)  = [10 15 22]; coordinates of node 3
           BOUN (3,:)  = [ 1  0  1]; boundary condition code for node 3 (0=free and 1=fixed)
           CON {4}     = [ 6 7];     element 4 connects nodes 6 and 7
           ELEMNAME{4} = 'LinTruss'; element 4 is a linear elastic truss

  data structure MODEL has the following fields
  MODEL.ndm      = dimension of structural model
        nn       = number of nodes in structural model
        ne       = number of elements
        nf       = number of free degrees of freedom
        nt       = total number of degrees of freedom
        XYZ      = node coordinates, nodes are stored columnwise
        BOUN     = boundary conditions, nodes are stored columnwise
        CON      = node connectivity array
        DOF      = array with degree of freedom numbering, nodes are stored columnwise
        ndf(el)  = no of dofs/node for element el
        nen(el)  = no of nodes     for element el
        ElemName = cell array of element names</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_MODEL creates data structure Model from node coordinates, connectivity and boundary conditions
  MODEL = CREATE_MODEL (XYZ,CON,BOUN,ELEMNAME)
  function creates data structure MODEL with model information from the array of
  node coordinates XYZ (rows correspond to node numbers and columns to dofs),
  the cell array of element connectivity CON (rows correspond to element numbers),
  the array of boundary conditions BOUN (rows correspond to node numbers and columns to dofs),
  and the cell array of element names ELEMNAME (rows correspond to element numbers)
  Example: XYZ  (3,:)  = [10 15 22]; coordinates of node 3
           BOUN (3,:)  = [ 1  0  1]; boundary condition code for node 3 (0=free and 1=fixed)
           CON {4}     = [ 6 7];     element 4 connects nodes 6 and 7
           ELEMNAME{4} = 'LinTruss'; element 4 is a linear elastic truss

  data structure MODEL has the following fields
  MODEL.ndm      = dimension of structural model
        nn       = number of nodes in structural model
        ne       = number of elements
        nf       = number of free degrees of freedom
        nt       = total number of degrees of freedom
        XYZ      = node coordinates, nodes are stored columnwise
        BOUN     = boundary conditions, nodes are stored columnwise
        CON      = node connectivity array
        DOF      = array with degree of freedom numbering, nodes are stored columnwise
        ndf(el)  = no of dofs/node for element el
        nen(el)  = no of nodes     for element el
        ElemName = cell array of element names</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_MomCurvAnalysis" class="code" title="">S_MomCurvAnalysis</a>	script for moment-curvature analysis under constant axial force</li><li><a href="../../Solution_Library/Scripts/S_NMAnalysis" class="code" title="">S_NMAnalysis</a>	script for incremental application of N-M pair on section</li><li><a href="../../Solution_Library/Scripts/S_NMAnalysiswSepLoadHist" class="code" title="">S_NMAnalysiswSepLoadHist</a>	script for application N and M with separate load histories</li><li><a href="../../Solution_Library/Static_Analysis/MomntCurvAnalysis" class="code" title="[eHist,sHist,Post] = MomntCurvAnalysis (SecName,SecData,LoadData)">MomntCurvAnalysis</a>	moment-curvature analysis of section under constant or variable normal force</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->