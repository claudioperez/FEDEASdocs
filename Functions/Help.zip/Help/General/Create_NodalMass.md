
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_NodalMass</div>

--------------------------

# `Create_NodalMass`


## <a name="_name"></a>Purpose

free dof lumped mass vector for structural model


## <a name="_synopsis"></a>Synopsis

`Ml = Create_NodalMass (Model,Me)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_NODALMASS free dof lumped mass vector for structural model
  ML = CREATE_NODALMASS (MODEL,ME)
  the function sets up the free dof lumped mass vector ML for the structural model
  specified in data structure MODEL from the specified nodal lumped mass values in array ME
  in which rows correspond to node numbers and columns to dof direction
  Example: ME(5,:) = [20 20 0]; lumped mass value in X and Y at node 5; no rotary inertia</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_NODALMASS free dof lumped mass vector for structural model
  ML = CREATE_NODALMASS (MODEL,ME)
  the function sets up the free dof lumped mass vector ML for the structural model
  specified in data structure MODEL from the specified nodal lumped mass values in array ME
  in which rows correspond to node numbers and columns to dof direction
  Example: ME(5,:) = [20 20 0]; lumped mass value in X and Y at node 5; no rotary inertia</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Add_Mass2Model" class="code" title="Model = Add_Mass2Model (Model,Me,ElemData,option)">Add_Mass2Model</a>	sets up lumped or consistent mass in Model.M</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->