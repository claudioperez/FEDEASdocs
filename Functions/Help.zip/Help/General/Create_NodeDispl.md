
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_NodeDispl</div>

--------------------------

# `Create_NodeDispl`


## <a name="_name"></a>Purpose

set up reference vector of imposed displacements at restrained dofs


## <a name="_synopsis"></a>Synopsis

`Uref = Create_NodeDispl (Model,Ue)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_NODEDISPL set up reference vector of imposed displacements at restrained dofs
  UREF = CREATE_NODEDISPL (MODEL,UE)
  the function sets up the vector of imposed displacements UREF at the restrained dofs of the model;
  model information is supplied in data structure MODEL and the imposed displacements in array UE;
  in array UE rows correspond to node numbers and columns to dofs
  Example: UE(3,:) = [0.2 0.1 0.03] means imposed displacements at node 3 in X,Y and Z direction</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_NODEDISPL set up reference vector of imposed displacements at restrained dofs
  UREF = CREATE_NODEDISPL (MODEL,UE)
  the function sets up the vector of imposed displacements UREF at the restrained dofs of the model;
  model information is supplied in data structure MODEL and the imposed displacements in array UE;
  in array UE rows correspond to node numbers and columns to dofs
  Example: UE(3,:) = [0.2 0.1 0.03] means imposed displacements at node 3 in X,Y and Z direction</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->