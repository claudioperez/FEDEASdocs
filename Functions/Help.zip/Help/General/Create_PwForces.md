
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Create_PwForces</div>

--------------------------

# `Create_PwForces`


## <a name="_name"></a>Purpose

set up equivalent nodal forces due to uniform element loading w


## <a name="_synopsis"></a>Synopsis

`Pw = Create_PwForces (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_PWFORCES set up equivalent nodal forces due to uniform element loading w
  PW = CREATE_PWFORCES (MODEL,ELEMDATA)
  the function sets up the vector of equivalent nodal forces PW due to uniform element loading w;
  model information is supplied in data structure MODEL,
  and the magnitude of w is supplied for each element in field W of ELEMDATA</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_PWFORCES set up equivalent nodal forces due to uniform element loading w
  PW = CREATE_PWFORCES (MODEL,ELEMDATA)
  the function sets up the vector of equivalent nodal forces PW due to uniform element loading w;
  model information is supplied in data structure MODEL,
  and the magnitude of w is supplied for each element in field W of ELEMDATA</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li><li><a href="../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_GeneralForceMethod" class="code" title="">S_GeneralForceMethod</a>	script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->