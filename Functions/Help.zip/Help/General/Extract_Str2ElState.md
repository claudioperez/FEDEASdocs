
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Extract_Str2ElState</div>

--------------------------

# `Extract_Str2ElState`


## <a name="_name"></a>Purpose

extract element state from structure state


## <a name="_synopsis"></a>Synopsis

`ElemState = Extract_Str2ElState (el,id,State)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_STR2ELSTATE extract element state from structure state
  ELEMSTATE = EXTRACT_STR2ELSTATE(EL,ID,STATE)
  the function extracts from the data structure STATE the necessary state information
  for element EL, with id-array ID, and returns it in data structure ELEMSTATE;
  when STATE is numeric, it is assumed to represent the global dof displacement vector
  and the function extracts only the element dof displacements in ELEMSTATE.U</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_STR2ELSTATE extract element state from structure state
  ELEMSTATE = EXTRACT_STR2ELSTATE(EL,ID,STATE)
  the function extracts from the data structure STATE the necessary state information
  for element EL, with id-array ID, and returns it in data structure ELEMSTATE;
  when STATE is numeric, it is assumed to represent the global dof displacement vector
  and the function extracts only the element dof displacements in ELEMSTATE.U</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Debug_Element" class="code" title="Debug = Debug_Element (el,DebuName,Model,ElemData,State,Option)">Debug_Element</a>	</li><li><a href="../Form_StiffnessMatrix" class="code" title="">Form_StiffnessMatrix</a>	</li><li><a href="../Get_VarHist4Debug" class="code" title="">Get_VarHist4Debug</a>	</li><li><a href="../Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../Structure_Full" class="code" title="Resp = Structure_Full (action,Model,ElemData,State,ElemList)">Structure_Full</a>	performs requested action on group of elements</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->