
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Form_StiffnessMatrix</div>

--------------------------

# `Form_StiffnessMatrix`


## <a name="_name"></a>Purpose




## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"></pre>
<!-- <div class="fragment"><pre class="comment"></pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Extract_Str2ElState" class="code" title="ElemState = Extract_Str2ElState (el,id,State)">Extract_Str2ElState</a>	extract element state from structure state</li><li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->