
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Ks_matrix</div>

--------------------------

# `Ks_matrix`


## <a name="_name"></a>Purpose

block diagonal matrix of basic element stiffness matrices for structural model


## <a name="_synopsis"></a>Synopsis

`Ks = Ks_matrix (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KS_MATRIX block diagonal matrix of basic element stiffness matrices for structural model
  KS = KS_MATRIX (MODEL,ELEMDATA)
  the function sets up the block diagonal matrix of basic element stiffness matrices KS
  for the structural model specified in data structure MODEL with element property
  information in cell array ELEMDATA</pre>
<!-- <div class="fragment"><pre class="comment">KS_MATRIX block diagonal matrix of basic element stiffness matrices for structural model
  KS = KS_MATRIX (MODEL,ELEMDATA)
  the function sets up the block diagonal matrix of basic element stiffness matrices KS
  for the structural model specified in data structure MODEL with element property
  information in cell array ELEMDATA</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->