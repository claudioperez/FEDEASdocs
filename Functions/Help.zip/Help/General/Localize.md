
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Localize</div>

--------------------------

# `Localize`


## <a name="_name"></a>Purpose

returns the node coordinates and id array of element


## <a name="_synopsis"></a>Synopsis

`[xyz,id] = Localize (Model,el)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LOCALIZE returns the node coordinates and id array of element
  [XYZ,ID] = LOCALIZE (MODEL,EL)
  the function returns the node coordinates XYZ and the id array ID
  of the element with number EL for the structural model specified in data structure MODEL</pre>
<!-- <div class="fragment"><pre class="comment">LOCALIZE returns the node coordinates and id array of element
  [XYZ,ID] = LOCALIZE (MODEL,EL)
  the function returns the node coordinates XYZ and the id array ID
  of the element with number EL for the structural model specified in data structure MODEL</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../A_matrix" class="code" title="A = A_matrix (Model)">A_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../Add_Action" class="code" title="Resp = Add_Action (action,Model,ElemData,State,ElemList)">Add_Action</a>	performs requested action on group of elements</li><li><a href="../Aj_matrix" class="code" title="Aj = Aj_matrix (Model)">Aj_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../B_matrix" class="code" title="B = B_matrix (Model)">B_matrix</a>	equilibrium matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../Create_PwForces" class="code" title="Pw = Create_PwForces (Model,ElemData)">Create_PwForces</a>	set up equivalent nodal forces due to uniform element loading w</li><li><a href="../Debug_Element" class="code" title="Debug = Debug_Element (el,DebuName,Model,ElemData,State,Option)">Debug_Element</a>	</li><li><a href="../Form_StiffnessMatrix" class="code" title="">Form_StiffnessMatrix</a>	</li><li><a href="../Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../Get_VarHist4Debug" class="code" title="">Get_VarHist4Debug</a>	</li><li><a href="../Kf_matrix" class="code" title="Kf = Kf_matrix (Model,ElemData)">Kf_matrix</a>	stiffness matrix at free dofs of structural model</li><li><a href="../Ks_matrix" class="code" title="Ks = Ks_matrix (Model,ElemData)">Ks_matrix</a>	block diagonal matrix of basic element stiffness matrices for structural model</li><li><a href="../Q0_vector" class="code" title="Q0 = Q0_vector (Model,ElemData)">Q0_vector</a>	initial (fixed-end) force vector for structural model</li><li><a href="../State_of_Model" class="code" title="[Pr,Kf,Post] = State_of_Model (Model,ElemData,U)">State_of_Model</a>	path-independent state determination for structural model</li><li><a href="../Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../Structure_Full" class="code" title="Resp = Structure_Full (action,Model,ElemData,State,ElemList)">Structure_Full</a>	performs requested action on group of elements</li><li><a href="../V0_vector" class="code" title="V0 = V0_vector (Model,ElemData,Roption)">V0_vector</a>	initial element deformation vector for the structural model</li><li><a href="../../Solution_Library/Static_Analysis/Event2Event_NLAnalysis" class="code" title="[lamdah,Qh,Ufh,Vph,Iph] = Event2Event_NLAnalysis (opt,Model,ElemData,Loading,ConvPar)">Event2Event_NLAnalysis</a>	event-to-event incremental analysis with linear or P-DELTA geometry</li><li><a href="../../Solution_Library/Static_Analysis/PlasticAnalysis" class="code" title="[lamdac,Qc,DUf,DVpl] = PlasticAnalysis (Model,ElemData,Loading,LPOpt)">PlasticAnalysis</a>	collapse load factor, basic forces, and collapse mechanism by plastic analysis</li><li><a href="../../Utilities/Plotting/Elements/Get_IPVarDistr" class="code" title="Line = Get_IPVarDistr (Model,ElemData,Post,Component,ElemList,UserScale)">Get_IPVarDistr</a>	plots distribution of integration point variables of elements with sections</li><li><a href="../../Utilities/Plotting/Elements/Label_2dMoments" class="code" title="Label_2dMoments (Model,Post,ElemList,Digit,Units)">Label_2dMoments</a>	label end moment values for 2d frame elements in current window</li><li><a href="../../Utilities/Plotting/Elements/Label_AxialForces" class="code" title="Label_AxialForces (Model,Post,ElemList,Digit,Units)">Label_AxialForces</a>	label axial force values in current window</li><li><a href="../../Utilities/Plotting/Elements/Plot_2dCurvDistr" class="code" title="Plot_2dCurvDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dCurvDistr</a>	plot curvature distribution of 2d linear elastic frame elements</li><li><a href="../../Utilities/Plotting/Elements/Plot_2dMomntDistr" class="code" title="Plot_2dMomntDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dMomntDistr</a>	plots moment distribution for 2d frame elements in current window</li><li><a href="../../Utilities/Plotting/Elements/Plot_AxialForces" class="code" title="Plot_AxialForces (Model,Post,ElemList,UserScale)">Plot_AxialForces</a>	plot axial forces in current window</li><li><a href="../../Utilities/Plotting/Elements/Plot_ForcDistr" class="code" title="Plot_ForcDistr (Model,ElemData,Post,Component,ElemList,UserScale)">Plot_ForcDistr</a>	plots internal force distribution for truss and frame elements in ElemList</li><li><a href="../../Utilities/Plotting/Elements/Plot_IPVarDistr" class="code" title="LineH = Plot_IPVarDistr (Model,ElemData,Post,Component,ElemList,UserScale)">Plot_IPVarDistr</a>	plots distribution of integration point variables of elements with sections</li><li><a href="../../Utilities/Plotting/Structure/Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../../Utilities/Plotting/Structure/Plot_ElemLoading" class="code" title="Plot_ElemLoading (Model,ElemData,PlotOpt)">Plot_ElemLoading</a>	display element loading in current window</li><li><a href="../../Utilities/Plotting/Structure/Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../../Utilities/Plotting/Structure/Plot_OpenPlasticHinges" class="code" title="Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)">Plot_OpenPlasticHinges</a>	display plastic hinge locations in original or deformed configuration</li><li><a href="../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li><li><a href="../../Utilities/Plotting/Structure/Plot_Releases" class="code" title="Plot_Releases (Model,ElemData,U,PlotOpt)">Plot_Releases</a>	display element releases in current window</li><li><a href="../../Utilities/PostProcessing/Add_OpenPHIndx2Post" class="code" title="Post = Add_OpenPHIndx2Post (Model,Post)">Add_OpenPHIndx2Post</a>	add index to POST for open plastic hinges in elements</li><li><a href="../../Utilities/PostProcessing/Get_StShear" class="code" title="StShear = Get_StShear (Model,ElemData,Frame,Post,GravCol)">Get_StShear</a>	determine the story shears for moment resisting frame</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->