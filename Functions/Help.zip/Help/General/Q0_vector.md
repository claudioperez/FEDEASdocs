
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Q0_vector</div>

--------------------------

# `Q0_vector`


## <a name="_name"></a>Purpose

initial (fixed-end) force vector for structural model


## <a name="_synopsis"></a>Synopsis

`Q0 = Q0_vector (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">Q0_VECTOR initial (fixed-end) force vector for structural model
  Q0 = Q0_VECTOR (MODEL,ELEMDATA)
  the function sets up the initial (fixed-end) force vector Q0 for the structural model
  specified in data structure MODEL with element property information in cell array ELEMDATA</pre>
<!-- <div class="fragment"><pre class="comment">Q0_VECTOR initial (fixed-end) force vector for structural model
  Q0 = Q0_VECTOR (MODEL,ELEMDATA)
  the function sets up the initial (fixed-end) force vector Q0 for the structural model
  specified in data structure MODEL with element property information in cell array ELEMDATA</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li><li><a href="../../Solution_Library/Static_Analysis/Event2Event_NLAnalysis" class="code" title="[lamdah,Qh,Ufh,Vph,Iph] = Event2Event_NLAnalysis (opt,Model,ElemData,Loading,ConvPar)">Event2Event_NLAnalysis</a>	event-to-event incremental analysis with linear or P-DELTA geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->