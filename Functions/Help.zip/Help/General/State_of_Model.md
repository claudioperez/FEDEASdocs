
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 State_of_Model</div>

--------------------------

# `State_of_Model`


## <a name="_name"></a>Purpose

path-independent state determination for structural model


## <a name="_synopsis"></a>Synopsis

`[Pr,Kf,Post] = State_of_Model (Model,ElemData,U)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">STATE_OF_MODEL path-independent state determination for structural model
  [PR,KF,POST] = STATE_OF_MODEL (MODEL,ELEMDATA,U)
  the function determines the resisting force vector PR at all dofs, and the stiffness matrix KF
  at the free dofs of the structural model specified in data structure MODEL;
  since PR and KF depend on the displacement values U at the model dofs, the latter
  are supplied as input argument along with element property information in cell array ELEMDATA;
  the function also returns element post-processing information in data structure POST</pre>
<!-- <div class="fragment"><pre class="comment">STATE_OF_MODEL path-independent state determination for structural model
  [PR,KF,POST] = STATE_OF_MODEL (MODEL,ELEMDATA,U)
  the function determines the resisting force vector PR at all dofs, and the stiffness matrix KF
  at the free dofs of the structural model specified in data structure MODEL;
  since PR and KF depend on the displacement values U at the model dofs, the latter
  are supplied as input argument along with element property information in cell array ELEMDATA;
  the function also returns element post-processing information in data structure POST</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_LinearStep" class="code" title="">S_LinearStep</a>	basic script for linear elastic analysis step by displacement method</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->