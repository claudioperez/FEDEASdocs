
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Structure_Full</div>

--------------------------

# `Structure_Full`


## <a name="_name"></a>Purpose

performs requested action on group of elements


## <a name="_synopsis"></a>Synopsis

`Resp = Structure_Full (action,Model,ElemData,State,ElemList)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">STRUCTURE performs requested action on group of elements
  RESP = STRUCTURE (ACTION,MODEL,ELEMDATA,STATE,ELEMLIST)
  function performs requested action on group of elements in structural model
  as specified in ELEMLIST (default is all elements)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION  = 'chec' function checks element property data for omissions and inserts default values in ELEMDATA
            'init' function initializes element history variables in fields Past and Pres of STATE
            'forc' function returns structure resisting force vector in STATE
            'stif' function returns structure stiffness matrix and resisting force vector in STATE
            'mass' function returns lumped mass vector and consistent mass matrix in MASS
            'post' function returns data structure POST with post-processing information
  depending on the value of character variable ACTION the function returns information
  in data structure RESP for the structure with information in data structure MODEL;
  cell array ELEMDATA supplies the element property data 
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure RESP stands for one of the following data structures depending on the value of ACTION 
  RESP = ELEMDATA for action = 'chec'
  RESP = STATE    for action = 'init'
  RESP = STATE    for action = 'stif'
  RESP = STATE    for action = 'forc'
  RESP = MASS     for action = 'mass'
  RESP = POST     for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STATE is a data structure with information about the current state of the structure in fields
       lamda   = row vector of current load factor(s)
       U       = global dof total displacement vector
       DU      = global dof displacement increments from last convergencey
       DDU     = global dof displacement increments from last iteration
       Udot    = global dof velocity vector
       Udotdot = global dof acceleration vector
       Kf      = structure stiffness matrix at free dofs; returned along with U under action = 'stif'
       Kfd     = structure stiffness matrix coupling free and restrained dofs
       Pr      = structure resisting force vector; returned along with U under action = 'stif' or 'forc'
       Past    = data structure of         element history variables at last convergence in cell array Elem
       Pres    = data structure of current element history variables                     in cell array Elem
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   MASS is a data structure with mass information in fields:
       Ml       = lumped mass vector of free dofs of structural model
       Mc       = consistent mass matrix of free dofs of structural model
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   POST is a data structure with structure and element response information
        for post-processing in fields:
       lamda    = row vector of current load factor(s)
       Elem{el} = cell array with post-processing information for each element
       U        = global dof displacement vector
       Pr       = structure resisting force vector
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMDATA is a cell array with element property information</pre>
<!-- <div class="fragment"><pre class="comment">STRUCTURE performs requested action on group of elements
  RESP = STRUCTURE (ACTION,MODEL,ELEMDATA,STATE,ELEMLIST)
  function performs requested action on group of elements in structural model
  as specified in ELEMLIST (default is all elements)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION  = 'chec' function checks element property data for omissions and inserts default values in ELEMDATA
            'init' function initializes element history variables in fields Past and Pres of STATE
            'forc' function returns structure resisting force vector in STATE
            'stif' function returns structure stiffness matrix and resisting force vector in STATE
            'mass' function returns lumped mass vector and consistent mass matrix in MASS
            'post' function returns data structure POST with post-processing information
  depending on the value of character variable ACTION the function returns information
  in data structure RESP for the structure with information in data structure MODEL;
  cell array ELEMDATA supplies the element property data 
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure RESP stands for one of the following data structures depending on the value of ACTION 
  RESP = ELEMDATA for action = 'chec'
  RESP = STATE    for action = 'init'
  RESP = STATE    for action = 'stif'
  RESP = STATE    for action = 'forc'
  RESP = MASS     for action = 'mass'
  RESP = POST     for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  STATE is a data structure with information about the current state of the structure in fields
       lamda   = row vector of current load factor(s)
       U       = global dof total displacement vector
       DU      = global dof displacement increments from last convergencey
       DDU     = global dof displacement increments from last iteration
       Udot    = global dof velocity vector
       Udotdot = global dof acceleration vector
       Kf      = structure stiffness matrix at free dofs; returned along with U under action = 'stif'
       Kfd     = structure stiffness matrix coupling free and restrained dofs
       Pr      = structure resisting force vector; returned along with U under action = 'stif' or 'forc'
       Past    = data structure of         element history variables at last convergence in cell array Elem
       Pres    = data structure of current element history variables                     in cell array Elem
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   MASS is a data structure with mass information in fields:
       Ml       = lumped mass vector of free dofs of structural model
       Mc       = consistent mass matrix of free dofs of structural model
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   POST is a data structure with structure and element response information
        for post-processing in fields:
       lamda    = row vector of current load factor(s)
       Elem{el} = cell array with post-processing information for each element
       U        = global dof displacement vector
       Pr       = structure resisting force vector
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   ELEMDATA is a cell array with element property information</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Add_Action" class="code" title="Resp = Add_Action (action,Model,ElemData,State,ElemList)">Add_Action</a>	performs requested action on group of elements</li><li><a href="../Extract_Str2ElState" class="code" title="ElemState = Extract_Str2ElState (el,id,State)">Extract_Str2ElState</a>	extract element state from structure state</li><li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->