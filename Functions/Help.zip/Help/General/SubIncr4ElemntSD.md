
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 SubIncr4ElemntSD</div>

--------------------------

# `SubIncr4ElemntSD`


## <a name="_name"></a>Purpose

element displacement increment subdivision for state determination


## <a name="_synopsis"></a>Synopsis

`ElemState = SubIncr4ElemntSD (el,ElemName,xyz,ElemData,ElemState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SUBINCR4ELMNTSD element displacement increment subdivision for state determination
ELEMSTATE = SUBINCR4ELMNTSD (EL,ELEMNAME,XYZ,ELEMDATA,ELEMSTATE)
  function calls the state determination function for all elements in the structural model
  with the option of subdividing the displacement increment in case of non-convergence;
  the latter case is represented by the logical variable CONVFLAG in ELEMSTATE;
  to activate the option of element displacement increment subdivision, the variable
  SUBDIVNO must be set in the element property data structure ELEMDATA</pre>
<!-- <div class="fragment"><pre class="comment">SUBINCR4ELMNTSD element displacement increment subdivision for state determination
ELEMSTATE = SUBINCR4ELMNTSD (EL,ELEMNAME,XYZ,ELEMDATA,ELEMSTATE)
  function calls the state determination function for all elements in the structural model
  with the option of subdividing the displacement increment in case of non-convergence;
  the latter case is represented by the logical variable CONVFLAG in ELEMSTATE;
  to activate the option of element displacement increment subdivision, the variable
  SUBDIVNO must be set in the element property data structure ELEMDATA</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->