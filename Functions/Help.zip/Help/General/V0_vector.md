
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 V0_vector</div>

--------------------------

# `V0_vector`


## <a name="_name"></a>Purpose

initial element deformation vector for the structural model


## <a name="_synopsis"></a>Synopsis

`V0 = V0_vector (Model,ElemData,Roption)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">V0_VECTOR initial element deformation vector for the structural model
  V0 = V0_VECTOR (MODEL,ELEMDATA,ROPTION)
  the function sets up the initial element deformation vector V0 for the structural model
  specified in data structure MODEL with element property information in cell array ELEMDATA
  if ROPTION=0, element release information is not accounted for in setting up V0 (default=1)</pre>
<!-- <div class="fragment"><pre class="comment">V0_VECTOR initial element deformation vector for the structural model
  V0 = V0_VECTOR (MODEL,ELEMDATA,ROPTION)
  the function sets up the initial element deformation vector V0 for the structural model
  specified in data structure MODEL with element property information in cell array ELEMDATA
  if ROPTION=0, element release information is not accounted for in setting up V0 (default=1)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../Solution_Library/Scripts/S_GeneralForceMethod" class="code" title="">S_GeneralForceMethod</a>	script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf</li><li><a href="../../Utilities/PostProcessing/Complete_QV" class="code" title="[Q,Ve] = Complete_QV (Model,ElemData,Qin)">Complete_QV</a>	complete basic force QIN and element deformation vector VE with values at releases</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->