
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Coro3dKinematics</div>

--------------------------

# `Coro3dKinematics`


## <a name="_name"></a>Purpose

determine deformations and kinematic transformation matrices


## <a name="_synopsis"></a>Synopsis

`[av,ap,ar,aq,ath,v] = Coro3dKinematics (xyz,GeomData,u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CORO3DKINEMATICS determine deformations and kinematic transformation matrices
  [AV,AP,AR,AQ,ATH,V] = CORO3DKINEMATICS (XYZ,GEOMDATA,U)
  the function determines the element deformations V and the kinematic
  transformation matrices AV, AP, AR, AQ and ATH for the corotational
  formulation of nonlinear geometry for a 2-node, 3d frame element;
  U is the vector of node displacements in the global reference system
  and XYZ are the node coordinates; the data structure GEOMDATA carries
  information about joint offsets for the element</pre>
<!-- <div class="fragment"><pre class="comment">CORO3DKINEMATICS determine deformations and kinematic transformation matrices
  [AV,AP,AR,AQ,ATH,V] = CORO3DKINEMATICS (XYZ,GEOMDATA,U)
  the function determines the element deformations V and the kinematic
  transformation matrices AV, AP, AR, AQ and ATH for the corotational
  formulation of nonlinear geometry for a 2-node, 3d frame element;
  U is the vector of node displacements in the global reference system
  and XYZ are the node coordinates; the data structure GEOMDATA carries
  information about joint offsets for the element</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_3dFrm" class="code" title="[L,T] = DefGeom_3dFrm (xyz,GeomData,u)">DefGeom_3dFrm</a>	determines current length and corotational triad of 2-node, 3d frame element</li><li><a href="../Large3du2v_Frm" class="code" title="[v,vthetaI,vthetaJ] = Large3du2v_Frm (xyz,GeomData,u)">Large3du2v_Frm</a>	determine 3d frame element deformations from end displacements</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li><li><a href="../spin" class="code" title="S = spin(u)">spin</a>	determine the spin tensor of a vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../GeomTran_3dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_3dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_3dFrm</a>	kinematic matrices and deformations for a 2-node 3d frame element</li><li><a href="../kg_3dFrm" class="code" title="kg = kg_3dFrm (option,xyz,GeomData,u,q,ElLoad)">kg_3dFrm</a>	geometric stiffness matrix for 2-node 3d frame element different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->