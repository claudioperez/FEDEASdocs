
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DefGeom_2dFrm</div>

--------------------------

# `DefGeom_2dFrm`


## <a name="_name"></a>Purpose

determines current length and corotational diad of 2-node, 2d frame element


## <a name="_synopsis"></a>Synopsis

`[L,T] = DefGeom_2dFrm (xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFGEOM_2dFRM determines current length and corotational diad of 2-node, 2d frame element
  [L,T] = DEFGEOM_2dFRM (XYZ);
  the function determines the length L and the corotational diad T
  of a 2d frame element in the current configuration
  from the end node coordinates XYZ (column 1 for node i, column 2 for node j);
  the corotational diad is given in matrix T whose columns correspond to axes x and y, resp.</pre>
<!-- <div class="fragment"><pre class="comment">DEFGEOM_2dFRM determines current length and corotational diad of 2-node, 2d frame element
  [L,T] = DEFGEOM_2dFRM (XYZ);
  the function determines the length L and the corotational diad T
  of a 2d frame element in the current configuration
  from the end node coordinates XYZ (column 1 for node i, column 2 for node j);
  the corotational diad is given in matrix T whose columns correspond to axes x and y, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm_wDispIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm_wDispIntp</a>	deformed shape of 2d frame element with cubic polynomials</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvIntp</a>	deformed shape of 2d frame element from curvatures</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvShearIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvShearIntp</a>	deformed shape of 2d Timoshenko frame element</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->