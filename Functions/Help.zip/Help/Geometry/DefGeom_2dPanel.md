
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DefGeom_2dPanel</div>

--------------------------

# `DefGeom_2dPanel`


## <a name="_name"></a>Purpose

determines local coordinates and corotational triad of 4-node b/c panel element


## <a name="_synopsis"></a>Synopsis

`[xl,T] = DefGeom_2dPanel (xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFGEOM_2DPANEL determines local coordinates and corotational triad of 4-node b/c panel element
  [XL,T] = DEFGEOM_2DPANEL (XYZ);
  the function determines the local coordinates XL and the corotational triad T
  of a 4-node 2d beam-column panel element in the configuration with end node coordinates XYZ
  (column 1 for node i, column 2 for node j);
  the corotational dyad is given by the array T whose columns correspond to axes x and y</pre>
<!-- <div class="fragment"><pre class="comment">DEFGEOM_2DPANEL determines local coordinates and corotational triad of 4-node b/c panel element
  [XL,T] = DEFGEOM_2DPANEL (XYZ);
  the function determines the local coordinates XL and the corotational triad T
  of a 4-node 2d beam-column panel element in the configuration with end node coordinates XYZ
  (column 1 for node i, column 2 for node j);
  the corotational dyad is given by the array T whose columns correspond to axes x and y</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../GeomTran_2dPanel" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_2dPanel (option,xyz,u,Du,DDu)">GeomTran_2dPanel</a>	kinematic matrices and local displacements for a 4-node b/c panel element</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->