
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DefGeom_Quad</div>

--------------------------

# `DefGeom_Quad`


## <a name="_name"></a>Purpose

determines local coordinates and corotational triad of quadrilateral element


## <a name="_synopsis"></a>Synopsis

`[xl,T] = DefGeom_Quad (xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFGEOM_QUAD determines local coordinates and corotational triad of quadrilateral element
  [XL,T] = DEFGEOM_QUAD (XYZ);
  the function determines the local coordinates XL and the corotational triad T
  of a quadrilateral element in the configuration with end node coordinates XYZ
  (column 1 for node i, column 2 for node j);
  the corotational triad is given by matrix T whose columns correspond to axes x,y,z resp.</pre>
<!-- <div class="fragment"><pre class="comment">DEFGEOM_QUAD determines local coordinates and corotational triad of quadrilateral element
  [XL,T] = DEFGEOM_QUAD (XYZ);
  the function determines the local coordinates XL and the corotational triad T
  of a quadrilateral element in the configuration with end node coordinates XYZ
  (column 1 for node i, column 2 for node j);
  the corotational triad is given by matrix T whose columns correspond to axes x,y,z resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/BeamColPanel" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanel</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeQuad" class="code" title="ElemResp = Inel4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeReQuad" class="code" title="ElemResp = Inel4to9nodeReQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeReQuad</a>	isoparametric 4-9 node quad element with inelastic material and reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlate" class="code" title="ElemResp = LE4nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlate</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeQuad" class="code" title="ElemResp = LE4nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuad</a>	isoparametric 4-node quadrilateral element with linear elastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeQuadwIM" class="code" title="ElemResp = LE4nodeQuadwIM (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuadwIM</a>	isoparametric 4-node quad element with linear elastic material and incompatible bending modes</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinPlate" class="code" title="ElemResp = LE4to9nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinPlate</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinShell" class="code" title="ElemResp = LE4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinShell</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeQuad" class="code" title="ElemResp = LE4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with linear elastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE9nodeQuad" class="code" title="ElemResp = LE9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE9nodeQuad</a>	isoparametric 9 node quadrilateral element with linear elastic material</li><li><a href="../GeomTran_2dPanel" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_2dPanel (option,xyz,u,Du,DDu)">GeomTran_2dPanel</a>	kinematic matrices and local displacements for a 4-node b/c panel element</li><li><a href="../GeomTran_QuadMemb" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadMemb (option,xyz,u,Du,DDu)">GeomTran_QuadMemb</a>	kinematic matrices and local displacements for a quadrilateral membrane element</li><li><a href="../GeomTran_QuadPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadPlate (option,xyz,u,Du,DDu)">GeomTran_QuadPlate</a>	kinematic matrices and local displacements for a quadrilateral plate element</li><li><a href="../Large3du2ul_Quad" class="code" title="ul = Large3du2ul_Quad (xyz,u)">Large3du2ul_Quad</a>	determine the local displacements of a triangular element</li><li><a href="../kg_2dPanel" class="code" title="kg = kg_2dPanel (option,xyz,u,pl)">kg_2dPanel</a>	geometric stiffness matrix for 4-node beam-column panel element</li><li><a href="../kg_QuadMemb" class="code" title="kg = kg_QuadMemb (option,xyz,u,pl)">kg_QuadMemb</a>	geometric stiffness matrix for quadrilateral membrane element for different options</li><li><a href="../kg_QuadPlate" class="code" title="kg = kg_QuadPlate (option,xyz,u,pl)">kg_QuadPlate</a>	geometric stiffness matrix for quadrilateral plate element for different options</li><li><a href="../../Utilities/PreProcessing/Structure/Tie_3dMesh" class="code" title="[XYZ, CON] = Tie_3dMesh (blst)">Tie_3dMesh</a>	tie nodes and elements for mesh generated in separate 3d blocks</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->