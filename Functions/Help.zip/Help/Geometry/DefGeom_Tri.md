
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DefGeom_Tri</div>

--------------------------

# `DefGeom_Tri`


## <a name="_name"></a>Purpose

determines local coordinates and corotational triad of triangular element


## <a name="_synopsis"></a>Synopsis

`[xl,T]= DefGeom_Tri (xyz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DEFGEOM_TRI determines local coordinates and corotational triad of triangular element
  [XL,T] = DEFGEOM_TRI (XYZ)
  the function determines the local coordinates XL and the corotational triad T
  of a triangular element in the current configuration
  from the end node coordinates XYZ (column 1 for node i, column 2 for node j);
  the corotational triad is given in matrix T whose columns correspond to axes x,y,z resp.</pre>
<!-- <div class="fragment"><pre class="comment">DEFGEOM_TRI determines local coordinates and corotational triad of triangular element
  [XL,T] = DEFGEOM_TRI (XYZ)
  the function determines the local coordinates XL and the corotational triad T
  of a triangular element in the current configuration
  from the end node coordinates XYZ (column 1 for node i, column 2 for node j);
  the corotational triad is given in matrix T whose columns correspond to axes x,y,z resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/InelCST" class="code" title="ElemResp = InelCST (action,el_no,xyz,ElemData,ElemState)">InelCST</a>	constant strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelDKT" class="code" title="ElemResp = InelDKT (action,el_no,xyz,ElemData,ElemState)">InelDKT</a>	inelastic discrete Kirchhoff triangle for plate bending</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Linear/LECMSDKTShell" class="code" title="ElemResp = LECMSDKTShell (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending</li><li><a href="../../Element_Library/Shell_Elements/Linear/LECMSDKTShell_wDDOF" class="code" title="ElemResp = LECMSDKTShell_wDDOF (action,el_no,xyz,ElemData,ElemState)">LECMSDKTShell_wDDOF</a>	linear elastic 3-node triangle with constant mebrane strain + DK bending with drill DOF</li><li><a href="../../Element_Library/Shell_Elements/Linear/LECST" class="code" title="ElemResp = LECST (action,el_no,xyz,ElemData,ElemState)">LECST</a>	constant strain triangle with linear elastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Linear/LEDKT" class="code" title="ElemResp = LEDKT (action,el_no,xyz,ElemData,ElemState)">LEDKT</a>	discrete Kirchhoff 3-node triangle for plate bending with linear elastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LELST" class="code" title="ElemResp = LELST (action,el_no,xyz,ElemData,ElemState)">LELST</a>	linear strain triangle with linear elastic material under plane stress/strain</li><li><a href="../GeomTran_TriMemb" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriMemb (option,xyz,u,Du,DDu)">GeomTran_TriMemb</a>	kinematic matrices and local displacements for a triangular membrane element</li><li><a href="../GeomTran_TriPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriPlate (option,xyz,u,Du,DDu)">GeomTran_TriPlate</a>	kinematic matrices and local displacements for a triangular plate element</li><li><a href="../Large3du2ul_Tri" class="code" title="ul = Large3du2ul_Tri (xyz,u)">Large3du2ul_Tri</a>	determine the local displacements of a triangular element</li><li><a href="../kg_TriMemb" class="code" title="kg = kg_TriMemb (option,xyz,u,pl)">kg_TriMemb</a>	geometric stiffness matrix for triangular membrane element for different options</li><li><a href="../kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->