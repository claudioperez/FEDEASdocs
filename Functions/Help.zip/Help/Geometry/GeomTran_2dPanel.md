
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 GeomTran_2dPanel</div>

--------------------------

# `GeomTran_2dPanel`


## <a name="_name"></a>Purpose

kinematic matrices and local displacements for a 4-node b/c panel element


## <a name="_synopsis"></a>Synopsis

` [ag,ab,xl0,ul,Dul,DDul] = GeomTran_2dPanel (option,xyz,u,Du,DDu)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEOMTRAN_2DPANEL kinematic matrices and local displacements for a 4-node b/c panel element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_2DPANEL (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a 4-node beam-column panel zone element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">GEOMTRAN_2DPANEL kinematic matrices and local displacements for a 4-node b/c panel element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_2DPANEL (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a 4-node beam-column panel zone element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_2dPanel" class="code" title="[xl,T] = DefGeom_2dPanel (xyz)">DefGeom_2dPanel</a>	determines local coordinates and corotational triad of 4-node b/c panel element</li><li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/BeamColPanel" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanel</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->