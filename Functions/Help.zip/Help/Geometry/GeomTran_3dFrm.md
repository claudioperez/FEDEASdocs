
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 GeomTran_3dFrm</div>

--------------------------

# `GeomTran_3dFrm`


## <a name="_name"></a>Purpose

kinematic matrices and deformations for a 2-node 3d frame element


## <a name="_synopsis"></a>Synopsis

`[ag,bg,ab,v,Dv,DDv] = GeomTran_3dFrm (option,xyz,GeomData,u,Du,DDu)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEOMTRAN_3dFRM kinematic matrices and deformations for a 2-node 3d frame element
  [AG,BG,AB,V,DV,DDV] = GEOMTRAN_3dFRM (OPTION,XYZ,GEOMDATA,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  the static matrix BG from the basic to the global reference system, 
  and the kinematic matrix AB from the global to the local reference system
  as well as the element deformation vector V and its increments DV and DDV
  from the node displacement array U and its increments DU and DDU
  for a 2-node 3d frame element with end node coordinates XYZ;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.
  GEOMDATA is a data structure with information about rigid joint offsets in field JNTOFF
  (first column for node i, second column for node j),
  and orientation (direction cosines) of the local y-axis in vector YORNT</pre>
<!-- <div class="fragment"><pre class="comment">GEOMTRAN_3dFRM kinematic matrices and deformations for a 2-node 3d frame element
  [AG,BG,AB,V,DV,DDV] = GEOMTRAN_3dFRM (OPTION,XYZ,GEOMDATA,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  the static matrix BG from the basic to the global reference system, 
  and the kinematic matrix AB from the global to the local reference system
  as well as the element deformation vector V and its increments DV and DDV
  from the node displacement array U and its increments DU and DDU
  for a 2-node 3d frame element with end node coordinates XYZ;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.
  GEOMDATA is a data structure with information about rigid joint offsets in field JNTOFF
  (first column for node i, second column for node j),
  and orientation (direction cosines) of the local y-axis in vector YORNT</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Coro3dKinematics" class="code" title="[av,ap,ar,aq,ath,v] = Coro3dKinematics (xyz,GeomData,u)">Coro3dKinematics</a>	determine deformations and kinematic transformation matrices</li><li><a href="../DefGeom_3dFrm" class="code" title="[L,T] = DefGeom_3dFrm (xyz,GeomData,u)">DefGeom_3dFrm</a>	determines current length and corotational triad of 2-node, 3d frame element</li><li><a href="../Large3du2v_Frm" class="code" title="[v,vthetaI,vthetaJ] = Large3du2v_Frm (xyz,GeomData,u)">Large3du2v_Frm</a>	determine 3d frame element deformations from end displacements</li><li><a href="../TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wGPNMYS" class="code" title="ElemResp = Inel3dFrm_wGPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wGPNMYS</a>	3d frame element with elastic-plastic hardening axial-flexure hinges</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wLHNMYS" class="code" title="ElemResp = Inel3dFrm_wLHNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wLHNMYS</a>	3d frame element with elastic-linear hardening plastic axial-flexure hinges</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wLPPNMYS" class="code" title="ElemResp = Inel3dFrm_wLPPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wLPPNMYS</a>	= INEL3dFRM_wLPPNMYS (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape3dFrm_wCurvShearIntp" class="code" title="[XYZd,xyzd] = DeformShape3dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape3dFrm_wCurvShearIntp</a>	deformed shape of 3d Timoshenko frame element</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwDF" class="code" title="ElemResp = Dinel3dFrm_EBwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwDF</a>	Euler-Bernoulli 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwFF" class="code" title="ElemResp = Dinel3dFrm_EBwFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwFF</a>	3d-frame element with distributed inelasticity (iterative force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwMF" class="code" title="ElemResp = Dinel3dFrm_EBwMF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwMF</a>	3d-frame element with distributed inelasticity (mixed formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwiterMFCL" class="code" title="ElemResp = Dinel3dFrm_EBwiterMFCL (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwiterMFCL</a>	3d-frame element with distributed inelasticity (direct force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF" class="code" title="ElemResp = Dinel3dFrm_TwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF_FLI" class="code" title="ElemResp = Dinel3dFrm_TwDF_FLI (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF_FLI</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwdirDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirFF" class="code" title="ElemResp = Dinel3dFrm_TwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterFF" class="code" title="ElemResp = Dinel3dFrm_TwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/Linear/LE3dFrm" class="code" title="ElemResp = LE3dFrm (action,el_no,xyz,ElemData,ElemState)">LE3dFrm</a>	3d linear frame element under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->