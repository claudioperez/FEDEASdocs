
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 GeomTran_QuadPlate</div>

--------------------------

# `GeomTran_QuadPlate`


## <a name="_name"></a>Purpose

kinematic matrices and local displacements for a quadrilateral plate element


## <a name="_synopsis"></a>Synopsis

` [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadPlate (option,xyz,u,Du,DDu)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEOMTRAN_QUADPLATE kinematic matrices and local displacements for a quadrilateral plate element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_QUADPLATE (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a quadrilateral plate element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">GEOMTRAN_QUADPLATE kinematic matrices and local displacements for a quadrilateral plate element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_QUADPLATE (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a quadrilateral plate element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../Large3du2ul_Quad" class="code" title="ul = Large3du2ul_Quad (xyz,u)">Large3du2ul_Quad</a>	determine the local displacements of a triangular element</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li><li><a href="../spin" class="code" title="S = spin(u)">spin</a>	determine the spin tensor of a vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlate" class="code" title="ElemResp = LE4nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlate</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinPlate" class="code" title="ElemResp = LE4to9nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinPlate</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinShell" class="code" title="ElemResp = LE4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinShell</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->