
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 GeomTran_TriMemb</div>

--------------------------

# `GeomTran_TriMemb`


## <a name="_name"></a>Purpose

kinematic matrices and local displacements for a triangular membrane element


## <a name="_synopsis"></a>Synopsis

` [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriMemb (option,xyz,u,Du,DDu)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEOMTRAN_TRIMEMB kinematic matrices and local displacements for a triangular membrane element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_TRIMEMB (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a triangular membrane element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">GEOMTRAN_TRIMEMB kinematic matrices and local displacements for a triangular membrane element
  [AG,AB,XL0,UL,DUL,DDUL] = GEOMTRAN_TRIMEMB (OPTION,XYZ,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the kinematic matrix AB from the global to the local reference system
  as well as the local coordinates XL0, and local displacements UL and increments DUL and DDUL
  from the node displacement array U and its increments DU and DDU
  for a triangular membrane element with end node coordinates XYZ;
  OPTION is a character variable with one of two values:
  'linear' and 'corotational', for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Tri" class="code" title="[xl,T]= DefGeom_Tri (xyz)">DefGeom_Tri</a>	determines local coordinates and corotational triad of triangular element</li><li><a href="../spinblk" class="code" title="S = spinblk(u)">spinblk</a>	determine the spin tensors for a group of vectors</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/InelCST" class="code" title="ElemResp = InelCST (action,el_no,xyz,ElemData,ElemState)">InelCST</a>	constant strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/InelLST" class="code" title="ElemResp = InelLST (action,el_no,xyz,ElemData,ElemState)">InelLST</a>	linear strain triangle with inelastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Linear/LECST" class="code" title="ElemResp = LECST (action,el_no,xyz,ElemData,ElemState)">LECST</a>	constant strain triangle with linear elastic material under plane stress/strain</li><li><a href="../../Element_Library/Shell_Elements/Linear/LELST" class="code" title="ElemResp = LELST (action,el_no,xyz,ElemData,ElemState)">LELST</a>	linear strain triangle with linear elastic material under plane stress/strain</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->