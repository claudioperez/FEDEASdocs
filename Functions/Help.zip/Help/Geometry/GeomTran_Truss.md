
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 GeomTran_Truss</div>

--------------------------

# `GeomTran_Truss`


## <a name="_name"></a>Purpose

kinematic matrices and deformations for a 2-node truss element


## <a name="_synopsis"></a>Synopsis

`[ag,bg,v,Dv,DDv] = GeomTran_Truss (option,xyz,u,Du,DDu)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEOMTRAN_TRUSS kinematic matrices and deformations for a 2-node truss element
  [AG,BG,V,DV,DDV] = GEOMTRAN_TRUSS (NDF,XYZ,GEOMDATA,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the static matrix BG from the basic to the global reference system 
  as well as the element deformation vector V and its increments DV and DDV
  from the end displacement vector U and its increments DU and DDU
  for a 2-node truss element with end node coordinates XYZ and NDF dofs/node;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">GEOMTRAN_TRUSS kinematic matrices and deformations for a 2-node truss element
  [AG,BG,V,DV,DDV] = GEOMTRAN_TRUSS (NDF,XYZ,GEOMDATA,U,DU,DDU)
  the function determines the kinematic matrix AG from the global to the basic reference system,
  and the static matrix BG from the basic to the global reference system 
  as well as the element deformation vector V and its increments DV and DDV
  from the end displacement vector U and its increments DU and DDU
  for a 2-node truss element with end node coordinates XYZ and NDF dofs/node;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/InelTruss" class="code" title="ElemResp = InelTruss (action,el_no,xyz,ElemData,ElemState)">InelTruss</a>	2d/3d inelastic truss element under linear or nonlinear geometry</li><li><a href="../../Element_Library/Frame_Elements/Linear/LETruss" class="code" title="ElemResp = LETruss (action,el_no,xyz,ElemData,ElemState)">LETruss</a>	2d/3d linear truss element under linear or nonlinear geometry</li><li><a href="../../Element_Library/Frame_Elements/Linear/LETrussC" class="code" title="ElemResp = LETrussC (action,el_no,xyz,ElemData,ElemState)">LETrussC</a>	2d/3d linear truss element under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->