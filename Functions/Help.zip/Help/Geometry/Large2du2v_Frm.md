
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Large2du2v_Frm</div>

--------------------------

# `Large2du2v_Frm`


## <a name="_name"></a>Purpose

determine 2d frame element deformations from end displacements


## <a name="_synopsis"></a>Synopsis

`v = Large2du2v_Frm (xyz,u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LARGE2DU2V_FRM determine 2d frame element deformations from end displacements
  V = LARGE2DU2V_FRM (XYZ,U)
  the function determines the deformations V of a 2-node, 2d frame element
  with end node coordinates XYZ under large end node displacements U</pre>
<!-- <div class="fragment"><pre class="comment">LARGE2DU2V_FRM determine 2d frame element deformations from end displacements
  V = LARGE2DU2V_FRM (XYZ,U)
  the function determines the deformations V of a 2-node, 2d frame element
  with end node coordinates XYZ under large end node displacements U</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm_wDispIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm_wDispIntp</a>	deformed shape of 2d frame element with cubic polynomials</li><li><a href="../GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->