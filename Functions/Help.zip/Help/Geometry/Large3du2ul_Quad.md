
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Large3du2ul_Quad</div>

--------------------------

# `Large3du2ul_Quad`


## <a name="_name"></a>Purpose

determine the local displacements of a triangular element


## <a name="_synopsis"></a>Synopsis

`ul = Large3du2ul_Quad (xyz,u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LARGE3DU2UL_QUAD determine the local displacements of a triangular element
  UL = LARGE3DU2UL_QUAD(XYZ,U)
  the function determines the displacements UL in the local reference system
  under the large node displacements U in the global reference system
  of a qudrilateral element with end node coordinates XYZ</pre>
<!-- <div class="fragment"><pre class="comment">LARGE3DU2UL_QUAD determine the local displacements of a triangular element
  UL = LARGE3DU2UL_QUAD(XYZ,U)
  the function determines the displacements UL in the local reference system
  under the large node displacements U in the global reference system
  of a qudrilateral element with end node coordinates XYZ</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../GeomTran_QuadPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadPlate (option,xyz,u,Du,DDu)">GeomTran_QuadPlate</a>	kinematic matrices and local displacements for a quadrilateral plate element</li><li><a href="../kg_QuadPlate" class="code" title="kg = kg_QuadPlate (option,xyz,u,pl)">kg_QuadPlate</a>	geometric stiffness matrix for quadrilateral plate element for different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->