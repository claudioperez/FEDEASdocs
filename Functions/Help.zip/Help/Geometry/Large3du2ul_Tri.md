
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Large3du2ul_Tri</div>

--------------------------

# `Large3du2ul_Tri`


## <a name="_name"></a>Purpose

determine the local displacements of a triangular element


## <a name="_synopsis"></a>Synopsis

`ul = Large3du2ul_Tri (xyz,u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LARGE3DU2UL_TRI determine the local displacements of a triangular element
  UL = LARGE3DU2UL_TRI(XYZ,U)
  the function determines the displacements UL in the local reference system
  under the large node displacements U in the global reference system
  of a triangular element with end node coordinates XYZ</pre>
<!-- <div class="fragment"><pre class="comment">LARGE3DU2UL_TRI determine the local displacements of a triangular element
  UL = LARGE3DU2UL_TRI(XYZ,U)
  the function determines the displacements UL in the local reference system
  under the large node displacements U in the global reference system
  of a triangular element with end node coordinates XYZ</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Tri" class="code" title="[xl,T]= DefGeom_Tri (xyz)">DefGeom_Tri</a>	determines local coordinates and corotational triad of triangular element</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../GeomTran_TriPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriPlate (option,xyz,u,Du,DDu)">GeomTran_TriPlate</a>	kinematic matrices and local displacements for a triangular plate element</li><li><a href="../kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->