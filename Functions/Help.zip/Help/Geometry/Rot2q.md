
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Rot2q</div>

--------------------------

# `Rot2q`


## <a name="_name"></a>Purpose

convert normalized rotation vector to quaternion representation


## <a name="_synopsis"></a>Synopsis

`q = Rot2q (theta)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ROTQ convert normalized rotation vector to quaternion representation
  Q = ROT2Q (THETA)
  the function converts the normalized rotation vector THETA to the
  normalized quaternion representation Q</pre>
<!-- <div class="fragment"><pre class="comment">ROTQ convert normalized rotation vector to quaternion representation
  Q = ROT2Q (THETA)
  the function converts the normalized rotation vector THETA to the
  normalized quaternion representation Q</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Coro3dKinematics" class="code" title="[av,ap,ar,aq,ath,v] = Coro3dKinematics (xyz,GeomData,u)">Coro3dKinematics</a>	determine deformations and kinematic transformation matrices</li><li><a href="../DefGeom_3dFrm" class="code" title="[L,T] = DefGeom_3dFrm (xyz,GeomData,u)">DefGeom_3dFrm</a>	determines current length and corotational triad of 2-node, 3d frame element</li><li><a href="../GeomTran_QuadPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadPlate (option,xyz,u,Du,DDu)">GeomTran_QuadPlate</a>	kinematic matrices and local displacements for a quadrilateral plate element</li><li><a href="../GeomTran_TriPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriPlate (option,xyz,u,Du,DDu)">GeomTran_TriPlate</a>	kinematic matrices and local displacements for a triangular plate element</li><li><a href="../Large3du2ul_Quad" class="code" title="ul = Large3du2ul_Quad (xyz,u)">Large3du2ul_Quad</a>	determine the local displacements of a triangular element</li><li><a href="../Large3du2ul_Tri" class="code" title="ul = Large3du2ul_Tri (xyz,u)">Large3du2ul_Tri</a>	determine the local displacements of a triangular element</li><li><a href="../Large3du2v_Frm" class="code" title="[v,vthetaI,vthetaJ] = Large3du2v_Frm (xyz,GeomData,u)">Large3du2v_Frm</a>	determine 3d frame element deformations from end displacements</li><li><a href="../kg_3dFrm" class="code" title="kg = kg_3dFrm (option,xyz,GeomData,u,q,ElLoad)">kg_3dFrm</a>	geometric stiffness matrix for 2-node 3d frame element different options</li><li><a href="../kg_QuadPlate" class="code" title="kg = kg_QuadPlate (option,xyz,u,pl)">kg_QuadPlate</a>	geometric stiffness matrix for quadrilateral plate element for different options</li><li><a href="../kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->