
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 TestScaleRotation</div>

--------------------------

# `TestScaleRotation`


## <a name="_name"></a>Purpose

% ------ (test by FCF 8/2015; not required for normalized quaternions)


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> % ------ (test by FCF 8/2015; not required for normalized quaternions)
 % scale rotation vectors
 nthI = norm(thI);
 if nthI&lt;1e-12
    qI = [1/2.*thI;cos(nthI/2)];
 else
    qI = [sin(nthI/2)/nthI.*thI;cos(nthI/2)];
 end
 nthJ = norm(thJ);
 if nthJ&lt;1e-12
    qJ = [1/2.*thJ;cos(nthJ/2)];
 else
    qJ = [sin(nthJ/2)/nthJ.*thJ;cos(nthJ/2)];
 end
 % ------ (test by FCF 8/2015; not required for normalized quaternions)</pre>
<!-- <div class="fragment"><pre class="comment"> % ------ (test by FCF 8/2015; not required for normalized quaternions)
 % scale rotation vectors
 nthI = norm(thI);
 if nthI&lt;1e-12
    qI = [1/2.*thI;cos(nthI/2)];
 else
    qI = [sin(nthI/2)/nthI.*thI;cos(nthI/2)];
 end
 nthJ = norm(thJ);
 if nthJ&lt;1e-12
    qJ = [1/2.*thJ;cos(nthJ/2)];
 else
    qJ = [sin(nthJ/2)/nthJ.*thJ;cos(nthJ/2)];
 end
 % ------ (test by FCF 8/2015; not required for normalized quaternions)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->