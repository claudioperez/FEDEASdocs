
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 TranJnt</div>

--------------------------

# `TranJnt`


## <a name="_name"></a>Purpose

sets up transformation matrix for finite size joints


## <a name="_synopsis"></a>Synopsis

`aj = TranJnt (JntOff)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANJNT sets up transformation matrix for finite size joints
  AJ = TRANJNT (JNTOFF)
  the function sets up the transformation matrix AJ for finite size joints of 2d and 3d frame elements;
  the rigid joint offsets at the element ends are specified in array JNTOFF
  with the first column corresponding to node i and the second column to node j</pre>
<!-- <div class="fragment"><pre class="comment">TRANJNT sets up transformation matrix for finite size joints
  AJ = TRANJNT (JNTOFF)
  the function sets up the transformation matrix AJ for finite size joints of 2d and 3d frame elements;
  the rigid joint offsets at the element ends are specified in array JNTOFF
  with the first column corresponding to node i and the second column to node j</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape2dFrm_wDispIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm_wDispIntp</a>	deformed shape of 2d frame element with cubic polynomials</li><li><a href="../../Element_Library/Frame_Elements/DeformShape3dFrm" class="code" title="[XYZd,xyzd] = DeformShape3dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape3dFrm</a>	deformed shape of linear elastic, uniform, prismatic 3d frame element</li><li><a href="../../Element_Library/Frame_Elements/DeformShape3dFrm_wDispIntp" class="code" title="[XYZd,xyzd] = DeformShape3dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape3dFrm_wDispIntp</a>	deformed shape of 3d frame element with cubic polynomials</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvIntp</a>	deformed shape of 2d frame element from curvatures</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvShearIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvShearIntp</a>	deformed shape of 2d Timoshenko frame element</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape3dFrm_wCurvIntp" class="code" title="[XYZd,xyzd] = DeformShape3dFrm_wCurvIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape3dFrm_wCurvIntp</a>	deformed shape of 3d frame element from curvatures</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/DeformShape3dFrm_wCurvShearIntp" class="code" title="[XYZd,xyzd] = DeformShape3dFrm_wCurvShearIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape3dFrm_wCurvShearIntp</a>	deformed shape of 3d Timoshenko frame element</li><li><a href="../../General/Aj_matrix" class="code" title="Aj = Aj_matrix (Model)">Aj_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li><li><a href="../GeomTran_3dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_3dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_3dFrm</a>	kinematic matrices and deformations for a 2-node 3d frame element</li><li><a href="../../Utilities/Plotting/Structure/Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../../Utilities/Plotting/Structure/Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../../Utilities/Plotting/Structure/Plot_OpenPlasticHinges" class="code" title="Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)">Plot_OpenPlasticHinges</a>	display plastic hinge locations in original or deformed configuration</li><li><a href="../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->