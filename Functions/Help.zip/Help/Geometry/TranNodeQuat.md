
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 TranNodeQuat</div>

--------------------------

# `TranNodeQuat`


## <a name="_name"></a>Purpose

transforms node quaternions and moments to rotations and moments


## <a name="_synopsis"></a>Synopsis

`[U,P] = TranNodeQuat (Model,Uq,Pq,rix)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANNODEQUAT transforms node quaternions and moments to rotations and moments
  [U,P] = TRANNODEQUAT (MODEL,UQ,PQ,RIX)
  the function transforms the node quaternions UQ and their work conjugate
  quaternion moments PQ to rotations U and work conjugate moments M;
  MODEL carries the information about the structural model and RIX is
  the index of rotation dofs at each node, which must be of length 3;
  translations and work conjugate forces in UQ and PQ return unaffected</pre>
<!-- <div class="fragment"><pre class="comment">TRANNODEQUAT transforms node quaternions and moments to rotations and moments
  [U,P] = TRANNODEQUAT (MODEL,UQ,PQ,RIX)
  the function transforms the node quaternions UQ and their work conjugate
  quaternion moments PQ to rotations U and work conjugate moments M;
  MODEL carries the information about the structural model and RIX is
  the index of rotation dofs at each node, which must be of length 3;
  translations and work conjugate forces in UQ and PQ return unaffected</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../spin" class="code" title="S = spin(u)">spin</a>	determine the spin tensor of a vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->