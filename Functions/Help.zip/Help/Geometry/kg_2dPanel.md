
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 kg_2dPanel</div>

--------------------------

# `kg_2dPanel`


## <a name="_name"></a>Purpose

geometric stiffness matrix for 4-node beam-column panel element


## <a name="_synopsis"></a>Synopsis

`kg = kg_2dPanel (option,xyz,u,pl)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KG_2DPANEL geometric stiffness matrix for 4-node beam-column panel element
  KG = KG_2DPANEL (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG for 4-node beam-column panel element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">KG_2DPANEL geometric stiffness matrix for 4-node beam-column panel element
  KG = KG_2DPANEL (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG for 4-node beam-column panel element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../spinblk" class="code" title="S = spinblk(u)">spinblk</a>	determine the spin tensors for a group of vectors</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->