
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 kg_3dFrm</div>

--------------------------

# `kg_3dFrm`


## <a name="_name"></a>Purpose

geometric stiffness matrix for 2-node 3d frame element different options


## <a name="_synopsis"></a>Synopsis

`kg = kg_3dFrm (option,xyz,GeomData,u,q,ElLoad)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KG_3dFRM geometric stiffness matrix for 2-node 3d frame element different options
  KG = KG_3dFRM (OPTION,XYZ,GEOMDATA,U,Q,ELLOAD)
  the function determines the geometric stiffness matrix KG of a 2-node element with end
  coordinates in array XYZ (node i corresponds to first column and node j to second);
  the geometric stiffness matrix depends on the node displacement values in array U (ndfx2)
  in the global reference system and on the basic force vector Q;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">KG_3dFRM geometric stiffness matrix for 2-node 3d frame element different options
  KG = KG_3dFRM (OPTION,XYZ,GEOMDATA,U,Q,ELLOAD)
  the function determines the geometric stiffness matrix KG of a 2-node element with end
  coordinates in array XYZ (node i corresponds to first column and node j to second);
  the geometric stiffness matrix depends on the node displacement values in array U (ndfx2)
  in the global reference system and on the basic force vector Q;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Coro3dKinematics" class="code" title="[av,ap,ar,aq,ath,v] = Coro3dKinematics (xyz,GeomData,u)">Coro3dKinematics</a>	determine deformations and kinematic transformation matrices</li><li><a href="../ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../spin" class="code" title="S = spin(u)">spin</a>	determine the spin tensor of a vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wGPNMYS" class="code" title="ElemResp = Inel3dFrm_wGPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wGPNMYS</a>	3d frame element with elastic-plastic hardening axial-flexure hinges</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wLHNMYS" class="code" title="ElemResp = Inel3dFrm_wLHNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wLHNMYS</a>	3d frame element with elastic-linear hardening plastic axial-flexure hinges</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel3dFrm_wLPPNMYS" class="code" title="ElemResp = Inel3dFrm_wLPPNMYS (action,el_no,xyz,ElemData,ElemState)">Inel3dFrm_wLPPNMYS</a>	= INEL3dFRM_wLPPNMYS (ACTION,EL_NO,XYZ,ELEMDATA,ELEMSTATE)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwDF" class="code" title="ElemResp = Dinel3dFrm_EBwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwDF</a>	Euler-Bernoulli 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwFF" class="code" title="ElemResp = Dinel3dFrm_EBwFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwFF</a>	3d-frame element with distributed inelasticity (iterative force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwMF" class="code" title="ElemResp = Dinel3dFrm_EBwMF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwMF</a>	3d-frame element with distributed inelasticity (mixed formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwiterMFCL" class="code" title="ElemResp = Dinel3dFrm_EBwiterMFCL (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwiterMFCL</a>	3d-frame element with distributed inelasticity (direct force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TWarpwiterFF" class="code" title="ElemResp = Dinel3dFrm_TWarpwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TWarpwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF" class="code" title="ElemResp = Dinel3dFrm_TwDF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwDF_FLI" class="code" title="ElemResp = Dinel3dFrm_TwDF_FLI (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwDF_FLI</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwdirDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwdirFF" class="code" title="ElemResp = Dinel3dFrm_TwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwdirFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterFF" class="code" title="ElemResp = Dinel3dFrm_TwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterFF</a>	3d-frame element with distributed inelasticity (force formulation)</li><li><a href="../../Element_Library/Frame_Elements/Linear/LE3dFrm" class="code" title="ElemResp = LE3dFrm (action,el_no,xyz,ElemData,ElemState)">LE3dFrm</a>	3d linear frame element under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->