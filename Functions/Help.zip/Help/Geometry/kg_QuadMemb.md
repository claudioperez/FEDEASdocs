
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 kg_QuadMemb</div>

--------------------------

# `kg_QuadMemb`


## <a name="_name"></a>Purpose

geometric stiffness matrix for quadrilateral membrane element for different options


## <a name="_synopsis"></a>Synopsis

`kg = kg_QuadMemb (option,xyz,u,pl)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KG_QUADMEMB geometric stiffness matrix for quadrilateral membrane element for different options
  KG = KG_QUADMEMB (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG of a quad mebrane element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">KG_QUADMEMB geometric stiffness matrix for quadrilateral membrane element for different options
  KG = KG_QUADMEMB (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG of a quad mebrane element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../spinblk" class="code" title="S = spinblk(u)">spinblk</a>	determine the spin tensors for a group of vectors</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/BeamColPanel" class="code" title="ElemResp = BeamColPanel (action,el_no,xyz,ElemData,ElemState)">BeamColPanel</a>	2, 3 or 4-node beam-column panel zone element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeQuad" class="code" title="ElemResp = Inel4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeReQuad" class="code" title="ElemResp = Inel4to9nodeReQuad (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeReQuad</a>	isoparametric 4-9 node quad element with inelastic material and reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeQuad" class="code" title="ElemResp = LE4nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuad</a>	isoparametric 4-node quadrilateral element with linear elastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeQuadwIM" class="code" title="ElemResp = LE4nodeQuadwIM (action,el_no,xyz,ElemData,ElemState)">LE4nodeQuadwIM</a>	isoparametric 4-node quad element with linear elastic material and incompatible bending modes</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeQuad" class="code" title="ElemResp = LE4to9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeQuad</a>	isoparametric 4-9 node quadrilateral element with linear elastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE9nodeQuad" class="code" title="ElemResp = LE9nodeQuad (action,el_no,xyz,ElemData,ElemState)">LE9nodeQuad</a>	isoparametric 9 node quadrilateral element with linear elastic material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->