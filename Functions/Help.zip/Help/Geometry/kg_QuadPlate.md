
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 kg_QuadPlate</div>

--------------------------

# `kg_QuadPlate`


## <a name="_name"></a>Purpose

geometric stiffness matrix for quadrilateral plate element for different options


## <a name="_synopsis"></a>Synopsis

`kg = kg_QuadPlate (option,xyz,u,pl)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KG_QUADPLATE geometric stiffness matrix for quadrilateral plate element for different options
  KG = KG_QUADPLATE (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG of a quad plate element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">KG_QUADPLATE geometric stiffness matrix for quadrilateral plate element for different options
  KG = KG_QUADPLATE (OPTION,XYZ,U,PL);
  the function determines the geometric stiffness matrix KG of a quad plate element
  with end coordinates in array XYZ (columns correspond to nodes);
  the geometric stiffness matrix depends on the node displacement values in array U (ndm x nen)
  in the global reference system and on the local nodal force vector PL; (nen = number of nodes)
  OPTION is a character variable with value equal to
  'linear' or 'corotational' for linear and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DefGeom_Quad" class="code" title="[xl,T] = DefGeom_Quad (xyz)">DefGeom_Quad</a>	determines local coordinates and corotational triad of quadrilateral element</li><li><a href="../Large3du2ul_Quad" class="code" title="ul = Large3du2ul_Quad (xyz,u)">Large3du2ul_Quad</a>	determine the local displacements of a triangular element</li><li><a href="../Rot2q" class="code" title="q = Rot2q (theta)">Rot2q</a>	convert normalized rotation vector to quaternion representation</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li><li><a href="../spin" class="code" title="S = spin(u)">spin</a>	determine the spin tensor of a vector</li><li><a href="../spinblk" class="code" title="S = spinblk(u)">spinblk</a>	determine the spin tensors for a group of vectors</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinReShellwITC" class="code" title="ElemResp = Inel4nodeMindlinReShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinReShellwITC</a>	isoparametric inelastic 4 node quad Mindlin RC layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4nodeMindlinShellwITC" class="code" title="ElemResp = Inel4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">Inel4nodeMindlinShellwITC</a>	isoparametric inelastic 4 node quad Mindlin layer shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinReShell" class="code" title="ElemResp = Inel4to9nodeMindlinReShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinReShell</a>	inelastic isoparametric 4-9 node quad Mindlin element with reinforcing layers</li><li><a href="../../Element_Library/Shell_Elements/Inelastic/Inel4to9nodeMindlinShell" class="code" title="ElemResp = Inel4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">Inel4to9nodeMindlinShell</a>	isoparametric 4-9 node quad layer shell element with inelastic material</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlate" class="code" title="ElemResp = LE4nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlate</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinPlatewITC" class="code" title="ElemResp = LE4nodeMindlinPlatewITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinPlatewITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin plate element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4nodeMindlinShellwITC" class="code" title="ElemResp = LE4nodeMindlinShellwITC (action,el_no,xyz,ElemData,ElemState)">LE4nodeMindlinShellwITC</a>	linear elastic isoparametric 4-node quadrilateral Mindlin shell element with ITC</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinPlate" class="code" title="ElemResp = LE4to9nodeMindlinPlate (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinPlate</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin plate element</li><li><a href="../../Element_Library/Shell_Elements/Linear/LE4to9nodeMindlinShell" class="code" title="ElemResp = LE4to9nodeMindlinShell (action,el_no,xyz,ElemData,ElemState)">LE4to9nodeMindlinShell</a>	linear elastic isoparametric 4-9 node quadrilateral Mindlin shell element</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->