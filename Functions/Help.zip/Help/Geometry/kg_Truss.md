
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 kg_Truss</div>

--------------------------

# `kg_Truss`


## <a name="_name"></a>Purpose

geometric stiffness matrix for 2d/3d 2-node truss element for different options


## <a name="_synopsis"></a>Synopsis

`kg = kg_Truss (option,xyz,u,q)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">KG_TRUSS geometric stiffness matrix for 2d/3d 2-node truss element for different options
  KG = KG_TRUSS (OPTION,XYZ,U,Q)
  the function determines the geometric stiffness matrix KG of a 2-node 2d/3d truss element
  with end coordinates in array XYZ (node i corresponds to first column and node j to second);
  the geometric stiffness matrix depends on the node displacement values in array U (ndmx2)
  in the global reference system and on the basic force vector Q;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre>
<!-- <div class="fragment"><pre class="comment">KG_TRUSS geometric stiffness matrix for 2d/3d 2-node truss element for different options
  KG = KG_TRUSS (OPTION,XYZ,U,Q)
  the function determines the geometric stiffness matrix KG of a 2-node 2d/3d truss element
  with end coordinates in array XYZ (node i corresponds to first column and node j to second);
  the geometric stiffness matrix depends on the node displacement values in array U (ndmx2)
  in the global reference system and on the basic force vector Q;
  OPTION is a character variable with one of three values:
  'linear','PDelta' and 'corotational' for linear, P-Delta and corotational geometry, resp.</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/InelTruss" class="code" title="ElemResp = InelTruss (action,el_no,xyz,ElemData,ElemState)">InelTruss</a>	2d/3d inelastic truss element under linear or nonlinear geometry</li><li><a href="../../Element_Library/Frame_Elements/Linear/LETruss" class="code" title="ElemResp = LETruss (action,el_no,xyz,ElemData,ElemState)">LETruss</a>	2d/3d linear truss element under linear or nonlinear geometry</li><li><a href="../../Element_Library/Frame_Elements/Linear/LETrussC" class="code" title="ElemResp = LETrussC (action,el_no,xyz,ElemData,ElemState)">LETrussC</a>	2d/3d linear truss element under linear or nonlinear geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->