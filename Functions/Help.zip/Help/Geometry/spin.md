
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 spin</div>

--------------------------

# `spin`


## <a name="_name"></a>Purpose

determine the spin tensor of a vector


## <a name="_synopsis"></a>Synopsis

`S = spin(u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SPIN determine the spin tensor of a vector
  S = SPIN (U)
  the function determines the spin tensor S of a vector U with three components</pre>
<!-- <div class="fragment"><pre class="comment">SPIN determine the spin tensor of a vector
  S = SPIN (U)
  the function determines the spin tensor S of a vector U with three components</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../Coro3dKinematics" class="code" title="[av,ap,ar,aq,ath,v] = Coro3dKinematics (xyz,GeomData,u)">Coro3dKinematics</a>	determine deformations and kinematic transformation matrices</li><li><a href="../GeomTran_QuadPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadPlate (option,xyz,u,Du,DDu)">GeomTran_QuadPlate</a>	kinematic matrices and local displacements for a quadrilateral plate element</li><li><a href="../GeomTran_TriPlate" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriPlate (option,xyz,u,Du,DDu)">GeomTran_TriPlate</a>	kinematic matrices and local displacements for a triangular plate element</li><li><a href="../TranNodeQuat" class="code" title="[U,P] = TranNodeQuat (Model,Uq,Pq,rix)">TranNodeQuat</a>	transforms node quaternions and moments to rotations and moments</li><li><a href="../kg_3dFrm" class="code" title="kg = kg_3dFrm (option,xyz,GeomData,u,q,ElLoad)">kg_3dFrm</a>	geometric stiffness matrix for 2-node 3d frame element different options</li><li><a href="../kg_QuadPlate" class="code" title="kg = kg_QuadPlate (option,xyz,u,pl)">kg_QuadPlate</a>	geometric stiffness matrix for quadrilateral plate element for different options</li><li><a href="../kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li><li><a href="../q2Rmat" class="code" title="R = q2Rmat (qhat)">q2Rmat</a>	determine rotation matrix from normalized quaternions</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->