
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 spinblk</div>

--------------------------

# `spinblk`


## <a name="_name"></a>Purpose

determine the spin tensors for a group of vectors


## <a name="_synopsis"></a>Synopsis

`S = spinblk(u)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SPINBLK determine the spin tensors for a group of vectors 
  S = SPINBLK (U)
  the function determines the spin tensors for a group of vectors in U;
  U must have size N=3K where K is the number of vectors
  the array S contains the spin tensors in K vertically concatenated 3x3 blocks</pre>
<!-- <div class="fragment"><pre class="comment">SPINBLK determine the spin tensors for a group of vectors 
  S = SPINBLK (U)
  the function determines the spin tensors for a group of vectors in U;
  U must have size N=3K where K is the number of vectors
  the array S contains the spin tensors in K vertically concatenated 3x3 blocks</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../GeomTran_QuadMemb" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_QuadMemb (option,xyz,u,Du,DDu)">GeomTran_QuadMemb</a>	kinematic matrices and local displacements for a quadrilateral membrane element</li><li><a href="../GeomTran_TriMemb" class="code" title=" [ag,ab,xl0,ul,Dul,DDul] = GeomTran_TriMemb (option,xyz,u,Du,DDu)">GeomTran_TriMemb</a>	kinematic matrices and local displacements for a triangular membrane element</li><li><a href="../kg_2dPanel" class="code" title="kg = kg_2dPanel (option,xyz,u,pl)">kg_2dPanel</a>	geometric stiffness matrix for 4-node beam-column panel element</li><li><a href="../kg_QuadMemb" class="code" title="kg = kg_QuadMemb (option,xyz,u,pl)">kg_QuadMemb</a>	geometric stiffness matrix for quadrilateral membrane element for different options</li><li><a href="../kg_QuadPlate" class="code" title="kg = kg_QuadPlate (option,xyz,u,pl)">kg_QuadPlate</a>	geometric stiffness matrix for quadrilateral plate element for different options</li><li><a href="../kg_TriMemb" class="code" title="kg = kg_TriMemb (option,xyz,u,pl)">kg_TriMemb</a>	geometric stiffness matrix for triangular membrane element for different options</li><li><a href="../kg_TriPlate" class="code" title="kg = kg_TriPlate (option,xyz,u,pl)">kg_TriPlate</a>	geometric stiffness matrix for triangular plate element for different options</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->