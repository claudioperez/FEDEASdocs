
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">1dMaterials</a> &gt; Gen1dMatwDmg</div>

--------------------------

# `Gen1dMatwDmg`


## <a name="_name"></a>Purpose

1d material with damage evolution of any effective stress-strain relation


## <a name="_synopsis"></a>Synopsis

`MatResp = Gen1dMatwDmg (action,MatNo,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GEN1dMATwDAMG 1d material with damage evolution of any effective stress-strain relation 
  MATRESP = GEN1dMATwDMG (ACTION,MAT_NO,MATDATA,MATSTATE)
  the function determines the current material state under total strain EPSI
  for a 1d model with damage evolution of any effective stress-strain relation;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'chec' function checks material property data for omissions and returns default values in MATDATA
           'init' function returns the material history variables in MATSTATE
           'forc' function returns the material stress (tensor) in MATSTATE
           'stif' function returns the material tangent modulus and the stress (tensor) in MATSTATE
           'post' function returns data structure MATPOST with post-processing information
  depending on the value of character variable ACTION the function returns information in data structure MATRESP
  for the material with number MAT_NO; data structure MATDATA supplies the material property data
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure MATRESP stands for one of the following data objects depending on value of ACTION
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'hist'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with material property information; it has the fields
    BMatName  = function for effective stress-strain relation (consult function help)
    Eny(1:2)  = yield energy dissipation ([ +ve -ve ])  
    epsy(1:2) = yield strain             ([ +ve -ve ])  
    Dmg       = data structure with damage variables (consult function DmgEvow1pnd)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with material response information for post-processing in fields
         eps   = total strain
         sig   = uniaxial stress
         eps_p = plastic strain (if available)
         d     = damage index ( [ +ve -ve ] )
         Etd   = tangent modulus of true stress-strain relation</pre>
<!-- <div class="fragment"><pre class="comment">GEN1dMATwDAMG 1d material with damage evolution of any effective stress-strain relation 
  MATRESP = GEN1dMATwDMG (ACTION,MAT_NO,MATDATA,MATSTATE)
  the function determines the current material state under total strain EPSI
  for a 1d model with damage evolution of any effective stress-strain relation;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'chec' function checks material property data for omissions and returns default values in MATDATA
           'init' function returns the material history variables in MATSTATE
           'forc' function returns the material stress (tensor) in MATSTATE
           'stif' function returns the material tangent modulus and the stress (tensor) in MATSTATE
           'post' function returns data structure MATPOST with post-processing information
  depending on the value of character variable ACTION the function returns information in data structure MATRESP
  for the material with number MAT_NO; data structure MATDATA supplies the material property data
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure MATRESP stands for one of the following data objects depending on value of ACTION
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'hist'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with material property information; it has the fields
    BMatName  = function for effective stress-strain relation (consult function help)
    Eny(1:2)  = yield energy dissipation ([ +ve -ve ])  
    epsy(1:2) = yield strain             ([ +ve -ve ])  
    Dmg       = data structure with damage variables (consult function DmgEvow1pnd)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with material response information for post-processing in fields
         eps   = total strain
         sig   = uniaxial stress
         eps_p = plastic strain (if available)
         d     = damage index ( [ +ve -ve ] )
         Etd   = tangent modulus of true stress-strain relation</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Material_Library/DmgEvow1pnd" class="code" title="DmgResp = DmgEvow1pnd (action,DmgData,DmgState)">DmgEvow1pnd</a>	damage model with one positive and one negative damage index</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->