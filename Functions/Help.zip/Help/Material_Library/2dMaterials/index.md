---
title: 2dMaterials
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `2dMaterials`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# 2dMaterials

<table>
<tr><td><a href="InelConPlasDmgDo2dMat">InelConPlasDmgDo2dMat</a></td><td>inelastic concrete material with damage plasticity by Do </td></tr><tr><td><a href="InelConPlasDmgTT2dMat">InelConPlasDmgTT2dMat</a></td><td>inelastic concrete material with damage plasticity by Tesser-Taledo </td></tr><tr><td><a href="InelJ2PwLH2dMat">InelJ2PwLH2dMat</a></td><td>inelastic 2d material with J2 plasticity under linear kinematic and isotropic hardening </td></tr><tr><td><a href="InelJ2PwLHPlnStrs2dMat">InelJ2PwLHPlnStrs2dMat</a></td><td>inelastic 2d material with J2 plasticity and linear hardening under plane stress </td></tr><tr><td><a href="InelPlnStrs2dMat">InelPlnStrs2dMat</a></td><td> inelastic material under plane stress in x-y </td></tr><tr><td><a href="LEIso2dMat">LEIso2dMat</a></td><td>linear elastic, isotropic 2d material model under general plane stress or strain conditions </td></tr><tr><td><a href="LESOrth2dMat">LESOrth2dMat</a></td><td>linear elastic, isotropic 2d material model under general plane stress or strain conditions </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->