
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">3dMaterials</a> &gt; GenDiagNdMat</div>

--------------------------

# `GenDiagNdMat`


## <a name="_name"></a>Purpose

GENDIAGNDMAT


## <a name="_synopsis"></a>Synopsis

`MatResp = GenDiagNdMat (action,MatNo,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GENDIAGNDMAT 
  MATRESP = GENDIAGNDMAT (ACTION,MAT_NO,MATDATA,MATSTATE)
  Function determines the stress-strain relation for a general Nd material model
  defined assembly a series of defined material model; each material model
  is decoupled from the others.
           
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'chec' function checks material property data for omissions and returns default values in MATDATA
           'init' function returns the material history variables in MATSTATE
           'forc' function returns the material stress (tensor) in MATSTATE
           'stif' function returns the material tangent modulus and the stress (tensor) in MATSTATE
           'post' function returns data structure MATPOST with post-processing information
  depending on the value of character variable ACTION the function returns information in data structure MATRESP
  for the material with number MAT_NO; data structure MATDATA supplies the material property data
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure MATRESP stands for one of the following data objects depending on value of ACTION 
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'hist'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for action = 'data' and for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain Nx1 vector
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate Nx1 vector
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress Nx1 vector; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables

         The stiffness matrix and the stress vector are organized in this way:

               [km_1     0      0  ...     0]                 [sig_1]
               [   0  km_2      0  ...     0]                 [sig_2]
          km = [   0     0   km_3  ...     0]           sig = [sig_3]
               [ ...   ...    ...  ...   ...]                 [ ... ]
               [   0     0      0  ...  km_M]                 [sig_M]

         where M is the number of material model used to compone the
         global one.

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA contains the field &quot;Mat&quot;. This is a 1xM cell array data
          structures with material property information;
          each cell MAT{i} contains the fields required for the
          specific material model to add to the global one
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST contains the field &quot;Mat&quot;. This is a 1xM cell array data. This is 
          a 1xM cell array data structures with material response information
          for post-processing; each cell MAT{i} contains the fields
          provided by the specific material model added to the global one</pre>
<!-- <div class="fragment"><pre class="comment">GENDIAGNDMAT 
  MATRESP = GENDIAGNDMAT (ACTION,MAT_NO,MATDATA,MATSTATE)
  Function determines the stress-strain relation for a general Nd material model
  defined assembly a series of defined material model; each material model
  is decoupled from the others.
           
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  the character variable ACTION should have one of the following values
  ACTION = 'chec' function checks material property data for omissions and returns default values in MATDATA
           'init' function returns the material history variables in MATSTATE
           'forc' function returns the material stress (tensor) in MATSTATE
           'stif' function returns the material tangent modulus and the stress (tensor) in MATSTATE
           'post' function returns data structure MATPOST with post-processing information
  depending on the value of character variable ACTION the function returns information in data structure MATRESP
  for the material with number MAT_NO; data structure MATDATA supplies the material property data
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  data structure MATRESP stands for one of the following data objects depending on value of ACTION 
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'hist'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for action = 'data' and for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain Nx1 vector
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate Nx1 vector
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress Nx1 vector; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables

         The stiffness matrix and the stress vector are organized in this way:

               [km_1     0      0  ...     0]                 [sig_1]
               [   0  km_2      0  ...     0]                 [sig_2]
          km = [   0     0   km_3  ...     0]           sig = [sig_3]
               [ ...   ...    ...  ...   ...]                 [ ... ]
               [   0     0      0  ...  km_M]                 [sig_M]

         where M is the number of material model used to compone the
         global one.

  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA contains the field &quot;Mat&quot;. This is a 1xM cell array data
          structures with material property information;
          each cell MAT{i} contains the fields required for the
          specific material model to add to the global one
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST contains the field &quot;Mat&quot;. This is a 1xM cell array data. This is 
          a 1xM cell array data structures with material response information
          for post-processing; each cell MAT{i} contains the fields
          provided by the specific material model added to the global one</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->