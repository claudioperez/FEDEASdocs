
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">3dMaterials</a> &gt; Hardening</div>

--------------------------

# `Hardening`


## <a name="_name"></a>Purpose

library of hardening functions for plasticity models


## <a name="_synopsis"></a>Synopsis

`y = Hardening (Fname)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">HARDENING library of hardening functions for plasticity models</pre>
<!-- <div class="fragment"><pre class="comment">HARDENING library of hardening functions for plasticity models</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Material_Library/1dMaterials/InelGP1dMat" class="code" title="MatResp = InelGP1dMat (action,MatNo,MatData,MatState)">InelGP1dMat</a>	inelastic generalized plasticity 1d material model</li><li><a href="../InelGJ2P3dMat" class="code" title="MatResp = InelGJ2P3dMat (action,MatNo,MatData,MatState)">InelGJ2P3dMat</a>	3d generalized J2 plasticity material model</li><li><a href="../OneParamPlastDamg3dMat" class="code" title="MatResp = OneParamPlastDamg3dMat (action,MatNo,MatData,MatState)">OneParamPlastDamg3dMat</a>	3d generalized damage plasticity material model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->