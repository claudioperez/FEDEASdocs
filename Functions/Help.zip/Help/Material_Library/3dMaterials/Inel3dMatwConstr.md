
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">3dMaterials</a> &gt; Inel3dMatwConstr</div>

--------------------------

# `Inel3dMatwConstr`


## <a name="_name"></a>Purpose

3d inelastic material under stress constraints (condensation)


## <a name="_synopsis"></a>Synopsis

`MatResp = Inel3dMatwConstr (action,MatNo,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INEL3DMATwCONSTR 3d inelastic material under stress constraints (condensation)
  MATRESP = INEL3DMATwCONSTR (ACTION,MATNO,MATDATA,MATSTATE)
  the function determines the stress-strain relation for any inelastic 3d material
  under stress constraints (condensation);
  MATNO is an integer counter for identification
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in MATRESP:
  ACTION = 'chec': check material property data for omissions and assign default values
           'init': initialize material history variables
           'forc': report material stress(es)
           'stif': report material stiffness matrix and stress(es)
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure MATRESP stands for the following data object(s) for each ACTION:
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'init'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with section property information; it has the fields
     Mat3dName = name for 3d material function
     ir        = stress components to retain   (default = 1 2 4 5 6)
     ic        = stress components to condense (default = 3 for zz)
     Wrtol     = relative work tolerance for    stress constraints (default = 10-20)
     Satol     = absolute stress norm tolerance stress constraints (default = 10-6) 
     maxiter   = maximum number of iterations for satisfying stress constraints
     ConvFlag  = convergence flag for constraint iterations (true/false)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state;
           it has the following fields:
     eps    = total strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     Deps   = strain increments from last convergence
     DDeps  = strain increments from last iteration
     epsdot = strain rate tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     km     = material stiffness matrix
     sig    = stress tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     Past   = material history variables at last converged state
     Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with section response information for post-processing;
          it has the following fields:
     eps = total strain
     sig = stress (6x1)</pre>
<!-- <div class="fragment"><pre class="comment">INEL3DMATwCONSTR 3d inelastic material under stress constraints (condensation)
  MATRESP = INEL3DMATwCONSTR (ACTION,MATNO,MATDATA,MATSTATE)
  the function determines the stress-strain relation for any inelastic 3d material
  under stress constraints (condensation);
  MATNO is an integer counter for identification
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in MATRESP:
  ACTION = 'chec': check material property data for omissions and assign default values
           'init': initialize material history variables
           'forc': report material stress(es)
           'stif': report material stiffness matrix and stress(es)
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure MATRESP stands for the following data object(s) for each ACTION:
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'init'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with section property information; it has the fields
     Mat3dName = name for 3d material function
     ir        = stress components to retain   (default = 1 2 4 5 6)
     ic        = stress components to condense (default = 3 for zz)
     Wrtol     = relative work tolerance for    stress constraints (default = 10-20)
     Satol     = absolute stress norm tolerance stress constraints (default = 10-6) 
     maxiter   = maximum number of iterations for satisfying stress constraints
     ConvFlag  = convergence flag for constraint iterations (true/false)
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state;
           it has the following fields:
     eps    = total strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     Deps   = strain increments from last convergence
     DDeps  = strain increments from last iteration
     epsdot = strain rate tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     km     = material stiffness matrix
     sig    = stress tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
     Past   = material history variables at last converged state
     Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with section response information for post-processing;
          it has the following fields:
     eps = total strain
     sig = stress (6x1)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Condense_MV" class="code" title="[Kfc,Pfc] = Condense_MV (Kf,idr,Pf)">Condense_MV</a>	condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom</li><li><a href="../../../Material_Library/Condense_k" class="code" title="krr = Condense_k (k,idr,idc)">Condense_k</a>	condense matrix K to a reduced set idr of dofs by condensing out dofs idc</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->