
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">3dMaterials</a> &gt; InelDPwLH3dMat</div>

--------------------------

# `InelDPwLH3dMat`


## <a name="_name"></a>Purpose

inelastic 3d material model with Drucker-Prager plasticity and kinematic and isotropic hardening


## <a name="_synopsis"></a>Synopsis

`MatResp = InelDPwLH3dMat (action,MatNo,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INELDPwLH3DMAT inelastic 3d material model with Drucker-Prager plasticity and kinematic and isotropic hardening
  MATRESP = INELDPwLH3DMAT (ACTION,MAT_NO,MATDATA,MATSTATE)
  the function determines the stress-strain relation for an inelastic 3d material model
  based on Drucker-Prager plasticity with isotropic and kinematic hardening;
  MATNO is an integer counter for identification
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in MATRESP:
  ACTION = 'chec': check material property data for omissions and assign default values
           'init': initialize material history variables
           'forc': report material stress(es)
           'stif': report material stiffness matrix and stress(es)
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure MATRESP stands for the following data object(s) for each ACTION:
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'init'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with material property information; it has the fields
     E  = initial modulus
     nu = Poisson ratio
     ft = tensile strength
     fc = compressive strength
     r  = frictional strength parameter
     rb = plastic volume change parameter
     Hk = kinematic hardening modulus
     Hi = isotropic hardening modulus
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress tensor in 6x1 vector form; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with material response information for post-processing in fields
         eps   =         strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         sig   =         stress tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         eps_p = plastic strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23</pre>
<!-- <div class="fragment"><pre class="comment">INELDPwLH3DMAT inelastic 3d material model with Drucker-Prager plasticity and kinematic and isotropic hardening
  MATRESP = INELDPwLH3DMAT (ACTION,MAT_NO,MATDATA,MATSTATE)
  the function determines the stress-strain relation for an inelastic 3d material model
  based on Drucker-Prager plasticity with isotropic and kinematic hardening;
  MATNO is an integer counter for identification
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in MATRESP:
  ACTION = 'chec': check material property data for omissions and assign default values
           'init': initialize material history variables
           'forc': report material stress(es)
           'stif': report material stiffness matrix and stress(es)
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure MATRESP stands for the following data object(s) for each ACTION:
  MATRESP = MATDATA   for action = 'chec'
  MATRESP = MATSTATE  for action = 'init'
  MATRESP = MATSTATE  for action = 'stif'
  MATRESP = MATSTATE  for action = 'forc'
  MATRESP = MATPOST   for action = 'post'
  MATRESP is empty    for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATDATA is a data structure with material property information; it has the fields
     E  = initial modulus
     nu = Poisson ratio
     ft = tensile strength
     fc = compressive strength
     r  = frictional strength parameter
     rb = plastic volume change parameter
     Hk = kinematic hardening modulus
     Hi = isotropic hardening modulus
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATSTATE is a data structure with information about the current material state in fields
         eps    = total strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         Deps   = strain increments from last convergence
         DDeps  = strain increments from last iteration
         epsdot = strain rate tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         km     = material stiffness matrix; returned under ACTION = 'stif'
         sig    = stress tensor in 6x1 vector form; returned under ACTION = 'stif' or 'forc'
         Past   = material history variables at last converged state
         Pres   = current values of material history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  MATPOST is a data structure with material response information for post-processing in fields
         eps   =         strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         sig   =         stress tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23
         eps_p = plastic strain tensor in 6x1 vector form in the order 11, 22, 33, 12, 13, 23</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->