
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">3dMaterials</a> &gt; Vec2Tensor</div>

--------------------------

# `Vec2Tensor`


## <a name="_name"></a>Purpose

transforms vector to tensor and vice versa


## <a name="_synopsis"></a>Synopsis

`Tensor = Vec2Tensor (Vstr)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">VEC2TENSOR transforms vector to tensor and vice versa
  TENSOR = VEC2TENSOR (VSTR)
  the function transforms the stress or strain vector VSTR to the corresponding
  tensor TENSOR and vice versa; it supports vectors of length 3, 6 or 9 and 2x2 or 3x3 tensors</pre>
<!-- <div class="fragment"><pre class="comment">VEC2TENSOR transforms vector to tensor and vice versa
  TENSOR = VEC2TENSOR (VSTR)
  the function transforms the stress or strain vector VSTR to the corresponding
  tensor TENSOR and vice versa; it supports vectors of length 3, 6 or 9 and 2x2 or 3x3 tensors</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->