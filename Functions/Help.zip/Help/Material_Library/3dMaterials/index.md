---
title: 3dMaterials
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `3dMaterials`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# 3dMaterials

<table>
<tr><td><a href="GenDiagNdMat">GenDiagNdMat</a></td><td>GENDIAGNDMAT </td></tr><tr><td><a href="Hardening">Hardening</a></td><td>library of hardening functions for plasticity models </td></tr><tr><td><a href="Inel3dMatwConstr">Inel3dMatwConstr</a></td><td>3d inelastic material under stress constraints (condensation) </td></tr><tr><td><a href="InelDPwCapwLH3dMat">InelDPwCapwLH3dMat</a></td><td>inelastic 3d material model with Drucker-Prager plasticity with tension cutoff </td></tr><tr><td><a href="InelDPwLH3dMat">InelDPwLH3dMat</a></td><td>inelastic 3d material model with Drucker-Prager plasticity and kinematic and isotropic hardening </td></tr><tr><td><a href="InelGJ2P3dMat">InelGJ2P3dMat</a></td><td>3d generalized J2 plasticity material model </td></tr><tr><td><a href="InelGJ2PStrConstr3dMat">InelGJ2PStrConstr3dMat</a></td><td> 3d general plasticity J2 material under constrained stress state </td></tr><tr><td><a href="InelJ2PwLH3dMat">InelJ2PwLH3dMat</a></td><td>inelastic 3d material model with J2 plasticity and linear kinematic and isotropic hardening </td></tr><tr><td><a href="InelJ2PwLH3dto1dMat">InelJ2PwLH3dto1dMat</a></td><td>inelastic 1d response of J2 plastic material with linear kinematic and isotropic hardening </td></tr><tr><td><a href="InelJ2PwLHStrConstr3dMat">InelJ2PwLHStrConstr3dMat</a></td><td>inelastic 3d material with J2 plasticity and linear hardening under stress constraints </td></tr><tr><td><a href="InelRe3dMatwConstr">InelRe3dMatwConstr</a></td><td>3d inelastic material with smeared reinforcement under stress constraints </td></tr><tr><td><a href="LEIso3dMat">LEIso3dMat</a></td><td>linear elastic, isotropic 3d material model </td></tr><tr><td><a href="LEIsoConstr3dMat">LEIsoConstr3dMat</a></td><td>linear elastic, isotropic 3d material model with stress or strain constraints </td></tr><tr><td><a href="Mazars3dConcrete">Mazars3dConcrete</a></td><td>MAZARS3dCONCRETE </td></tr><tr><td><a href="OneParamPlastDamg3dMat">OneParamPlastDamg3dMat</a></td><td>3d generalized damage plasticity material model </td></tr><tr><td><a href="Vec2Tensor">Vec2Tensor</a></td><td>transforms vector to tensor and vice versa </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../matlab_logo.png" alt="icon name" class="icon">Development</li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->