
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Condense_k</div>

--------------------------

# `Condense_k`


## <a name="_name"></a>Purpose

condense matrix K to a reduced set idr of dofs by condensing out dofs idc


## <a name="_synopsis"></a>Synopsis

`krr = Condense_k (k,idr,idc)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CONDENSE_K condense matrix K to a reduced set idr of dofs by condensing out dofs idc
  KRR = CONDENSE_K (K,IDR,IDC)
  the function condenses the stiffness matrix K to a reduced set of dofs as specified
  in list or row vector IDR by condensing out the dofs in list or row vector IDC;
  the condensed stiffness matrix is KRR</pre>
<!-- <div class="fragment"><pre class="comment">CONDENSE_K condense matrix K to a reduced set idr of dofs by condensing out dofs idc
  KRR = CONDENSE_K (K,IDR,IDC)
  the function condenses the stiffness matrix K to a reduced set of dofs as specified
  in list or row vector IDR by condensing out the dofs in list or row vector IDC;
  the condensed stiffness matrix is KRR</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_TwiterDF_FCQ" class="code" title="ElemResp = Dinel3dFrm_TwiterDF_FCQ (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_TwiterDF_FCQ</a>	Timoshenko 3d-frame element with distributed inelasticity (displacement formulation)</li><li><a href="../../Material_Library/2dMaterials/InelJ2PwLHPlnStrs2dMat" class="code" title="MatResp = InelJ2PwLHPlnStrs2dMat (action,MatNo,MatData,MatState)">InelJ2PwLHPlnStrs2dMat</a>	inelastic 2d material with J2 plasticity and linear hardening under plane stress</li><li><a href="../../Material_Library/3dMaterials/Inel3dMatwConstr" class="code" title="MatResp = Inel3dMatwConstr (action,MatNo,MatData,MatState)">Inel3dMatwConstr</a>	3d inelastic material under stress constraints (condensation)</li><li><a href="../../Material_Library/3dMaterials/InelGJ2PStrConstr3dMat" class="code" title="MatResp = InelGJ2PStrConstr3dMat (action,MatNo,MatData,MatState)">InelGJ2PStrConstr3dMat</a>	 3d general plasticity J2 material under constrained stress state</li><li><a href="../../Material_Library/3dMaterials/InelJ2PwLHStrConstr3dMat" class="code" title="MatResp = InelJ2PwLHStrConstr3dMat (action,MatNo,MatData,MatState)">InelJ2PwLHStrConstr3dMat</a>	inelastic 3d material with J2 plasticity and linear hardening under stress constraints</li><li><a href="../../Material_Library/3dMaterials/InelRe3dMatwConstr" class="code" title="MatResp = InelRe3dMatwConstr (action,MatNo,MatData,MatState)">InelRe3dMatwConstr</a>	3d inelastic material with smeared reinforcement under stress constraints</li><li><a href="../../Section_Library/MatSDwIterConstrPaolo" class="code" title="MatState = MatSDwIterConstrPaolo (action,ifib,MatName,MatData,MatState)">MatSDwIterConstrPaolo</a>	condensation of material response</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->