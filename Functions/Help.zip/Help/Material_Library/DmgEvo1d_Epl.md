
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DmgEvo1d_Epl</div>

--------------------------

# `DmgEvo1d_Epl`


## <a name="_name"></a>Purpose

true stress and modulus determination under 1d damage evolution with plastic energy


## <a name="_synopsis"></a>Synopsis

`[sig,Etd,DmgPres] = DmgEvo1d_Epl (DmgData,DmgPast,EffState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DMGEVO1d_EPL true stress and modulus determination under 1d damage evolution with plastic energy
  [SIG,ETD,DMGPRES] = DMGEVO1d_EPL (DMGDATA,DMGPAST,EFFSTATE)
  the function determines of true stress SIG and tangent modulus ETD from the effective stress
  and modulus in the structure EFFSTATE under a 1d damage evolution rule based on plastic energy;
  it updates the damage evolution history variables in structure DMGPAST to DMGPRESS;
  the damage rule parameters are supplied in the structure DMGDATA; its parameters fields
  have two columns, the first column for +ve and second column for -ve stress
  the damage parameter fields are:
    dp    = damage rule parameters (nx2, first column for +ve, second for -ve;
            n depends on the damage rule, for statistical functions n=2, default ones(2) )
    dfun  = damage evolution function ( default = MBeta )
    Cd0   = scale factor of yield energy for damage threshold ( 1x2, default [ 1 1 ] ) 
    Cd1   = scale factor of yield energy for complete damage  ( 1x2, default [ 100 100 ] )
    Cwc   = influence factor for repeat cycles  (0=none to 1=full)( 1x2, default [ 0 0 ] )
    Ccd   = damage coupling for opposite stress (0=none to 1=full)( 1x2, default [ 1 1 ] )
    Frac  = false or true for fracture inclusion (default=false)
    psiF  = if Frac is true, energy at fracture initiation ( 1x2 )
    psiU  = if Frac is true, energy at fracture completion ( 1x2 )
    psiyt = yield energy under +ve stress (scalar)
    psiyc = yield energy under -ve stress (scalar)
  the damage evolution history variables in DMGPAST (last step) and DMGPRES (current) are
    espEx = extreme strain             values to this point ( 1x2 )
    psiEx = extreme energy dissipation values to this point ( 1x2 )
    psiP  = last energy dissipation value ( 1x2 )
    sigeP = last effective stress   value (scalar)
    d     = damage index ( 1x2 )
  the effective state structure EFFSTATE has the fields
    sige  = effective stress       (scalar)
    Et    = tangent modulus of effective stress-strain (scalar)
    E     = initial modulus of effective stress-strain (scalar)
    epsp  = current plastic strain (scalar)
    epspP = plastic strain from last step (scalar)</pre>
<!-- <div class="fragment"><pre class="comment">DMGEVO1d_EPL true stress and modulus determination under 1d damage evolution with plastic energy
  [SIG,ETD,DMGPRES] = DMGEVO1d_EPL (DMGDATA,DMGPAST,EFFSTATE)
  the function determines of true stress SIG and tangent modulus ETD from the effective stress
  and modulus in the structure EFFSTATE under a 1d damage evolution rule based on plastic energy;
  it updates the damage evolution history variables in structure DMGPAST to DMGPRESS;
  the damage rule parameters are supplied in the structure DMGDATA; its parameters fields
  have two columns, the first column for +ve and second column for -ve stress
  the damage parameter fields are:
    dp    = damage rule parameters (nx2, first column for +ve, second for -ve;
            n depends on the damage rule, for statistical functions n=2, default ones(2) )
    dfun  = damage evolution function ( default = MBeta )
    Cd0   = scale factor of yield energy for damage threshold ( 1x2, default [ 1 1 ] ) 
    Cd1   = scale factor of yield energy for complete damage  ( 1x2, default [ 100 100 ] )
    Cwc   = influence factor for repeat cycles  (0=none to 1=full)( 1x2, default [ 0 0 ] )
    Ccd   = damage coupling for opposite stress (0=none to 1=full)( 1x2, default [ 1 1 ] )
    Frac  = false or true for fracture inclusion (default=false)
    psiF  = if Frac is true, energy at fracture initiation ( 1x2 )
    psiU  = if Frac is true, energy at fracture completion ( 1x2 )
    psiyt = yield energy under +ve stress (scalar)
    psiyc = yield energy under -ve stress (scalar)
  the damage evolution history variables in DMGPAST (last step) and DMGPRES (current) are
    espEx = extreme strain             values to this point ( 1x2 )
    psiEx = extreme energy dissipation values to this point ( 1x2 )
    psiP  = last energy dissipation value ( 1x2 )
    sigeP = last effective stress   value (scalar)
    d     = damage index ( 1x2 )
  the effective state structure EFFSTATE has the fields
    sige  = effective stress       (scalar)
    Et    = tangent modulus of effective stress-strain (scalar)
    E     = initial modulus of effective stress-strain (scalar)
    epsp  = current plastic strain (scalar)
    epspP = plastic strain from last step (scalar)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->