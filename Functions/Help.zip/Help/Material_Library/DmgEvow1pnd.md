
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DmgEvow1pnd</div>

--------------------------

# `DmgEvow1pnd`


## <a name="_name"></a>Purpose

damage model with one positive and one negative damage index


## <a name="_synopsis"></a>Synopsis

`DmgResp = DmgEvow1pnd (action,DmgData,DmgState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DMGEVOw1PND damage model with one positive and one negative damage index
  DMGRESP = DMGEVOw1PND (ACTION,DMGDATA,DMGSTATE)
  the function determines the true response of a force-deformation relation of any type
  under a damage evolution rule with one positive and one negative damage index
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in DMGRESP:
  ACTION = 'chec': check damage parameters for omissions and assign default values
           'init': initialize history variables for damage evolution
           'forc': report true force
           'stif': report true force and stiffness
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure DMGRESP stands for the following data object(s) for each ACTION:
  DMGRESP = DMGDATA    for action = 'chec'
  DMGRESP = DMGSTATE   for action = 'init'
  DMGRESP = DMGSTATE   for action = 'stif'
  DMGRESP = DMGSTATE   for action = 'forc'
  DMGRESP = DMGPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  DMGDATA is a data structure with damage parameter information; it has the fields
    dFun   = damage evolution function ( default = MBeta )
    DOpt   = 'total' (for total energy) or 'plastic' for plastic energy dissipation
    dp     = damage rule parameters (nx2, first column for +ve, second for -ve;
             n depends on the damage rule, for statistical functions n=2, default ones(2) )
    Cd0    = scale factor of yield energy for damage threshold ( 1x2, default [ 1 1 ] ) 
    Cd1    = scale factor of yield energy for complete damage  ( 1x2, default [ 100 100 ] )
    Cwc    = influence factor for repeat cycles  (0=none to 1=full)( 1x2, default [ 0 0 ] )
    Ccd    = damage coupling for opposite stress (0=none to 1=full)( 1x2, default [ 1 1 ] )
    psi_d0 = enery dissipation value at initiation of damage
    psi_d1 = enery dissipation value at completion of damage 
    Frac   = false or true for fracture inclusion (default=false)
    psiF   = if Frac is true, energy at fracture initiation ( 1x2 )
    psiU   = if Frac is true, energy at fracture completion ( 1x2 )
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  DMGSTATE is a data structure with the current damage state; it has the fields
         e    = total deformation
         De   = deformation increment from last convergence
         se   = effective force (from effective force-deformation relation)
         ep   = plastic deformation (if available from effective force-deformation relation)
         epP  = plastic deformation at last convergence
         s    = true force; updated under ACTION = 'stif'
         k    = true stiffness; updated under ACTION = 'stif' or 'forc'
         Past = damage history variables at last converged state
         Pres = current damage history variables
         the history variables of the damage evolution model are
             d     = damage indices                    ( 1x2)( +ve -ve )
             psi   = energy dissipation                ( 1x2 )
             se    = last effective force   value      (scalar)
             eEx   = extreme strain             values ( 1x2 )
             psiEx = extreme energy dissipation values ( 1x2 )</pre>
<!-- <div class="fragment"><pre class="comment">DMGEVOw1PND damage model with one positive and one negative damage index
  DMGRESP = DMGEVOw1PND (ACTION,DMGDATA,DMGSTATE)
  the function determines the true response of a force-deformation relation of any type
  under a damage evolution rule with one positive and one negative damage index
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in DMGRESP:
  ACTION = 'chec': check damage parameters for omissions and assign default values
           'init': initialize history variables for damage evolution
           'forc': report true force
           'stif': report true force and stiffness
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure DMGRESP stands for the following data object(s) for each ACTION:
  DMGRESP = DMGDATA    for action = 'chec'
  DMGRESP = DMGSTATE   for action = 'init'
  DMGRESP = DMGSTATE   for action = 'stif'
  DMGRESP = DMGSTATE   for action = 'forc'
  DMGRESP = DMGPOST    for action = 'post'
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  DMGDATA is a data structure with damage parameter information; it has the fields
    dFun   = damage evolution function ( default = MBeta )
    DOpt   = 'total' (for total energy) or 'plastic' for plastic energy dissipation
    dp     = damage rule parameters (nx2, first column for +ve, second for -ve;
             n depends on the damage rule, for statistical functions n=2, default ones(2) )
    Cd0    = scale factor of yield energy for damage threshold ( 1x2, default [ 1 1 ] ) 
    Cd1    = scale factor of yield energy for complete damage  ( 1x2, default [ 100 100 ] )
    Cwc    = influence factor for repeat cycles  (0=none to 1=full)( 1x2, default [ 0 0 ] )
    Ccd    = damage coupling for opposite stress (0=none to 1=full)( 1x2, default [ 1 1 ] )
    psi_d0 = enery dissipation value at initiation of damage
    psi_d1 = enery dissipation value at completion of damage 
    Frac   = false or true for fracture inclusion (default=false)
    psiF   = if Frac is true, energy at fracture initiation ( 1x2 )
    psiU   = if Frac is true, energy at fracture completion ( 1x2 )
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  DMGSTATE is a data structure with the current damage state; it has the fields
         e    = total deformation
         De   = deformation increment from last convergence
         se   = effective force (from effective force-deformation relation)
         ep   = plastic deformation (if available from effective force-deformation relation)
         epP  = plastic deformation at last convergence
         s    = true force; updated under ACTION = 'stif'
         k    = true stiffness; updated under ACTION = 'stif' or 'forc'
         Past = damage history variables at last converged state
         Pres = current damage history variables
         the history variables of the damage evolution model are
             d     = damage indices                    ( 1x2)( +ve -ve )
             psi   = energy dissipation                ( 1x2 )
             se    = last effective force   value      (scalar)
             eEx   = extreme strain             values ( 1x2 )
             psiEx = extreme energy dissipation values ( 1x2 )</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Material_Library/1dMaterials/Gen1dMatwDmg" class="code" title="MatResp = Gen1dMatwDmg (action,MatNo,MatData,MatState)">Gen1dMatwDmg</a>	1d material with damage evolution of any effective stress-strain relation</li><li><a href="../../Section_Library/SecwMDmg" class="code" title="SecResp = SecwMDmg (action,SecNo,ndm,SecData,SecState)">SecwMDmg</a>	=========================================================================================</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->