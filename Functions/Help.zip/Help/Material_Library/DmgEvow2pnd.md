
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DmgEvow2pnd</div>

--------------------------

# `DmgEvow2pnd`


## <a name="_name"></a>Purpose

damage model with two positive and two negative damage indices with interaction


## <a name="_synopsis"></a>Synopsis

`DmgResp = DmgEvow2pnd (action,DmgData,DmgState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DMGEVOw2PND damage model with two positive and two negative damage indices with interaction</pre>
<!-- <div class="fragment"><pre class="comment">DMGEVOw2PND damage model with two positive and two negative damage indices with interaction</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Section_Library/SecwNMDmg" class="code" title="SecResp = SecwNMDmg (action,SecNo,ndm,SecData,SecState)">SecwNMDmg</a>	=========================================================================================</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->