
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DmgEvow2pnd_Old</div>

--------------------------

# `DmgEvow2pnd_Old`


## <a name="_name"></a>Purpose

% ------ function Damage4NM ---------------------------------------------------------------


## <a name="_synopsis"></a>Synopsis

`DmgResp = DmgEvow2pnd (action,DmgData,DmgState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">% ------ function Damage4NM ---------------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">% ------ function Damage4NM ---------------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../DmgLib" class="code" title="y = DmgLib (Fname)">DmgLib</a>	value and slope of damage evolution function FNAME</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->