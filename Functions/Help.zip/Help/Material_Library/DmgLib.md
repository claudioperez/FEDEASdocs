
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 DmgLib</div>

--------------------------

# `DmgLib`


## <a name="_name"></a>Purpose

value and slope of damage evolution function FNAME


## <a name="_synopsis"></a>Synopsis

`y = DmgLib (Fname)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DMGLIB value and slope of damage evolution function FNAME
  the function returns the value and slope of the damage evolution function FNAME;
  the library contains the following normalized functions for damage evolution
    None  : no damage
    MBeta : modified beta cumulative distribution with the following parameter relation
            a = dp(2), b = dp(1)*dp(2) for dp(1)&gt;1 and a = dp(2)/dp(1), b=dp(2) otherwise
    OBeta : beta cumulative distribution      with parameters dp(1) and dp(2)
    Wbl   : Weibull cumulative distribution   with parameters dp(1) and dp(2)
    Logn  : lognormal cumulative distribution with parameters dp(1) and dp(2)
    Bilin : bilinear   function with parameters dp(1)-dp(3)
    Trilin: trilinear  function with parameters dp(1)-dp(5)</pre>
<!-- <div class="fragment"><pre class="comment">DMGLIB value and slope of damage evolution function FNAME
  the function returns the value and slope of the damage evolution function FNAME;
  the library contains the following normalized functions for damage evolution
    None  : no damage
    MBeta : modified beta cumulative distribution with the following parameter relation
            a = dp(2), b = dp(1)*dp(2) for dp(1)&gt;1 and a = dp(2)/dp(1), b=dp(2) otherwise
    OBeta : beta cumulative distribution      with parameters dp(1) and dp(2)
    Wbl   : Weibull cumulative distribution   with parameters dp(1) and dp(2)
    Logn  : lognormal cumulative distribution with parameters dp(1) and dp(2)
    Bilin : bilinear   function with parameters dp(1)-dp(3)
    Trilin: trilinear  function with parameters dp(1)-dp(5)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4M" class="code" title="DmgResp = Damage4M (action,DmgData,DmgState)">Damage4M</a>	% ------ function Damage4M ----------------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4M_Alt" class="code" title="DmgResp = Damage4M_v2 (action,DmgData,DmgState)">Damage4M_Alt</a>	% ------------function Damage4M -----------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4NM" class="code" title="DmgResp = Damage4NM (action,DmgData,DmgState)">Damage4NM</a>	% ------ function Damage4NM ---------------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4NM_Old" class="code" title="DmgState = Damage4NM (DmgData,DmgState)">Damage4NM_Old</a>	% ---------- function Damage4NM -----------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4NM_Orig" class="code" title="DmgResp = Damage4NM (action,DmgData,DmgState)">Damage4NM_Orig</a>	% ------ function Damage4NM ---------------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Damage4NMnOff" class="code" title="DmgResp = Damage4NM (action,DmgData,DmgState)">Damage4NMnOff</a>	% ------ function Damage4NM ---------------------------------------------------------------</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wLHNMYS_wDmgOfs" class="code" title="ElemResp = Inel2dFrm_wLHNMYS_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wLHNMYS_wDmgOfs</a>	=========================================================================================</li><li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/Inel2dFrm_wOneComp_wDmgDo" class="code" title="ElemResp = Inel2dFrm_wOneComp_wDmgOfs (action,el_no,xyz,ElemData,ElemState)">Inel2dFrm_wOneComp_wDmgDo</a>	=========================================================================================</li><li><a href="../../Element_Library/Frame_Elements/Damage4Beam" class="code" title="DmgState = Damage4Beam (Data,DmgState)">Damage4Beam</a>	</li><li><a href="../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_wMDamg" class="code" title="ElemResp = Dinel2dFrm_wMDamg (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_wMDamg</a>	inelastic 2d frame element with damage plasticity for flexure</li><li><a href="../DmgEvo1d" class="code" title="[sig,Etd,DmgPres] = DmgEvo1d (DmgData,DmgPast,EffState)">DmgEvo1d</a>	true stress and modulus determination under 1d damage evolution with total energy</li><li><a href="../DmgEvo1d_Epl" class="code" title="[sig,Etd,DmgPres] = DmgEvo1d_Epl (DmgData,DmgPast,EffState)">DmgEvo1d_Epl</a>	true stress and modulus determination under 1d damage evolution with plastic energy</li><li><a href="../DmgEvow1pnd" class="code" title="DmgResp = DmgEvow1pnd (action,DmgData,DmgState)">DmgEvow1pnd</a>	damage model with one positive and one negative damage index</li><li><a href="../DmgEvow2pnd" class="code" title="DmgResp = DmgEvow2pnd (action,DmgData,DmgState)">DmgEvow2pnd</a>	damage model with two positive and two negative damage indices with interaction</li><li><a href="../DmgEvow2pnd_Old" class="code" title="DmgResp = DmgEvow2pnd (action,DmgData,DmgState)">DmgEvow2pnd_Old</a>	% ------ function Damage4NM ---------------------------------------------------------------</li><li><a href="../../Section_Library/DmgEvo4M" class="code" title="[EId,SecState] = DmgEvo4M (SecData,SecState,EIt)">DmgEvo4M</a>	=========================================================================================</li><li><a href="../../Section_Library/DmgEvo4NM" class="code" title="[ksd,SecState] = DmgEvo4NM (SecData,SecState,kst)">DmgEvo4NM</a>	</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->