
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 SubIncr4MatSD</div>

--------------------------

# `SubIncr4MatSD`


## <a name="_name"></a>Purpose

material strain increment subdivision for state determination


## <a name="_synopsis"></a>Synopsis

`MatState = SubIncr4MatSD (MatName,action,MatNo,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SUBINCR4MATSD material strain increment subdivision for state determination
MATSTATE = SUBINCR4MATSD (MatName,action,MatNo,MatData,MatState)
  the function calls the state determination function for an iterative material
  with possible subdivision of the strain increment depending on CONVFLAG in MATSTATE;
  the number of step subdivisions SUBDIVNO is defined in MATDATA</pre>
<!-- <div class="fragment"><pre class="comment">SUBINCR4MATSD material strain increment subdivision for state determination
MATSTATE = SUBINCR4MATSD (MatName,action,MatNo,MatData,MatState)
  the function calls the state determination function for an iterative material
  with possible subdivision of the strain increment depending on CONVFLAG in MATSTATE;
  the number of step subdivisions SUBDIVNO is defined in MATDATA</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->