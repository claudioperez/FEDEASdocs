---
title: Material Library
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../index.md"><img alt="<" border="0" src="../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Material Library`&nbsp;<img alt=">" border="0" src="../right.png"></a></td></tr></table> -->

# Material Library

<table>
<tr><td><a href="Condense_k">Condense_k</a></td><td>condense matrix K to a reduced set idr of dofs by condensing out dofs idc </td></tr><tr><td><a href="DmgEvo1d">DmgEvo1d</a></td><td>true stress and modulus determination under 1d damage evolution with total energy </td></tr><tr><td><a href="DmgEvo1d_Epl">DmgEvo1d_Epl</a></td><td>true stress and modulus determination under 1d damage evolution with plastic energy </td></tr><tr><td><a href="DmgEvow1pnd">DmgEvow1pnd</a></td><td>damage model with one positive and one negative damage index </td></tr><tr><td><a href="DmgEvow2pnd">DmgEvow2pnd</a></td><td>damage model with two positive and two negative damage indices with interaction </td></tr><tr><td><a href="DmgEvow2pnd_Old">DmgEvow2pnd_Old</a></td><td>% ------ function Damage4NM --------------------------------------------------------------- </td></tr><tr><td><a href="DmgLib">DmgLib</a></td><td>value and slope of damage evolution function FNAME </td></tr><tr><td><a href="SubIncr4MatSD">SubIncr4MatSD</a></td><td>material strain increment subdivision for state determination </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../matlab_logo.png" alt="icon name" class="icon"><a href="1dMaterials">1dMaterials</a></li><li><img src="../matlab_logo.png" alt="icon name" class="icon"><a href="2dMaterials">2dMaterials</a></li><li><img src="../matlab_logo.png" alt="icon name" class="icon"><a href="3dMaterials">3dMaterials</a></li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->