
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Extract_Sec2MatState</div>

--------------------------

# `Extract_Sec2MatState`


## <a name="_name"></a>Purpose

extract material state from section state


## <a name="_synopsis"></a>Synopsis

`MatState = Extract_Sec2MatState (m,as,SecState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EXTRACT_SEC2MATSTATE extract material state from section state
  MATSTATE = EXTRACT_SEC2MATSTATE (M,AS,SECSTATE)
  function extracts from data structure SECSTATE the necessary information
  for material point M, and returns it in data structure MATSTATE;
  it needs compatibility array AS to determine material strains from section deformations</pre>
<!-- <div class="fragment"><pre class="comment">EXTRACT_SEC2MATSTATE extract material state from section state
  MATSTATE = EXTRACT_SEC2MATSTATE (M,AS,SECSTATE)
  function extracts from data structure SECSTATE the necessary information
  for material point M, and returns it in data structure MATSTATE;
  it needs compatibility array AS to determine material strains from section deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../CompReCircSecw1dMat" class="code" title="SecResp = CompReCircSecw1dMat (action,SecNo,ndm,SecData,SecState)">CompReCircSecw1dMat</a>	response of reinforced composite circular section with uniaxial materials</li><li><a href="../HomoCircSecw1dMat" class="code" title="SecResp = HomoCircSecw1dMat (action,SecNo,ndm,SecData,SecState)">HomoCircSecw1dMat</a>	response of homogeneous circular section with uniaxial material</li><li><a href="../HomoCircSecwNdMat" class="code" title="SecResp = HomoCircSecwNdMat (action,SecNo,ndm,SecData,SecState)">HomoCircSecwNdMat</a>	response of homogeneous circular section with 1d/2d/3d materia</li><li><a href="../HomoRectSecw1dMat" class="code" title="SecResp = HomoRectSecw1dMat (action,SecNo,ndm,SecData,SecState)">HomoRectSecw1dMat</a>	response of homogeneous rectangular section with uniaxial material</li><li><a href="../HomoRectSecwNdMat" class="code" title="SecResp = HomoRectSecwNdMat (action,SecNo,ndm,SecData,SecState)">HomoRectSecwNdMat</a>	response of homogeneous rectangular section with 1d/2d/3d material</li><li><a href="../HomoWFSecw1dMat" class="code" title="SecResp = HomoWFSecw1dMat (action,SecNo,ndm,SecData,SecState)">HomoWFSecw1dMat</a>	response of homogeneous wide flange (WF) section with uniaxial material</li><li><a href="../MultRectSecw1dMat" class="code" title="SecResp = MultRectSecw1dMat (action,SecNo,ndm,SecData,SecState)">MultRectSecw1dMat</a>	response for section of rectangular patches and bars with uniaxial material</li><li><a href="../ReCircSecw1dMat" class="code" title="SecResp = ReCircSecw1dMat (action,SecNo,ndm,SecData,SecState)">ReCircSecw1dMat</a>	response of reinforced circular section with uniaxial materials</li><li><a href="../ReRectSecw1dMat" class="code" title="SecResp = ReRectSecw1dMat (action,SecNo,ndm,SecData,SecState)">ReRectSecw1dMat</a>	response of reinforced rectangular section with uniaxial materials</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->