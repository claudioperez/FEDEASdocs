
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 MatSDwConstr</div>

--------------------------

# `MatSDwConstr`


## <a name="_name"></a>Purpose

state determination of 3d material under constraints


## <a name="_synopsis"></a>Synopsis

`MatState = MatSDwConstr (ifib,MatName,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MATSDwCONSTR state determination of 3d material under constraints</pre>
<!-- <div class="fragment"><pre class="comment">MATSDwCONSTR state determination of 3d material under constraints</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../General/Condense_MV" class="code" title="[Kfc,Pfc] = Condense_MV (Kf,idr,Pf)">Condense_MV</a>	condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->