
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 MatSDwIterConstrPaolo</div>

--------------------------

# `MatSDwIterConstrPaolo`


## <a name="_name"></a>Purpose

condensation of material response


## <a name="_synopsis"></a>Synopsis

`MatState = MatSDwIterConstrPaolo (action,ifib,MatName,MatData,MatState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> iterative condensation of material response</pre>
<!-- <div class="fragment"><pre class="comment"> iterative condensation of material response</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Material_Library/Condense_k" class="code" title="krr = Condense_k (k,idr,idc)">Condense_k</a>	condense matrix K to a reduced set idr of dofs by condensing out dofs idc</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->