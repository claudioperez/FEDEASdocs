
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 ResSec_wLHNMYS</div>

--------------------------

# `ResSec_wLHNMYS`


## <a name="_name"></a>Purpose

response of stress resultant section with N-Mz interaction and linear hardening


## <a name="_synopsis"></a>Synopsis

`SecResp = ResSec_wLHNMYS (action,SecNo,ndm,SecData,SecState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RESSEC_wLHNMYS response of stress resultant section with N-Mz interaction and linear hardening   
  SECRESP = RESSEC_wLHNMYS (ACTION,SECNO,NDM,SECDATA,SECSTATE)
  the function determines the response of a section with 2 stress resultant forces,
  the axial force N and the bending moment Mz; the interaction of N-Mz is described by
  a polynomial limit surface with linear hardening
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in SECRESP:
  ACTION = 'chec': check section property data for omissions and assign default values
           'init': initialize section history variables
           'forc': report section resisting forces
           'stif': report section stiffness matrix and resisting forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure SECRESP stands for the following data object(s) for each ACTION:
  SECRESP = SECDATA    for action = 'chec'
  SECRESP = SECSTATE   for action = 'init'
  SECRESP = SECSTATE   for action = 'stif'
  SECRESP = SECSTATE   for action = 'forc'
  SECRESP = SECPOST    for action = 'post'
  SECRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Np    = plastic axial capacity
         Mp    = plastic moment capacity
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-M interaction surface is described by a polynomial with the following definition
       f(n,m) = Sum_i (ci*(n^ai)*(m^bi))
      where n = N/Np
            m = M/Mp
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if GPYSC = [ 1 2 0 ; 1 0 2 ; 3.5 2 2 ; -1 0 0 ];
                         f(p,m) = n^2 + m^2 + 3.5*n^2*m^2 - 1
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECSTATE is a data structure with information about the current section state; it has the fields
         e     = vector of total section deformations
         De    = vector of section deformation increments from last convergence
         DDe   = vector of section deformation increments from last iteration
         edot  = vector of section deformation rates
         ks    = section stiffness matrix; returned under ACTION = 'stif'
         s     = section resisting force vector; returned under ACTION = 'stif' or 'forc'
         Past  = section history variables at last converged state
         Pres  = current section history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECPOST is a data structure with section response information for post-processing; it has the fields
         e  = section deformations
         s  = section stress resultants
         ep = plastic deformations</pre>
<!-- <div class="fragment"><pre class="comment">RESSEC_wLHNMYS response of stress resultant section with N-Mz interaction and linear hardening   
  SECRESP = RESSEC_wLHNMYS (ACTION,SECNO,NDM,SECDATA,SECSTATE)
  the function determines the response of a section with 2 stress resultant forces,
  the axial force N and the bending moment Mz; the interaction of N-Mz is described by
  a polynomial limit surface with linear hardening
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in SECRESP:
  ACTION = 'chec': check section property data for omissions and assign default values
           'init': initialize section history variables
           'forc': report section resisting forces
           'stif': report section stiffness matrix and resisting forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure SECRESP stands for the following data object(s) for each ACTION:
  SECRESP = SECDATA    for action = 'chec'
  SECRESP = SECSTATE   for action = 'init'
  SECRESP = SECSTATE   for action = 'stif'
  SECRESP = SECSTATE   for action = 'forc'
  SECRESP = SECPOST    for action = 'post'
  SECRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Np    = plastic axial capacity
         Mp    = plastic moment capacity
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-M interaction surface is described by a polynomial with the following definition
       f(n,m) = Sum_i (ci*(n^ai)*(m^bi))
      where n = N/Np
            m = M/Mp
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if GPYSC = [ 1 2 0 ; 1 0 2 ; 3.5 2 2 ; -1 0 0 ];
                         f(p,m) = n^2 + m^2 + 3.5*n^2*m^2 - 1
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECSTATE is a data structure with information about the current section state; it has the fields
         e     = vector of total section deformations
         De    = vector of section deformation increments from last convergence
         DDe   = vector of section deformation increments from last iteration
         edot  = vector of section deformation rates
         ks    = section stiffness matrix; returned under ACTION = 'stif'
         s     = section resisting force vector; returned under ACTION = 'stif' or 'forc'
         Past  = section history variables at last converged state
         Pres  = current section history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECPOST is a data structure with section response information for post-processing; it has the fields
         e  = section deformations
         s  = section stress resultants
         ep = plastic deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../SD4ResSec_wLHNMYS_2YS" class="code" title="[s,ks,SecHist,ConvFlag] = SD4ResSec_wLHNMYS (SecData,e,SecHist)">SD4ResSec_wLHNMYS_2YS</a>	stress resultant section for N-M interaction with linear hardening polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->