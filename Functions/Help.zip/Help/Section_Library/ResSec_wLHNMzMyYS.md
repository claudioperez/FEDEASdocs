
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 ResSec_wLHNMzMyYS</div>

--------------------------

# `ResSec_wLHNMzMyYS`


## <a name="_name"></a>Purpose

response of stress resultant section with N-Mz-My interaction and linear hardening


## <a name="_synopsis"></a>Synopsis

`SecResp = ResSec_wLHNMzMyYS (action,SecNo,ndm,SecData,SecState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RESSEC_wLHNMzMyYS response of stress resultant section with N-Mz-My interaction and linear hardening   
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMzMyYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 3 stress resultant forces,
  the axial force N and the bending moments Mz, My about the z- and y-axis, respectively;
  the interaction of N-Mz-My is described by a polynomial limit surface with linear hardening
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in SECRESP:
  ACTION = 'chec': check section property data for omissions and assign default values
           'init': initialize section history variables
           'forc': report section resisting forces
           'stif': report section stiffness matrix and resisting forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure SECRESP stands for the following data object(s) for each ACTION:
  SECRESP = SECDATA    for action = 'chec'
  SECRESP = SECSTATE   for action = 'init'
  SECRESP = SECSTATE   for action = 'stif'
  SECRESP = SECSTATE   for action = 'forc'
  SECRESP = SECPOST    for action = 'post'
  SECRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         Iz    = moment of inertia about z-axis
         Iy    = moment of inertia about y-axis
         Np    = plastic axial capacity
         Mpz   = plastic moment capacity about z-axis
         Mpy   = plastic moment capacity about y-axis
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-Mz-My interaction surface is described by a polynomial with the following definition
       f(n,mz,my) = Sum_i (di*(n^ai)*(mz^bi)*(my^ci))
      where n   = N/Np
            mz  = Mz/Mpz
            my  = My/Mpy
        a,b,c,d = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [d1 a1 b1 c1; d2 a2 b2 c2; d3 a3 b3 c3 ; ...];
                e.g. if GPYSC = [ 1 2 0 0 ; 1 0 2 0 ; 3.5 2 2 0 ; 3 0 2 2 ; -1 0 0 0 ];
                         f(p,m) = n^2 + mz^2 + 3.5*n^2*mz^2 + 3*mz^2*my^2- 1
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECSTATE is a data structure with information about the current section state; it has the fields
         e     = vector of total section deformations
         De    = vector of section deformation increments from last convergence
         DDe   = vector of section deformation increments from last iteration
         edot  = vector of section deformation rates
         ks    = section stiffness matrix; returned under ACTION = 'stif'
         s     = section resisting force vector; returned under ACTION = 'stif' or 'forc'
         Past  = section history variables at last converged state
         Pres  = current section history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECPOST is a data structure with section response information for post-processing; it has the fields
         e  = section deformations
         s  = section stress resultants
         ep = plastic deformations</pre>
<!-- <div class="fragment"><pre class="comment">RESSEC_wLHNMzMyYS response of stress resultant section with N-Mz-My interaction and linear hardening   
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMzMyYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 3 stress resultant forces,
  the axial force N and the bending moments Mz, My about the z- and y-axis, respectively;
  the interaction of N-Mz-My is described by a polynomial limit surface with linear hardening
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  When the character variable ACTION has one of the following values,
  the function performs the listed operations and returns the results in SECRESP:
  ACTION = 'chec': check section property data for omissions and assign default values
           'init': initialize section history variables
           'forc': report section resisting forces
           'stif': report section stiffness matrix and resisting forces
           'post': report post-processing information
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  The data structure SECRESP stands for the following data object(s) for each ACTION:
  SECRESP = SECDATA    for action = 'chec'
  SECRESP = SECSTATE   for action = 'init'
  SECRESP = SECSTATE   for action = 'stif'
  SECRESP = SECSTATE   for action = 'forc'
  SECRESP = SECPOST    for action = 'post'
  SECRESP is empty     for unsupported keywords
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         Iz    = moment of inertia about z-axis
         Iy    = moment of inertia about y-axis
         Np    = plastic axial capacity
         Mpz   = plastic moment capacity about z-axis
         Mpy   = plastic moment capacity about y-axis
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-Mz-My interaction surface is described by a polynomial with the following definition
       f(n,mz,my) = Sum_i (di*(n^ai)*(mz^bi)*(my^ci))
      where n   = N/Np
            mz  = Mz/Mpz
            my  = My/Mpy
        a,b,c,d = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [d1 a1 b1 c1; d2 a2 b2 c2; d3 a3 b3 c3 ; ...];
                e.g. if GPYSC = [ 1 2 0 0 ; 1 0 2 0 ; 3.5 2 2 0 ; 3 0 2 2 ; -1 0 0 0 ];
                         f(p,m) = n^2 + mz^2 + 3.5*n^2*mz^2 + 3*mz^2*my^2- 1
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECSTATE is a data structure with information about the current section state; it has the fields
         e     = vector of total section deformations
         De    = vector of section deformation increments from last convergence
         DDe   = vector of section deformation increments from last iteration
         edot  = vector of section deformation rates
         ks    = section stiffness matrix; returned under ACTION = 'stif'
         s     = section resisting force vector; returned under ACTION = 'stif' or 'forc'
         Past  = section history variables at last converged state
         Pres  = current section history variables
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  SECPOST is a data structure with section response information for post-processing; it has the fields
         e  = section deformations
         s  = section stress resultants
         ep = plastic deformations</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../SD4ResSec_wLHNMzMyYS" class="code" title="[s,ks,SecHist,ConvFlag] = SD4ResSec_wLHNMzMyYS (SecData,e,SecHist)">SD4ResSec_wLHNMzMyYS</a>	stress resultant section for N-Mz-My interaction with linear hardening polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->