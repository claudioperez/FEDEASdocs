
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 SD4ResSec_wLHNMYS</div>

--------------------------

# `SD4ResSec_wLHNMYS`


## <a name="_name"></a>Purpose

stress resultant section for N-M interaction with linear hardening polynomial yield surface


## <a name="_synopsis"></a>Synopsis

`[s,ks,SecHist,ConvFlag] = SD4ResSec_wLHNMYS (SecData,e,SecHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RESSEC_wLHNMYS stress resultant section for N-M interaction with linear hardening polynomial yield surface
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 2 stress resultants,
  the axial force N and the bending moment M

  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Np    = plastic axial capacity
         Mp    = plastic moment capacity
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-M interaction surface is described by a polynomial with the following definition
       f(n,m) = Sum_i (ci*(n^ai)*(m^bi))
      where n = N/Np
            m = M/Mp
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if YSCoeff = [ 1 2 0 ; 1 0 2 ; 3.5 2 2 ; -1 0 0 ];
                         f(p,m) = n^2 + m^2 + 3.5*n^2*m^2 - 1

  SECHIST is a data structure with section history information; it has two fields
         Past  = section history variables at last converged state
         Pres  = section history variables at current state
         these fields contain the following element history variable(s):
         ep    = plastic section deformation vector
         alfa  = hardening variable
         sbk    = back &quot;stress&quot;</pre>
<!-- <div class="fragment"><pre class="comment">RESSEC_wLHNMYS stress resultant section for N-M interaction with linear hardening polynomial yield surface
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 2 stress resultants,
  the axial force N and the bending moment M

  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         I     = moment of inertia
         Np    = plastic axial capacity
         Mp    = plastic moment capacity
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-M interaction surface is described by a polynomial with the following definition
       f(n,m) = Sum_i (ci*(n^ai)*(m^bi))
      where n = N/Np
            m = M/Mp
        a,b,c = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [c1 a1 b1; c2 a2 b2; c3 a3 b3; ...];
                e.g. if YSCoeff = [ 1 2 0 ; 1 0 2 ; 3.5 2 2 ; -1 0 0 ];
                         f(p,m) = n^2 + m^2 + 3.5*n^2*m^2 - 1

  SECHIST is a data structure with section history information; it has two fields
         Past  = section history variables at last converged state
         Pres  = section history variables at current state
         these fields contain the following element history variable(s):
         ep    = plastic section deformation vector
         alfa  = hardening variable
         sbk    = back &quot;stress&quot;</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/GPYS" class="code" title="[f,g,h] = GPYS (GPYSC,xyz,ScVec)">GPYS</a>	function value, gradient and Hessian of polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->