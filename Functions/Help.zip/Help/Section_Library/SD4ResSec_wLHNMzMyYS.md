
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 SD4ResSec_wLHNMzMyYS</div>

--------------------------

# `SD4ResSec_wLHNMzMyYS`


## <a name="_name"></a>Purpose

stress resultant section for N-Mz-My interaction with linear hardening polynomial yield surface


## <a name="_synopsis"></a>Synopsis

`[s,ks,SecHist,ConvFlag] = SD4ResSec_wLHNMzMyYS (SecData,e,SecHist)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RESSEC_wLHNMzMyYS stress resultant section for N-Mz-My interaction with linear hardening polynomial yield surface
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMzMyYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 3 stress resultant forces,
  the axial force N and the bending moments Mz, My about the z- and y-axis, respectively 

  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         Iz    = moment of inertia about z-axis
         Iy    = moment of inertia about y-axis
         Np    = plastic axial capacity
         Mpz   = plastic moment capacity about z-axis
         Mpy   = plastic moment capacity about y-axis
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-Mz-My interaction surface is described by a polynomial with the following definition
       f(n,mz,my) = Sum_i (di*(n^ai)*(mz^bi)*(my^ci))
      where n   = N/Np
            mz  = Mz/Mpz
            my  = My/Mpy
        a,b,c,d = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [d1 a1 b1 c1; d2 a2 b2 c2; d3 a3 b3 c3 ; ...];
                e.g. if GPYSC = [ 1 2 0 0 ; 1 0 2 0 ; 3.5 2 2 0 ; 3 0 2 2 ; -1 0 0 0 ];
                         f(p,m) = n^2 + mz^2 + 3.5*n^2*mz^2 + 3*mz^2*my^2- 1

  SECHIST is a data structure with section history information; it has two fields
         Past  = section history variables at last converged state
         Pres  = section history variables at current state
         these fields contain the following element history variable(s):
         ep    = plastic section deformation vector
         alfa  = hardening variable
         sb    = back &quot;stress&quot;</pre>
<!-- <div class="fragment"><pre class="comment">RESSEC_wLHNMzMyYS stress resultant section for N-Mz-My interaction with linear hardening polynomial yield surface
  [S,KS,SECHIST,CONVFLAG] = RESSEC_wLHNMzMyYS (SECDATA,E,SECHIST)
  the function determines the response of a section with 3 stress resultant forces,
  the axial force N and the bending moments Mz, My about the z- and y-axis, respectively 

  SECDATA is a data structure with element property information; it has the fields
         E     = Young Modulus
         A     = cross-sectional area
         Iz    = moment of inertia about z-axis
         Iy    = moment of inertia about y-axis
         Np    = plastic axial capacity
         Mpz   = plastic moment capacity about z-axis
         Mpy   = plastic moment capacity about y-axis
         Hkr   = kinematic hardening ratios
         Hir   = isotropic hardening modulus (?)
         GPYSC = coefficients for general polynomial yield surface (see below)

  the N-Mz-My interaction surface is described by a polynomial with the following definition
       f(n,mz,my) = Sum_i (di*(n^ai)*(mz^bi)*(my^ci))
      where n   = N/Np
            mz  = Mz/Mpz
            my  = My/Mpy
        a,b,c,d = polynomial coefficients extracted from GPYSC according to the scheme
        GPYSC = [d1 a1 b1 c1; d2 a2 b2 c2; d3 a3 b3 c3 ; ...];
                e.g. if GPYSC = [ 1 2 0 0 ; 1 0 2 0 ; 3.5 2 2 0 ; 3 0 2 2 ; -1 0 0 0 ];
                         f(p,m) = n^2 + mz^2 + 3.5*n^2*mz^2 + 3*mz^2*my^2- 1

  SECHIST is a data structure with section history information; it has two fields
         Past  = section history variables at last converged state
         Pres  = section history variables at current state
         these fields contain the following element history variable(s):
         ep    = plastic section deformation vector
         alfa  = hardening variable
         sb    = back &quot;stress&quot;</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Element_Library/Frame_Elements/ConcentrInelastic/GPYS" class="code" title="[f,g,h] = GPYS (GPYSC,xyz,ScVec)">GPYS</a>	function value, gradient and Hessian of polynomial yield surface</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../ResSec_wLHNMzMyYS" class="code" title="SecResp = ResSec_wLHNMzMyYS (action,SecNo,ndm,SecData,SecState)">ResSec_wLHNMzMyYS</a>	response of stress resultant section with N-Mz-My interaction and linear hardening</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->