
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 SecwMDmg</div>

--------------------------

# `SecwMDmg`


## <a name="_name"></a>Purpose

=========================================================================================


## <a name="_synopsis"></a>Synopsis

`SecResp = SecwMDmg (action,SecNo,ndm,SecData,SecState)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">  =========================================================================================
  FEDEASLab - Release 5.2, July 2021
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2021. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  function added                                                                    11-2019
  -----------------------------------------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">  =========================================================================================
  FEDEASLab - Release 5.2, July 2021
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2021. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  function added                                                                    11-2019
  -----------------------------------------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../../Material_Library/DmgEvow1pnd" class="code" title="DmgResp = DmgEvow1pnd (action,DmgData,DmgState)">DmgEvow1pnd</a>	damage model with one positive and one negative damage index</li></ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->