
<a name="_top"></a>
<div>
<!-- <a href="../index.md">Home</a> &gt; -->
 Shear4RectSec</div>

--------------------------

# `Shear4RectSec`


## <a name="_name"></a>Purpose

compute the shear distributions for a rectangular section


## <a name="_synopsis"></a>Synopsis

`[shy,shz] = Shear4RectSec (SecData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SHEAR4RECTSECT compute the shear distributions for a rectangular section
    SHY and SHZ are function handles @(Y,Z) for the shear distribution type
    in character variables SHEARY and SHEARZ with the following options:
    'constant','linear','parabolic','rigid' or direct function specification e.g. 'y^2+z^2'</pre>
<!-- <div class="fragment"><pre class="comment">SHEAR4RECTSECT compute the shear distributions for a rectangular section
    SHY and SHZ are function handles @(Y,Z) for the shear distribution type
    in character variables SHEARY and SHEARZ with the following options:
    'constant','linear','parabolic','rigid' or direct function specification e.g. 'y^2+z^2'</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../matlabicon.gif)">
<li><a href="../HomoRectSecwNdMat" class="code" title="SecResp = HomoRectSecwNdMat (action,SecNo,ndm,SecData,SecState)">HomoRectSecwNdMat</a>	response of homogeneous rectangular section with 1d/2d/3d material</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->