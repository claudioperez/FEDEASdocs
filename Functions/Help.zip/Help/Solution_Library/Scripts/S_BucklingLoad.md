
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Scripts</a> &gt; S_BucklingLoad</div>

--------------------------

# `S_BucklingLoad`


## <a name="_name"></a>Purpose

general script for determining the buckling load of a structural model


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">BUCKLINGLOAD general script for determining the buckling load of a structural model
  the scripts sets up the linear and the geometric stiffness of a structural model with
  its geometry and boundary conditions in MODEL and its element properties IN ELEMDATA;
  before invoking the script it is necessary to define the reference load in Loading,
  so that it can be applied in Step 2 for determining the axial forces in the elements
  and with them the total structure stiffness Kt in the undeformed configuration;
  the geometric stiffness Kg is determined by subtracting the initial stiffness Kl from Kt</pre>
<!-- <div class="fragment"><pre class="comment">BUCKLINGLOAD general script for determining the buckling load of a structural model
  the scripts sets up the linear and the geometric stiffness of a structural model with
  its geometry and boundary conditions in MODEL and its element properties IN ELEMDATA;
  before invoking the script it is necessary to define the reference load in Loading,
  so that it can be applied in Step 2 for determining the axial forces in the elements
  and with them the total structure stiffness Kt in the undeformed configuration;
  the geometric stiffness Kg is determined by subtracting the initial stiffness Kl from Kt</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize_SolStrat" class="code" title="SolStrat = Initialize_SolStrat">Initialize_SolStrat</a>	default values for most solution strategy parameters</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize_State" class="code" title="State = Initialize_State (Model,ElemData)">Initialize_State</a>	initialize state variables of structural model and create STATE</li><li><a href="../../../Solution_Library/Strategies/S_InitialStep" class="code" title="">S_InitialStep</a>	script for initial step of incremental analysis</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->