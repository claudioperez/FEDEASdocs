
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Scripts</a> &gt; S_Check_Global3dEQ</div>

--------------------------

# `S_Check_Global3dEQ`


## <a name="_name"></a>Purpose

general script for checking global equilibrium of 3d structural models


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CHECK_GLOBAL3dEQ general script for checking global equilibrium of 3d structural models
  the script uses the resisting forces in vector P or in State.Pr for checking the global
  force equilibrium of the structural model and the resisting forces along with
  the node coordinates in array Model.XYZ to set up the cross products for checking
  the moment equilibrium about the global X,Y,Z axes</pre>
<!-- <div class="fragment"><pre class="comment">CHECK_GLOBAL3dEQ general script for checking global equilibrium of 3d structural models
  the script uses the resisting forces in vector P or in State.Pr for checking the global
  force equilibrium of the structural model and the resisting forces along with
  the node coordinates in array Model.XYZ to set up the cross products for checking
  the moment equilibrium about the global X,Y,Z axes</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->