
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Scripts</a> &gt; S_ForceMethod</div>

--------------------------

# `S_ForceMethod`


## <a name="_name"></a>Purpose

script for force method of structural analysis


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">FORCEMETHOD script for force method of structural analysis
  the script contains the steps for the force method of structural analysis:
  (1) set up the equilibrium matrix Bf
  (2) set up the force influence matrices for the primary structure Bbari and Bbarx
  (3) set up the collection of element flexibility matrices Fs
  (4) set up the compatibility conditions and solve for the redundant basic forces Qx
  (5) determine the basic element forces Q=Qp+Bbarx*Qx
  (6) determine the element deformations Ve=Fs*Q+V0
  (7) determine the free DOF displacements Uf=Bbari'*Ve</pre>
<!-- <div class="fragment"><pre class="comment">FORCEMETHOD script for force method of structural analysis
  the script contains the steps for the force method of structural analysis:
  (1) set up the equilibrium matrix Bf
  (2) set up the force influence matrices for the primary structure Bbari and Bbarx
  (3) set up the collection of element flexibility matrices Fs
  (4) set up the compatibility conditions and solve for the redundant basic forces Qx
  (5) determine the basic element forces Q=Qp+Bbarx*Qx
  (6) determine the element deformations Ve=Fs*Q+V0
  (7) determine the free DOF displacements Uf=Bbari'*Ve</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/B_matrix" class="code" title="B = B_matrix (Model)">B_matrix</a>	equilibrium matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../../../General/BbariBbarx_matrix" class="code" title="[Bbari,Bbarx,ind_x] = BbariBbarx_matrix (Bf,ind_r,ind_rng)">BbariBbarx_matrix</a>	force influence matrices of primary structure from equilibrium matrix Bf</li><li><a href="../../../General/Create_PwForces" class="code" title="Pw = Create_PwForces (Model,ElemData)">Create_PwForces</a>	set up equivalent nodal forces due to uniform element loading w</li><li><a href="../../../General/Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../../../General/V0_vector" class="code" title="V0 = V0_vector (Model,ElemData,Roption)">V0_vector</a>	initial element deformation vector for the structural model</li><li><a href="../../../Utilities/General/H_index" class="code" title="iced = H_index (Model,ElemData)">H_index</a>	cell array of indices into structure arrays for continuous element deformations</li><li><a href="../../../Utilities/PostProcessing/Complete_QV" class="code" title="[Q,Ve] = Complete_QV (Model,ElemData,Qin)">Complete_QV</a>	complete basic force QIN and element deformation vector VE with values at releases</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->