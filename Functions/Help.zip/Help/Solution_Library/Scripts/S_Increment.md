
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Scripts</a> &gt; S_Increment</div>

--------------------------

# `S_Increment`


## <a name="_name"></a>Purpose

script for load incrementation


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INCREMENT script for load incrementation</pre>
<!-- <div class="fragment"><pre class="comment">INCREMENT script for load incrementation</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Static_Analysis/Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->