---
title: Scripts
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Scripts`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Scripts

<table>
<tr><td><a href="S_BucklingLoad">S_BucklingLoad</a></td><td>general script for determining the buckling load of a structural model </td></tr><tr><td><a href="S_Check_Global3dEQ">S_Check_Global3dEQ</a></td><td>general script for checking global equilibrium of 3d structural models </td></tr><tr><td><a href="S_DisplMethod">S_DisplMethod</a></td><td>script for displacement method of structural analysis </td></tr><tr><td><a href="S_DisplMethodwUd">S_DisplMethodwUd</a></td><td>script for displacement method of structural analysis including support displacements </td></tr><tr><td><a href="S_ForceMethod">S_ForceMethod</a></td><td>script for force method of structural analysis </td></tr><tr><td><a href="S_GeneralForceMethod">S_GeneralForceMethod</a></td><td>script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf </td></tr><tr><td><a href="S_Increment">S_Increment</a></td><td>script for load incrementation </td></tr><tr><td><a href="S_Initialize">S_Initialize</a></td><td>script for initializing State and SolStrat </td></tr><tr><td><a href="S_Iterate">S_Iterate</a></td><td>script for equilibrium iterations </td></tr><tr><td><a href="S_LinearStep">S_LinearStep</a></td><td>basic script for linear elastic analysis step by displacement method </td></tr><tr><td><a href="S_MomCurvAnalysis">S_MomCurvAnalysis</a></td><td>script for moment-curvature analysis under constant axial force </td></tr><tr><td><a href="S_NMAnalysis">S_NMAnalysis</a></td><td>script for incremental application of N-M pair on section </td></tr><tr><td><a href="S_NMAnalysiswSepLoadHist">S_NMAnalysiswSepLoadHist</a></td><td>script for application N and M with separate load histories </td></tr><tr><td><a href="S_Update_State">S_Update_State</a></td><td>state determination after convergence with results in Post </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->