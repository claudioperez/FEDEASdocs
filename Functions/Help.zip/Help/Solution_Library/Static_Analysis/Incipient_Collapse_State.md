
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; Incipient_Collapse_State</div>

--------------------------

# `Incipient_Collapse_State`


## <a name="_name"></a>Purpose

STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse


## <a name="_synopsis"></a>Synopsis

`[Qc,Uf,Vpl] = Incipient_Collapse_State (Model,ElemData,Loading)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INCIPIENT_COLLAPSE STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse
  [QC,UF,VPL] = INCIPIENT_COLLAPSE STATE (MODEL,ELEMDATA,LOADING)
  the function determines the state of a structural model at incipient collapse under loading
  information in data structure LOADING; the latter should have the field PREF for the
  load pattern to be factored, and may include a field Pcf for the load pattern to remain constant;
  the data structure MODEL contains information about the structural model, and
  element property information is provided in cell array ELEMDATA;
  the function returns the basic forces in vector QC, the displacements in vector UF,
  and the plastic deformations in vector VPL at incipient collapse of the structure</pre>
<!-- <div class="fragment"><pre class="comment">INCIPIENT_COLLAPSE STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse
  [QC,UF,VPL] = INCIPIENT_COLLAPSE STATE (MODEL,ELEMDATA,LOADING)
  the function determines the state of a structural model at incipient collapse under loading
  information in data structure LOADING; the latter should have the field PREF for the
  load pattern to be factored, and may include a field Pcf for the load pattern to remain constant;
  the data structure MODEL contains information about the structural model, and
  element property information is provided in cell array ELEMDATA;
  the function returns the basic forces in vector QC, the displacements in vector UF,
  and the plastic deformations in vector VPL at incipient collapse of the structure</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/A_matrix" class="code" title="A = A_matrix (Model)">A_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../../../General/BbariBbarx_matrix" class="code" title="[Bbari,Bbarx,ind_x] = BbariBbarx_matrix (Bf,ind_r,ind_rng)">BbariBbarx_matrix</a>	force influence matrices of primary structure from equilibrium matrix Bf</li><li><a href="../../../General/Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../PlasticAnalysis_wUBT" class="code" title="[lamdac,DUf,DVhp] = PlasticAnalysis_wUBT (Af,Qpl,Pref,Pcf,Options)">PlasticAnalysis_wUBT</a>	collapse load factor and deformation increments by upper bound theorem of plastic analysis</li><li><a href="../../../Utilities/PreProcessing/Elements/ElemData2Qpl" class="code" title="Qpl = ElemData2Qpl (Model,ElemData)">ElemData2Qpl</a>	converts the plastic capacities from cell array of element properties to vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->