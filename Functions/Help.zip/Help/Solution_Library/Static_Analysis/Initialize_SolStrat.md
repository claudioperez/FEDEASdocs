
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; Initialize_SolStrat</div>

--------------------------

# `Initialize_SolStrat`


## <a name="_name"></a>Purpose

default values for most solution strategy parameters


## <a name="_synopsis"></a>Synopsis

`SolStrat = Initialize_SolStrat`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INITIALIZE_SOLSTRAT default values for most solution strategy parameters
  SOLSTRAT = INITIALIZE_SOLSTRAT
  the function assigns default values to most solution strategy parameters and creates
  the data structure SOLSTRAT with corresponding information;
  SOLSTRAT contains three substructures: INCRSTRAT, ITERSTRAT and TIMESTRAT;
  these data structures contain the following fields
  INCRSTRAT
           Dlam0    = initial load factor increment(s) (row vector)
           Deltat   = pseudo-time increment (scalar)
           StifUpdt = stiffness update (character variable)
           LFCtrl   = load control (character variable)
           LCType   = load control type
           gamma    = exponent of current stiffness parameter method of load control
  ITERSTRAT
           StifUpdt = stiffness update (character variable)
           Type     = 'NR', 'ModNR', 'Krylov', 'LnSrch'
           LFCtrl   = load control (character variable)
           LCType   = load control type
           LCParam  = load control parameters
           maxiter  = maximum number of iterations for equilibrium (scalar)
           tol      = tolerance for satifaction of equilibrium equations (scalar)
  TIMESTRAT
           Delta    = time step of transient analysis (scalar)
           Type     = type of numerical integration (character variable)
           Param    = parameters of numerical time integration scheme (row vector)
  the data structure also contains three auxiliary fields
    Output = for echoing information about residuals during analysis           (default = yes)
    Debug  = for storing the state during solution for debuging                (default = no)
    PUHist = for storing displacements and forces during solution for plotting (default = no)</pre>
<!-- <div class="fragment"><pre class="comment">INITIALIZE_SOLSTRAT default values for most solution strategy parameters
  SOLSTRAT = INITIALIZE_SOLSTRAT
  the function assigns default values to most solution strategy parameters and creates
  the data structure SOLSTRAT with corresponding information;
  SOLSTRAT contains three substructures: INCRSTRAT, ITERSTRAT and TIMESTRAT;
  these data structures contain the following fields
  INCRSTRAT
           Dlam0    = initial load factor increment(s) (row vector)
           Deltat   = pseudo-time increment (scalar)
           StifUpdt = stiffness update (character variable)
           LFCtrl   = load control (character variable)
           LCType   = load control type
           gamma    = exponent of current stiffness parameter method of load control
  ITERSTRAT
           StifUpdt = stiffness update (character variable)
           Type     = 'NR', 'ModNR', 'Krylov', 'LnSrch'
           LFCtrl   = load control (character variable)
           LCType   = load control type
           LCParam  = load control parameters
           maxiter  = maximum number of iterations for equilibrium (scalar)
           tol      = tolerance for satifaction of equilibrium equations (scalar)
  TIMESTRAT
           Delta    = time step of transient analysis (scalar)
           Type     = type of numerical integration (character variable)
           Param    = parameters of numerical time integration scheme (row vector)
  the data structure also contains three auxiliary fields
    Output = for echoing information about residuals during analysis           (default = yes)
    Debug  = for storing the state during solution for debuging                (default = no)
    PUHist = for storing displacements and forces during solution for plotting (default = no)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_BucklingLoad" class="code" title="">S_BucklingLoad</a>	general script for determining the buckling load of a structural model</li><li><a href="../../../Solution_Library/Scripts/S_Initialize" class="code" title="">S_Initialize</a>	script for initializing State and SolStrat</li><li><a href="../../../Solution_Library/Scripts/S_MomCurvAnalysis" class="code" title="">S_MomCurvAnalysis</a>	script for moment-curvature analysis under constant axial force</li><li><a href="../../../Solution_Library/Scripts/S_NMAnalysis" class="code" title="">S_NMAnalysis</a>	script for incremental application of N-M pair on section</li><li><a href="../../../Solution_Library/Scripts/S_NMAnalysiswSepLoadHist" class="code" title="">S_NMAnalysiswSepLoadHist</a>	script for application N and M with separate load histories</li><li><a href="../MomntCurvAnalysis" class="code" title="[eHist,sHist,Post] = MomntCurvAnalysis (SecName,SecData,LoadData)">MomntCurvAnalysis</a>	moment-curvature analysis of section under constant or variable normal force</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->