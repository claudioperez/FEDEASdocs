
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; Initialize_State</div>

--------------------------

# `Initialize_State`


## <a name="_name"></a>Purpose

initialize state variables of structural model and create STATE


## <a name="_synopsis"></a>Synopsis

`State = Initialize_State (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INITIALIZE_STATE initialize state variables of structural model and create STATE    
  INITIALIZE_STATE (MODEL,ELEMDATA)
  function initializes the displacement, velocity and acceleration vectors
  for the structural model with information in data structure MODEL;
  the cell array ELEMDATA supplies the element property data for element history initialization;
  the function returns data structure STATE with the following fields
  STATE.U       = global dof total displacement vector
        DU      = global dof displacement increments from last convergence
        DDU     = global dof displacement increments from last iteration
        Udot    = global dof velocity vector
        Udotdot = global dof acceleration vector
        Past    = data structure of last    element history variables in cell array Elem
        Pres    = data structure of current element history variables in cell array Elem</pre>
<!-- <div class="fragment"><pre class="comment">INITIALIZE_STATE initialize state variables of structural model and create STATE    
  INITIALIZE_STATE (MODEL,ELEMDATA)
  function initializes the displacement, velocity and acceleration vectors
  for the structural model with information in data structure MODEL;
  the cell array ELEMDATA supplies the element property data for element history initialization;
  the function returns data structure STATE with the following fields
  STATE.U       = global dof total displacement vector
        DU      = global dof displacement increments from last convergence
        DDU     = global dof displacement increments from last iteration
        Udot    = global dof velocity vector
        Udotdot = global dof acceleration vector
        Past    = data structure of last    element history variables in cell array Elem
        Pres    = data structure of current element history variables in cell array Elem</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_BucklingLoad" class="code" title="">S_BucklingLoad</a>	general script for determining the buckling load of a structural model</li><li><a href="../../../Solution_Library/Scripts/S_Initialize" class="code" title="">S_Initialize</a>	script for initializing State and SolStrat</li><li><a href="../LinearStep" class="code" title="State = LinearStep (Model,ElemData,Loading)">LinearStep</a>	sets up and solves the structure equilibrium equations for single load step</li><li><a href="../../../Solution_Library/Strategies/S_InitialStep" class="code" title="">S_InitialStep</a>	script for initial step of incremental analysis</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep" class="code" title="">S_MultiStep</a>	script for multi-step incremental analysis after load factor initialization</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHist" class="code" title="">S_MultiStep_wLoadHist</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistwSD" class="code" title="">S_MultiStep_wLoadHistwSD</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep" class="code" title="">S_Transient_MultiStep</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStepwSD" class="code" title="">S_Transient_MultiStepwSD</a>	script for multi-step transient analysis under given load history(ies)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->