
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; Iterate</div>

--------------------------

# `Iterate`


## <a name="_name"></a>Purpose

equilibrium iterations until convergence under static conditions


## <a name="_synopsis"></a>Synopsis

`[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ITERATE equilibrium iterations until convergence under static conditions
  [STATE,SOLSTRAT] = ITERATE(MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function performs equilibrium iterations until convergence under the applied loading
  and determines the corresponding displacement increments under static conditions;
  information about the state of the structure is updated in STATE and
  information about parameters of solution strategy are updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns and corresponding load histories</pre>
<!-- <div class="fragment"><pre class="comment">ITERATE equilibrium iterations until convergence under static conditions
  [STATE,SOLSTRAT] = ITERATE(MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function performs equilibrium iterations until convergence under the applied loading
  and determines the corresponding displacement increments under static conditions;
  information about the state of the structure is updated in STATE and
  information about parameters of solution strategy are updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns and corresponding load histories</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../OneIteration" class="code" title="[State,SolStrat] = OneIteration (Model,ElemData,Loading,State,SolStrat)">OneIteration</a>	single equilibrium iteration under static conditions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_Iterate" class="code" title="">S_Iterate</a>	script for equilibrium iterations</li><li><a href="../../../Solution_Library/Strategies/S_InitialStep" class="code" title="">S_InitialStep</a>	script for initial step of incremental analysis</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep" class="code" title="">S_MultiStep</a>	script for multi-step incremental analysis after load factor initialization</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_Cont" class="code" title="">S_MultiStep_Cont</a>	script for continuation of multi-step incremental analysis</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHist" class="code" title="">S_MultiStep_wLoadHist</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistCont" class="code" title="">S_MultiStep_wLoadHistCont</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistContwSD" class="code" title="">S_MultiStep_wLoadHistContwSD</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistwSD" class="code" title="">S_MultiStep_wLoadHistwSD</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_OneStep_wLoadHist" class="code" title="">S_OneStep_wLoadHist</a>	script for a single step of incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_OneStep_wLoadHistwSD" class="code" title="">S_OneStep_wLoadHistwSD</a>	am not sure that this script is useful (FCF, January 10, 2021)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->