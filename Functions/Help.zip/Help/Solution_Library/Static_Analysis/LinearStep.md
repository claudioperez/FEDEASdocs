
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; LinearStep</div>

--------------------------

# `LinearStep`


## <a name="_name"></a>Purpose

sets up and solves the structure equilibrium equations for single load step


## <a name="_synopsis"></a>Synopsis

`State = LinearStep (Model,ElemData,Loading)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LINEARSTEP sets up and solves the structure equilibrium equations for single load step
  STATE = LINEARSTEP (MODEL,ELEMDATA,LOADING)
  function sets up and solves the structure equilibrium equations for single load step
  by direct assembly of element stiffness matrices; the structural response is contained
  in data structure STATE with fields U for the global dof displacement vector, Pr for the
  resisting force vector and Kf for the stiffness matrix at the free dofs of the structure;
  information about the structural model is supplied in data structure MODEL,
  the element properties are supplied in cell array ELEMDATA and loading information is
  given in data structure LOADING with fields Pref and Uref for a single applied force and
  a single imposed displacement vector, respectively</pre>
<!-- <div class="fragment"><pre class="comment">LINEARSTEP sets up and solves the structure equilibrium equations for single load step
  STATE = LINEARSTEP (MODEL,ELEMDATA,LOADING)
  function sets up and solves the structure equilibrium equations for single load step
  by direct assembly of element stiffness matrices; the structural response is contained
  in data structure STATE with fields U for the global dof displacement vector, Pr for the
  resisting force vector and Kf for the stiffness matrix at the free dofs of the structure;
  information about the structural model is supplied in data structure MODEL,
  the element properties are supplied in cell array ELEMDATA and loading information is
  given in data structure LOADING with fields Pref and Uref for a single applied force and
  a single imposed displacement vector, respectively</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../Initialize_State" class="code" title="State = Initialize_State (Model,ElemData)">Initialize_State</a>	initialize state variables of structural model and create STATE</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->