
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; LoadFactorControl</div>

--------------------------

# `LoadFactorControl`


## <a name="_name"></a>Purpose

determine load factor increment under load control strategy


## <a name="_synopsis"></a>Synopsis

`SolStrat = LoadFactorControl (action,SolStrat,detKf,Pref,Ut,DUr)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> LOADFACTORCONTROL determine load factor increment under load control strategy
  SOLSTRAT = LOADFACTORCONTROL(ACTION,SOLSTRAT,KL,KU,PREF,UT,DUR)
  the function determines the load factor increment in field DLAM of data structure SOLSTRAT
  under the specified load control strategy in field LCTYPE of SOLSTRAT;
  ACTION is a character variable that distinguishes various load control stages, i.e.
  initialization, incrementation and iteration; accordingly, the choices are
  ACTION = 'init': initialization of load control parameters in field HIST of SOLSTRAT
  ACTION = 'incr': determination of DLAM during load incrementation; parameter update in HIST
  ACTION = 'iter': determination of DLAM during equilibrium iteration (the following load
                   control methods are currently supported: 'MinDispNorm' and 'KeyDOF'
  KL and KU are the lower and upper diagonal LU components of the tangent stiffness matrix,
  PREF is the reference force vector and UT the corresponding displacement vector under PREF,
  DUR is the vector of displacement increments under the current unbalance force vector</pre>
<!-- <div class="fragment"><pre class="comment"> LOADFACTORCONTROL determine load factor increment under load control strategy
  SOLSTRAT = LOADFACTORCONTROL(ACTION,SOLSTRAT,KL,KU,PREF,UT,DUR)
  the function determines the load factor increment in field DLAM of data structure SOLSTRAT
  under the specified load control strategy in field LCTYPE of SOLSTRAT;
  ACTION is a character variable that distinguishes various load control stages, i.e.
  initialization, incrementation and iteration; accordingly, the choices are
  ACTION = 'init': initialization of load control parameters in field HIST of SOLSTRAT
  ACTION = 'incr': determination of DLAM during load incrementation; parameter update in HIST
  ACTION = 'iter': determination of DLAM during equilibrium iteration (the following load
                   control methods are currently supported: 'MinDispNorm' and 'KeyDOF'
  KL and KU are the lower and upper diagonal LU components of the tangent stiffness matrix,
  PREF is the reference force vector and UT the corresponding displacement vector under PREF,
  DUR is the vector of displacement increments under the current unbalance force vector</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../Initialize" class="code" title="[State,SolStrat] = Initialize (Model,ElemData,Loading,State,SolStrat)">Initialize</a>	initialize analysis variables in STATE and load control parameters in SOLSTRAT</li><li><a href="../OneIteration" class="code" title="[State,SolStrat] = OneIteration (Model,ElemData,Loading,State,SolStrat)">OneIteration</a>	single equilibrium iteration under static conditions</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->