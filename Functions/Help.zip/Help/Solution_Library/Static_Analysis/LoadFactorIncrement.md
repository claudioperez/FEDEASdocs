
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; LoadFactorIncrement</div>

--------------------------

# `LoadFactorIncrement`


## <a name="_name"></a>Purpose

load factor increment(s) for given load histories


## <a name="_synopsis"></a>Synopsis

`Dlam = LoadFactorIncrement (History,Time,Deltat)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LOADFACTORINCREMENT load factor increment(s) for given load histories
  DLAM = LOADFACTORINCREMENT(HISTORY,TIME,DELTAT)
  the function determines the load factor increment(s) in vector DLAM for the number of
  time histories in data structure HISTORY with fields TIME and VALUE; linear interpolation
  with current time TIME and time step DELTAT gives the load factor increment(s)</pre>
<!-- <div class="fragment"><pre class="comment">LOADFACTORINCREMENT load factor increment(s) for given load histories
  DLAM = LOADFACTORINCREMENT(HISTORY,TIME,DELTAT)
  the function determines the load factor increment(s) in vector DLAM for the number of
  time histories in data structure HISTORY with fields TIME and VALUE; linear interpolation
  with current time TIME and time step DELTAT gives the load factor increment(s)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientIncrement" class="code" title="[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)">TransientIncrement</a>	load incrementation and state advance under transient conditions</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->