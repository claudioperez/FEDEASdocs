
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; MomntCurvAnalysis</div>

--------------------------

# `MomntCurvAnalysis`


## <a name="_name"></a>Purpose

moment-curvature analysis of section under constant or variable normal force


## <a name="_synopsis"></a>Synopsis

`[eHist,sHist,Post] = MomntCurvAnalysis (SecName,SecData,LoadData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MOMNTCURVANALYSIS moment-curvature analysis of section under constant or variable normal force</pre>
<!-- <div class="fragment"><pre class="comment">MOMNTCURVANALYSIS moment-curvature analysis of section under constant or variable normal force</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Create_Loading" class="code" title="Loading = Create_Loading (Model,Pe,Ue)">Create_Loading</a>	create data structure Loading with reference vector(s) for applied forces and imposed displacements</li><li><a href="../../../General/Create_Model" class="code" title="Model = Create_Model (XYZ,CON,BOUN,ElemName)">Create_Model</a>	creates data structure Model from node coordinates, connectivity and boundary conditions</li><li><a href="../Initialize_SolStrat" class="code" title="SolStrat = Initialize_SolStrat">Initialize_SolStrat</a>	default values for most solution strategy parameters</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistwSD" class="code" title="">S_MultiStep_wLoadHistwSD</a>	script for multi-step incremental analysis under given load history(ies)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->