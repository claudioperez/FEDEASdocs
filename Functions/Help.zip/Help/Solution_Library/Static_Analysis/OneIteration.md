
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; OneIteration</div>

--------------------------

# `OneIteration`


## <a name="_name"></a>Purpose

single equilibrium iteration under static conditions


## <a name="_synopsis"></a>Synopsis

`[State,SolStrat] = OneIteration (Model,ElemData,Loading,State,SolStrat)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> ONEITERATION single equilibrium iteration under static conditions
  [STATE,SOLSTRAT] = ONEITERATION (MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function performs a single equilibrium iteration under the applied loading
  and determines the corresponding displacement increments under static conditions;
  information about the state of the structure is updated in STATE and
  information about the parameters of the solution strategy is updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns with corresponding load histories</pre>
<!-- <div class="fragment"><pre class="comment"> ONEITERATION single equilibrium iteration under static conditions
  [STATE,SOLSTRAT] = ONEITERATION (MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function performs a single equilibrium iteration under the applied loading
  and determines the corresponding displacement increments under static conditions;
  information about the state of the structure is updated in STATE and
  information about the parameters of the solution strategy is updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns with corresponding load histories</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../LoadFactorControl" class="code" title="SolStrat = LoadFactorControl (action,SolStrat,detKf,Pref,Ut,DUr)">LoadFactorControl</a>	determine load factor increment under load control strategy</li><li><a href="../StateDetermination" class="code" title="State = StateDetermination (StifUpdt,Model,ElemData,State)">StateDetermination</a>	structure state determination under static conditions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Iterate" class="code" title="[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)">Iterate</a>	equilibrium iterations until convergence under static conditions</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->