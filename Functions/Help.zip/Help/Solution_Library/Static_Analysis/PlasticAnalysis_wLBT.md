
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; PlasticAnalysis_wLBT</div>

--------------------------

# `PlasticAnalysis_wLBT`


## <a name="_name"></a>Purpose

collapse load factor and basic element forces by lower bound theorem of plastic analysis


## <a name="_synopsis"></a>Synopsis

`[lamdac,Qc] = PlasticAnalysis_wLBT (Bf,Qpl,Pref,Pcf,Options)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLASTICANALYSIS_wLBT collapse load factor and basic element forces by lower bound theorem of plastic analysis
  [LAMDAC,QC] = PLASTICANALYSIS_wLBT (BF,QPL,PREF,PCF,OPTIONS)
  the function uses the lower bound theorem of plastic analysis
  to determine the collapse load factor LAMDAC and the basic forces QC at collapse
  of a structural model under reference load vector PREF and force vector PCF at free dofs;
  the reference force vector PREF represents the load pattern to be factored, while
  the force vector PCF represents the load pattern that remains unfactored;
  for the sign of PCF note that the equilibrium equations are: lambda Pref + Pcf = Bf Q;
  there are two options for supplying the static matrix Bf:
  (a) as data structure Model with information about the structural model, that is used
      to set up the static matrix Bf of the structure automatically, or
  (b) as nf by nq matrix where nf = no of free dofs and nq = total number of basic forces;
  there are two options for supplying the plastic capacities QPL:
  (a) as cell array ELEMDATA with plastic capacities in fields Np for axial and Mp for flexural
  (b) as one column vector for the case that positive and negative capacities are the same,
       or, as two column array with positive plastic capacities in the first column
       and negative plastic capacities in the second (in absolute value) (signs matching Q!)
  NOTE: mixing of options (a) and (b) is not supported!</pre>
<!-- <div class="fragment"><pre class="comment">PLASTICANALYSIS_wLBT collapse load factor and basic element forces by lower bound theorem of plastic analysis
  [LAMDAC,QC] = PLASTICANALYSIS_wLBT (BF,QPL,PREF,PCF,OPTIONS)
  the function uses the lower bound theorem of plastic analysis
  to determine the collapse load factor LAMDAC and the basic forces QC at collapse
  of a structural model under reference load vector PREF and force vector PCF at free dofs;
  the reference force vector PREF represents the load pattern to be factored, while
  the force vector PCF represents the load pattern that remains unfactored;
  for the sign of PCF note that the equilibrium equations are: lambda Pref + Pcf = Bf Q;
  there are two options for supplying the static matrix Bf:
  (a) as data structure Model with information about the structural model, that is used
      to set up the static matrix Bf of the structure automatically, or
  (b) as nf by nq matrix where nf = no of free dofs and nq = total number of basic forces;
  there are two options for supplying the plastic capacities QPL:
  (a) as cell array ELEMDATA with plastic capacities in fields Np for axial and Mp for flexural
  (b) as one column vector for the case that positive and negative capacities are the same,
       or, as two column array with positive plastic capacities in the first column
       and negative plastic capacities in the second (in absolute value) (signs matching Q!)
  NOTE: mixing of options (a) and (b) is not supported!</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/B_matrix" class="code" title="B = B_matrix (Model)">B_matrix</a>	equilibrium matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../../../Utilities/PreProcessing/Elements/ElemData2Qpl" class="code" title="Qpl = ElemData2Qpl (Model,ElemData)">ElemData2Qpl</a>	converts the plastic capacities from cell array of element properties to vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->