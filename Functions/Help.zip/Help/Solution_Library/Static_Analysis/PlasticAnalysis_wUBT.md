
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; PlasticAnalysis_wUBT</div>

--------------------------

# `PlasticAnalysis_wUBT`


## <a name="_name"></a>Purpose

collapse load factor and deformation increments by upper bound theorem of plastic analysis


## <a name="_synopsis"></a>Synopsis

`[lamdac,DUf,DVhp] = PlasticAnalysis_wUBT (Af,Qpl,Pref,Pcf,Options)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLASTICANALYSIS_wUBT collapse load factor and deformation increments by upper bound theorem of plastic analysis
  [LAMDAC,DUF,DVHP] = PLASTICANALYSIS_wUBT (AF,QPL,PREF,PCF)
  the function uses the upper bound theorem of plastic analysis
  to determine the collapse load factor LAMDAC, and the displacement and plastic deformation
  increments of the collapse mechanism DUF and DVHP, respectively,
  of a structural model under reference load vector PREF and force vector PCF at free dofs;
  the reference force vector PREF represents the load pattern to be factored, while
  the force vector PFC represents the load pattern that remains unfactored;
  for the sign of PFU note that the equilibrium equations are: lambda Pref + Pcf = Bf Q;
  there are two options for supplying the kinematic matrix Af:
  (a) as data structure Model with information about the structural model, that is used
      to set up the kinematic matrix Af of the structure automatically, or
  (b) as nq by nf matrix where nq = total number of deformations and nf = no of free dofs;
  there are two options for supplying the plastic capacities QPL:
  (a) as cell array ELEMDATA with plastic capacities in fields Np for axial and Mp for flexural
  (b) as one column vector for the case that positive and negative capacities are the same,
       or, as two column array with positive plastic capacities in the first column
       and negative plastic capacities in the second (in absolute value) (signs matching Q!)
  NOTE: mixing of options (a) and (b) is not supported!</pre>
<!-- <div class="fragment"><pre class="comment">PLASTICANALYSIS_wUBT collapse load factor and deformation increments by upper bound theorem of plastic analysis
  [LAMDAC,DUF,DVHP] = PLASTICANALYSIS_wUBT (AF,QPL,PREF,PCF)
  the function uses the upper bound theorem of plastic analysis
  to determine the collapse load factor LAMDAC, and the displacement and plastic deformation
  increments of the collapse mechanism DUF and DVHP, respectively,
  of a structural model under reference load vector PREF and force vector PCF at free dofs;
  the reference force vector PREF represents the load pattern to be factored, while
  the force vector PFC represents the load pattern that remains unfactored;
  for the sign of PFU note that the equilibrium equations are: lambda Pref + Pcf = Bf Q;
  there are two options for supplying the kinematic matrix Af:
  (a) as data structure Model with information about the structural model, that is used
      to set up the kinematic matrix Af of the structure automatically, or
  (b) as nq by nf matrix where nq = total number of deformations and nf = no of free dofs;
  there are two options for supplying the plastic capacities QPL:
  (a) as cell array ELEMDATA with plastic capacities in fields Np for axial and Mp for flexural
  (b) as one column vector for the case that positive and negative capacities are the same,
       or, as two column array with positive plastic capacities in the first column
       and negative plastic capacities in the second (in absolute value) (signs matching Q!)
  NOTE: mixing of options (a) and (b) is not supported!</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/A_matrix" class="code" title="A = A_matrix (Model)">A_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../../../Utilities/PreProcessing/Elements/ElemData2Qpl" class="code" title="Qpl = ElemData2Qpl (Model,ElemData)">ElemData2Qpl</a>	converts the plastic capacities from cell array of element properties to vector</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Incipient_Collapse_State" class="code" title="[Qc,Uf,Vpl] = Incipient_Collapse_State (Model,ElemData,Loading)">Incipient_Collapse_State</a>	STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->