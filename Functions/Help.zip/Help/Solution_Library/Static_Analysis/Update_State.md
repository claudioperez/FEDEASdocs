
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Static_Analysis</a> &gt; Update_State</div>

--------------------------

# `Update_State`


## <a name="_name"></a>Purpose

final state determination under static conditions, reset increments and history


## <a name="_synopsis"></a>Synopsis

`State = Update_State (Model,ElemData,State)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">UPDATE_STATE final state determination under static conditions, reset increments and history
  STATE = UPDATE_STATE (MODEL,ELEMDATA,STATE)
  the function performs a final state determination for the current state of the structure
  as described by the displacement vector and its increments as well as by the history
  variables in STATE; it then updates the structure resisting forces and history variables
  in STATE and then sets the displacement increments in STATE to zero</pre>
<!-- <div class="fragment"><pre class="comment">UPDATE_STATE final state determination under static conditions, reset increments and history
  STATE = UPDATE_STATE (MODEL,ELEMDATA,STATE)
  the function performs a final state determination for the current state of the structure
  as described by the displacement vector and its increments as well as by the history
  variables in STATE; it then updates the structure resisting forces and history variables
  in STATE and then sets the displacement increments in STATE to zero</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_Update_State" class="code" title="">S_Update_State</a>	state determination after convergence with results in Post</li><li><a href="../../../Solution_Library/Strategies/S_InitialStep" class="code" title="">S_InitialStep</a>	script for initial step of incremental analysis</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep" class="code" title="">S_MultiStep</a>	script for multi-step incremental analysis after load factor initialization</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_Cont" class="code" title="">S_MultiStep_Cont</a>	script for continuation of multi-step incremental analysis</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHist" class="code" title="">S_MultiStep_wLoadHist</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistCont" class="code" title="">S_MultiStep_wLoadHistCont</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistContwSD" class="code" title="">S_MultiStep_wLoadHistContwSD</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_MultiStep_wLoadHistwSD" class="code" title="">S_MultiStep_wLoadHistwSD</a>	script for multi-step incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_OneStep_wLoadHist" class="code" title="">S_OneStep_wLoadHist</a>	script for a single step of incremental analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_OneStep_wLoadHistwSD" class="code" title="">S_OneStep_wLoadHistwSD</a>	am not sure that this script is useful (FCF, January 10, 2021)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->