---
title: Static Analysis
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Static Analysis`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Static Analysis

<table>
<tr><td><a href="Event2Event_NLAnalysis">Event2Event_NLAnalysis</a></td><td>event-to-event incremental analysis with linear or P-DELTA geometry </td></tr><tr><td><a href="Incipient_Collapse_State">Incipient_Collapse_State</a></td><td>STATE determine basic forces, free DOF displacements and plastic deformations at incipient collapse </td></tr><tr><td><a href="Increment">Increment</a></td><td>load incrementation and state advance under static conditions </td></tr><tr><td><a href="Initialize">Initialize</a></td><td>initialize analysis variables in STATE and load control parameters in SOLSTRAT </td></tr><tr><td><a href="Initialize_SolStrat">Initialize_SolStrat</a></td><td>default values for most solution strategy parameters </td></tr><tr><td><a href="Initialize_State">Initialize_State</a></td><td>initialize state variables of structural model and create STATE </td></tr><tr><td><a href="Iterate">Iterate</a></td><td>equilibrium iterations until convergence under static conditions </td></tr><tr><td><a href="LinearStep">LinearStep</a></td><td>sets up and solves the structure equilibrium equations for single load step </td></tr><tr><td><a href="LoadFactorControl">LoadFactorControl</a></td><td>determine load factor increment under load control strategy </td></tr><tr><td><a href="LoadFactorIncrement">LoadFactorIncrement</a></td><td>load factor increment(s) for given load histories </td></tr><tr><td><a href="MomntCurvAnalysis">MomntCurvAnalysis</a></td><td>moment-curvature analysis of section under constant or variable normal force </td></tr><tr><td><a href="OneIteration">OneIteration</a></td><td>single equilibrium iteration under static conditions </td></tr><tr><td><a href="PlasticAnalysis">PlasticAnalysis</a></td><td>collapse load factor, basic forces, and collapse mechanism by plastic analysis </td></tr><tr><td><a href="PlasticAnalysis_wBx">PlasticAnalysis_wBx</a></td><td>collapse load factor and basic element forces by lower bound theorem of plastic analysis </td></tr><tr><td><a href="PlasticAnalysis_wLBT">PlasticAnalysis_wLBT</a></td><td>collapse load factor and basic element forces by lower bound theorem of plastic analysis </td></tr><tr><td><a href="PlasticAnalysis_wUBT">PlasticAnalysis_wUBT</a></td><td>collapse load factor and deformation increments by upper bound theorem of plastic analysis </td></tr><tr><td><a href="StateDetermination">StateDetermination</a></td><td>structure state determination under static conditions </td></tr><tr><td><a href="Update_State">Update_State</a></td><td>final state determination under static conditions, reset increments and history </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->