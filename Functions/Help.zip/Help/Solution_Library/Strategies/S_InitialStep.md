
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_InitialStep</div>

--------------------------

# `S_InitialStep`


## <a name="_name"></a>Purpose

script for initial step of incremental analysis


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INITIALSTEP script for initial step of incremental analysis
  the script initializes the state of the structural model and sets up the necessary
  variables for the load factor evolution under the given load pattern;
  it starts the post-processing counter pc and saves the initial response state in  Post;
  after this it performs a single load step of static analysis with the parameters in SolStrat</pre>
<!-- <div class="fragment"><pre class="comment">INITIALSTEP script for initial step of incremental analysis
  the script initializes the state of the structural model and sets up the necessary
  variables for the load factor evolution under the given load pattern;
  it starts the post-processing counter pc and saves the initial response state in  Post;
  after this it performs a single load step of static analysis with the parameters in SolStrat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize" class="code" title="[State,SolStrat] = Initialize (Model,ElemData,Loading,State,SolStrat)">Initialize</a>	initialize analysis variables in STATE and load control parameters in SOLSTRAT</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize_State" class="code" title="State = Initialize_State (Model,ElemData)">Initialize_State</a>	initialize state variables of structural model and create STATE</li><li><a href="../../../Solution_Library/Static_Analysis/Iterate" class="code" title="[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)">Iterate</a>	equilibrium iterations until convergence under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Update_State" class="code" title="State = Update_State (Model,ElemData,State)">Update_State</a>	final state determination under static conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_BucklingLoad" class="code" title="">S_BucklingLoad</a>	general script for determining the buckling load of a structural model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->