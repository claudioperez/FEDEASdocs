
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_MultiStep</div>

--------------------------

# `S_MultiStep`


## <a name="_name"></a>Purpose

script for multi-step incremental analysis after load factor initialization


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MULTISTEP script for multi-step incremental analysis after load factor initialization
  the script sets up the necessary variables for the load factor evolution under the
  the given load pattern; it initializes the state of the structural model,
  only if the variable State does not exist in the workspace;
  it is, therefore, useful for incremental analysis after a change in the load pattern;
  it initializes the counter pc only if it does not exist in the workspace and saves
  post-processing information of the first response state;
  it performs (nostep) load steps of static analysis with the parameters in SolStrat</pre>
<!-- <div class="fragment"><pre class="comment">MULTISTEP script for multi-step incremental analysis after load factor initialization
  the script sets up the necessary variables for the load factor evolution under the
  the given load pattern; it initializes the state of the structural model,
  only if the variable State does not exist in the workspace;
  it is, therefore, useful for incremental analysis after a change in the load pattern;
  it initializes the counter pc only if it does not exist in the workspace and saves
  post-processing information of the first response state;
  it performs (nostep) load steps of static analysis with the parameters in SolStrat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize" class="code" title="[State,SolStrat] = Initialize (Model,ElemData,Loading,State,SolStrat)">Initialize</a>	initialize analysis variables in STATE and load control parameters in SOLSTRAT</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize_State" class="code" title="State = Initialize_State (Model,ElemData)">Initialize_State</a>	initialize state variables of structural model and create STATE</li><li><a href="../../../Solution_Library/Static_Analysis/Iterate" class="code" title="[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)">Iterate</a>	equilibrium iterations until convergence under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Update_State" class="code" title="State = Update_State (Model,ElemData,State)">Update_State</a>	final state determination under static conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_NMAnalysis" class="code" title="">S_NMAnalysis</a>	script for incremental application of N-M pair on section</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->