
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_MultiStep_wLoadHistCont</div>

--------------------------

# `S_MultiStep_wLoadHistCont`


## <a name="_name"></a>Purpose

script for multi-step incremental analysis under given load history(ies)


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MULTISTEP_wLOADHISTCONT script for multi-step incremental analysis under given load history(ies) 
  the script performs several load steps of static analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax;
  because it does not initialize the state or the parameters for the load factor evolution,
  it is suitable for the continuation of an incremental multi-step static analysis
  with the parameters in SolStrat</pre>
<!-- <div class="fragment"><pre class="comment">MULTISTEP_wLOADHISTCONT script for multi-step incremental analysis under given load history(ies) 
  the script performs several load steps of static analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax;
  because it does not initialize the state or the parameters for the load factor evolution,
  it is suitable for the continuation of an incremental multi-step static analysis
  with the parameters in SolStrat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Iterate" class="code" title="[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)">Iterate</a>	equilibrium iterations until convergence under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Update_State" class="code" title="State = Update_State (Model,ElemData,State)">Update_State</a>	final state determination under static conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->