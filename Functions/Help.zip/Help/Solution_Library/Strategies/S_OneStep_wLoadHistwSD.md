
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_OneStep_wLoadHistwSD</div>

--------------------------

# `S_OneStep_wLoadHistwSD`


## <a name="_name"></a>Purpose

am not sure that this script is useful (FCF, January 10, 2021)


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"> I am not sure that this script is useful (FCF, January 10, 2021)</pre>
<!-- <div class="fragment"><pre class="comment"> I am not sure that this script is useful (FCF, January 10, 2021)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Increment" class="code" title="[State,SolStrat] = Increment(Model,ElemData,Loading,State,SolStrat)">Increment</a>	load incrementation and state advance under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Iterate" class="code" title="[State,SolStrat] = Iterate (Model,ElemData,Loading,State,SolStrat)">Iterate</a>	equilibrium iterations until convergence under static conditions</li><li><a href="../../../Solution_Library/Static_Analysis/Update_State" class="code" title="State = Update_State (Model,ElemData,State)">Update_State</a>	final state determination under static conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->