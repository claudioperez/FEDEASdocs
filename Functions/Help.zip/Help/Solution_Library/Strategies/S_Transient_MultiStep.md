
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_Transient_MultiStep</div>

--------------------------

# `S_Transient_MultiStep`


## <a name="_name"></a>Purpose

script for multi-step transient analysis under given load history(ies)


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSIENT_MULTISTEP script for multi-step transient analysis under given load history(ies)                         
  the script sets up the necessary variables for the load factor evolution for the
  transient analysis under one or more more load patterns with given load histories;
  it initializes the state of the structural model, only if the variable State does not exist;
  it is, therefore, useful both for the application of load patterns with load histories
  from the unstressed state or for the continuation of incremental analysis
  after a change of the load patterns or the load histories;
  it initializes the counter pc only if it does not exist in the workspace and saves
  post-processing information of the initial response state;
  it performs several load steps of static analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax</pre>
<!-- <div class="fragment"><pre class="comment">TRANSIENT_MULTISTEP script for multi-step transient analysis under given load history(ies)                         
  the script sets up the necessary variables for the load factor evolution for the
  transient analysis under one or more more load patterns with given load histories;
  it initializes the state of the structural model, only if the variable State does not exist;
  it is, therefore, useful both for the application of load patterns with load histories
  from the unstressed state or for the continuation of incremental analysis
  after a change of the load patterns or the load histories;
  it initializes the counter pc only if it does not exist in the workspace and saves
  post-processing information of the initial response state;
  it performs several load steps of static analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Static_Analysis/Initialize_State" class="code" title="State = Initialize_State (Model,ElemData)">Initialize_State</a>	initialize state variables of structural model and create STATE</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientIncrement" class="code" title="[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)">TransientIncrement</a>	load incrementation and state advance under transient conditions</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientInitialize" class="code" title="State = TransientInitialize (Model,ElemData,Loading,State)">TransientInitialize</a>	initialize State variables for transient response analysis</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientIterate" class="code" title="[State,SolStrat] = TransientIterate (Model,ElemData,Loading,State,SolStrat)">TransientIterate</a>	equilibrium iterations until convergence under transient conditions</li><li><a href="../../../Solution_Library/Transient_Analysis/Update_TransientState" class="code" title="State = Update_TransientState (Model,ElemData,State,SolStrat)">Update_TransientState</a>	final state determination under transient conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->