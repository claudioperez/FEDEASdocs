
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Strategies</a> &gt; S_Transient_MultiStep_ContwSD</div>

--------------------------

# `S_Transient_MultiStep_ContwSD`


## <a name="_name"></a>Purpose

script for multi-step transient analysis under given load history(ies)


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSIENT_MULTISTEP_CONTwSD script for multi-step transient analysis under given load history(ies) 
                                with automatic time step division and rescaling
  the script performs several steps of transient analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax;
  because it does not initialize the state or the parameters for the load factor evolution,
  it is suitable for the continuation of a multi-step transient analysis
  with the parameters in SolStrat</pre>
<!-- <div class="fragment"><pre class="comment">TRANSIENT_MULTISTEP_CONTwSD script for multi-step transient analysis under given load history(ies) 
                                with automatic time step division and rescaling
  the script performs several steps of transient analysis with the parameters in SolStrat
  until the pseudo-time parameter Time in State exceeds the specified maximum time Tmax;
  because it does not initialize the state or the parameters for the load factor evolution,
  it is suitable for the continuation of a multi-step transient analysis
  with the parameters in SolStrat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientIncrement" class="code" title="[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)">TransientIncrement</a>	load incrementation and state advance under transient conditions</li><li><a href="../../../Solution_Library/Transient_Analysis/TransientIterate" class="code" title="[State,SolStrat] = TransientIterate (Model,ElemData,Loading,State,SolStrat)">TransientIterate</a>	equilibrium iterations until convergence under transient conditions</li><li><a href="../../../Solution_Library/Transient_Analysis/Update_TransientState" class="code" title="State = Update_TransientState (Model,ElemData,State,SolStrat)">Update_TransientState</a>	final state determination under transient conditions, reset increments and history</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->