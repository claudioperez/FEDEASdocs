---
title: Strategies
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Strategies`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Strategies

<table>
<tr><td><a href="S_InitialStep">S_InitialStep</a></td><td>script for initial step of incremental analysis </td></tr><tr><td><a href="S_MultiStep">S_MultiStep</a></td><td>script for multi-step incremental analysis after load factor initialization </td></tr><tr><td><a href="S_MultiStep_Cont">S_MultiStep_Cont</a></td><td>script for continuation of multi-step incremental analysis </td></tr><tr><td><a href="S_MultiStep_wLoadHist">S_MultiStep_wLoadHist</a></td><td>script for multi-step incremental analysis under given load history(ies) </td></tr><tr><td><a href="S_MultiStep_wLoadHistCont">S_MultiStep_wLoadHistCont</a></td><td>script for multi-step incremental analysis under given load history(ies) </td></tr><tr><td><a href="S_MultiStep_wLoadHistContwSD">S_MultiStep_wLoadHistContwSD</a></td><td>script for multi-step incremental analysis under given load history(ies) </td></tr><tr><td><a href="S_MultiStep_wLoadHistwSD">S_MultiStep_wLoadHistwSD</a></td><td>script for multi-step incremental analysis under given load history(ies) </td></tr><tr><td><a href="S_OneStep_wLoadHist">S_OneStep_wLoadHist</a></td><td>script for a single step of incremental analysis under given load history(ies) </td></tr><tr><td><a href="S_OneStep_wLoadHistwSD">S_OneStep_wLoadHistwSD</a></td><td>am not sure that this script is useful (FCF, January 10, 2021) </td></tr><tr><td><a href="S_Transient_MultiStep">S_Transient_MultiStep</a></td><td>script for multi-step transient analysis under given load history(ies) </td></tr><tr><td><a href="S_Transient_MultiStep_Cont">S_Transient_MultiStep_Cont</a></td><td>script for multi-step transient analysis under given load history(ies) </td></tr><tr><td><a href="S_Transient_MultiStep_ContwSD">S_Transient_MultiStep_ContwSD</a></td><td>script for multi-step transient analysis under given load history(ies) </td></tr><tr><td><a href="S_Transient_MultiStepwSD">S_Transient_MultiStepwSD</a></td><td>script for multi-step transient analysis under given load history(ies) </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->