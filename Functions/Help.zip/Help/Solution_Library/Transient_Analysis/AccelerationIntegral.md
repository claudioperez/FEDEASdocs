
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; AccelerationIntegral</div>

--------------------------

# `AccelerationIntegral`


## <a name="_name"></a>Purpose

determines displacement and velocity history for given acceleration history


## <a name="_synopsis"></a>Synopsis

`[u,udot] = AccelerationIntegral (uddot,Deltat,nstep)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ACCELERATIONINTEGRAL determines displacement and velocity history for given acceleration history 
  [U,UDOT] = ACCELERATIONINTEGRAL (UDDOT,DELTAT,NSTEP,U0,UDOT0)
  the function integrates the acceleration history in array UDDOT to determine
  the displacement history in array U and the velocity history in array UDOT;
  the time step of the acceleration record is DELTAT
  and the total number of steps is NSTEP (default = no of acceleration values);
  the displacement and the velocity history are corrected for zero end values</pre>
<!-- <div class="fragment"><pre class="comment">ACCELERATIONINTEGRAL determines displacement and velocity history for given acceleration history 
  [U,UDOT] = ACCELERATIONINTEGRAL (UDDOT,DELTAT,NSTEP,U0,UDOT0)
  the function integrates the acceleration history in array UDDOT to determine
  the displacement history in array U and the velocity history in array UDOT;
  the time step of the acceleration record is DELTAT
  and the total number of steps is NSTEP (default = no of acceleration values);
  the displacement and the velocity history are corrected for zero end values</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->