
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; Create_GrndAcc</div>

--------------------------

# `Create_GrndAcc`


## <a name="_name"></a>Purpose

function for setting up ground acceleration time histories


## <a name="_synopsis"></a>Synopsis

`GrndAcc = Create_GrndAcc(Directions,FileNames,ScaleFactors)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_GRNDACC function for setting up ground acceleration time histories    
 GrndAcc = Create_GrndAcc(Directions,FileNames,ScaleFactors)
 Directions   = cell array of strings with labels of global orientation for acceleration
                time-histories, e.g. {'X' 'Y'} 
 FileNames    = cell array of strings with file names of acceleration records,
                e.g. {'groundX.acc' 'groundY.acc'} 
 ScaleFactors = vector with scale factors for different acceleration records</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_GRNDACC function for setting up ground acceleration time histories    
 GrndAcc = Create_GrndAcc(Directions,FileNames,ScaleFactors)
 Directions   = cell array of strings with labels of global orientation for acceleration
                time-histories, e.g. {'X' 'Y'} 
 FileNames    = cell array of strings with file names of acceleration records,
                e.g. {'groundX.acc' 'groundY.acc'} 
 ScaleFactors = vector with scale factors for different acceleration records</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->