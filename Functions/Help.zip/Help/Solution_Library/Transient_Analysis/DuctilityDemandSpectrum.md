
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; DuctilityDemandSpectrum</div>

--------------------------

# `DuctilityDemandSpectrum`


## <a name="_name"></a>Purpose

determines the ductility demand spectrum for given acceleration history


## <a name="_synopsis"></a>Synopsis

`mu = DuctilityDemandSpectrum (Acceleration,Ry,T,zeta)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DUCTILITYDEMANDSPECTRUM determines the ductility demand spectrum for given acceleration history
  MU = DUCTILITYDEMANDSPECTRUM (ACCELERATION,RY,T,Z)
  the function determines the ductility demand spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value)
  and for given yield strength reduction factor(s) in row vector RY;
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 )
  the ductility demand values for the periods in row vector T are returned
  in array MU with the row number corresponding to the period and
  the column number to the yield strength reduction factor</pre>
<!-- <div class="fragment"><pre class="comment">DUCTILITYDEMANDSPECTRUM determines the ductility demand spectrum for given acceleration history
  MU = DUCTILITYDEMANDSPECTRUM (ACCELERATION,RY,T,Z)
  the function determines the ductility demand spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value)
  and for given yield strength reduction factor(s) in row vector RY;
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 )
  the ductility demand values for the periods in row vector T are returned
  in array MU with the row number corresponding to the period and
  the column number to the yield strength reduction factor</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../InelSDOF_Newmark" class="code" title="[u,udot,uddot,pr] = InelSDOF_Newmark (Deltat,omega,p,InelSDFData,zeta,u0,udot0)">InelSDOF_Newmark</a>	inelastic response of SDOF system to acceleration history with Newmark's method</li><li><a href="../LSDOF_Newmark" class="code" title="[u,udot,uddot] = LSDOF_Newmark (Deltat,omega,p,zeta,u0,udot0)">LSDOF_Newmark</a>	determines the response of linear SDOF system to acceleration history with Newmark's method</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->