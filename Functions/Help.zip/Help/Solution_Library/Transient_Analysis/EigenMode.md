
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; EigenMode</div>

--------------------------

# `EigenMode`


## <a name="_name"></a>Purpose

determines eigenfrequencies and eigenmodes of structural model


## <a name="_synopsis"></a>Synopsis

`[omega,Ueig] = EigenMode (Kf,M,nmod)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">EIGENMODE determines eigenfrequencies and eigenmodes of structural model
  [OMEGA UEIG] = EIGENMODE(KF,M,NMOD)
  function determines the lowest NMOD (default=all) eigenfrequencies in row vector OMEGA
  and corresponding eigenmodes in array UEIG for a structure with free dof stiffness matrix KF
  and free dof lumped mass vector or consistent mass matrix M;
  the eigenmodes in array UEIG are arranged columnwise (column no=mode no)</pre>
<!-- <div class="fragment"><pre class="comment">EIGENMODE determines eigenfrequencies and eigenmodes of structural model
  [OMEGA UEIG] = EIGENMODE(KF,M,NMOD)
  function determines the lowest NMOD (default=all) eigenfrequencies in row vector OMEGA
  and corresponding eigenmodes in array UEIG for a structure with free dof stiffness matrix KF
  and free dof lumped mass vector or consistent mass matrix M;
  the eigenmodes in array UEIG are arranged columnwise (column no=mode no)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Condense_MV" class="code" title="[Kfc,Pfc] = Condense_MV (Kf,idr,Pf)">Condense_MV</a>	condense matrix Kf and vector Pf to a reduced set idr of degrees of freedom</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Create_Damping" class="code" title="C = Create_Damping (type,Kf,Ml,zeta,mode)">Create_Damping</a>	setup damping matrix of structural model</li><li><a href="../ModalAnalysis" class="code" title="[omega,Ueig,Y_t,Ydot_t,Yddot_t] = ModalAnalysis (option,Kf,M,Loading,Deltat,zeta,nmod)">ModalAnalysis</a>	determines modal response history for given transient loading</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->