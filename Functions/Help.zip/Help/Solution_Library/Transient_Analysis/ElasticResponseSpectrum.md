
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; ElasticResponseSpectrum</div>

--------------------------

# `ElasticResponseSpectrum`


## <a name="_name"></a>Purpose

determines the elastic response spectrum for given acceleration history


## <a name="_synopsis"></a>Synopsis

`[D,Psv,Psa] = ElasticResponseSpectrum (Acceleration,T,zeta)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ELASTICRESPONSESPECTRUM determines the elastic response spectrum for given acceleration history
  [D,PSV,PSA] = ELASTICRESPONSESPECTRUM (ACCELERATION,T,ZETA)
  the function determines the elastic response spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value);
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 );
  the response spectrum values for the periods in row vector T are returned
  in arrays D for displacement, PSV for pseudo-velocity, and PSA for pseudo-acceleration
  with the row number corresponding to the period and the column number to the damping ratio</pre>
<!-- <div class="fragment"><pre class="comment">ELASTICRESPONSESPECTRUM determines the elastic response spectrum for given acceleration history
  [D,PSV,PSA] = ELASTICRESPONSESPECTRUM (ACCELERATION,T,ZETA)
  the function determines the elastic response spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value);
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 );
  the response spectrum values for the periods in row vector T are returned
  in arrays D for displacement, PSV for pseudo-velocity, and PSA for pseudo-acceleration
  with the row number corresponding to the period and the column number to the damping ratio</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../LSDOF_LinearWilson" class="code" title="[u,udot,uddot] = LSDOF_LinearWilson (Deltat,omega,p,zeta,u0,udot0)">LSDOF_LinearWilson</a>	transient response of linear SDOF system by exact integration of piecewise linear excitation</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/General/ElasticSpectra4EQRecord" class="code" title="Fig = ElasticSpectra4EQRecord(AccHst,Options)">ElasticSpectra4EQRecord</a>	generates elastic response spectra for earthquake record</li><li><a href="../../../Utilities/General/S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../../../Utilities/General/S_Process_EQRecordO" class="code" title="">S_Process_EQRecordO</a>	% script for processing ground motion records in PEER database format</li><li><a href="../../../Utilities/Plotting/Plot_EQRecord" class="code" title="">Plot_EQRecord</a>	% script for processing ground motion records</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->