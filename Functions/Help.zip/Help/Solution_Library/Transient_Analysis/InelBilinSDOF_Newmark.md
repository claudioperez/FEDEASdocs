
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; InelBilinSDOF_Newmark</div>

--------------------------

# `InelBilinSDOF_Newmark`


## <a name="_name"></a>Purpose

determines the response of inelastic bilinear SDOF system to acceleration history with Newmark's method


## <a name="_synopsis"></a>Synopsis

`[u,udot,uddot,Pr] = InelBilinSDOF_Newmark (Deltat,omega,p,MatData,zeta,u0,udot0)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INELBILINSDOF_NEWMARK determines the response of inelastic bilinear SDOF system to acceleration history with Newmark's method
  [U,UDOT,UDDOT,PR] = INELSDOF_NEWMARK (DELT,OMEGA,P,ZETA,U0,UDOT0)
  function determines the transient response history of inelastic bilinear SDOF system(s)
 with eigenfrequency(ies) in row vector OMEGA, to acceleration history (force/mass) in vector P,
  for damping ratio(s) in row vector ZETA (default=0),
  and initial conditions in row vectors U0 (displacement) and UDOT0 (velocity) (default values=0);
  the time step of integration is DELTAT;
  N.M. Newmark's method from 1959 is used for the numerical integration of the equations of motion;
  the properties of the force-deformation relation are supplied in data structure MATDATA;
  the function returns the displacement history(ies) in array U, the velocity history(ies)
  in array UDOT, the acceleration history(ies) in array UDDOT,
  and the resisting force history(ies) in array PR (also in the form force/mass!);
  these arrays are arranged columnwise (column no=frequency no)</pre>
<!-- <div class="fragment"><pre class="comment">INELBILINSDOF_NEWMARK determines the response of inelastic bilinear SDOF system to acceleration history with Newmark's method
  [U,UDOT,UDDOT,PR] = INELSDOF_NEWMARK (DELT,OMEGA,P,ZETA,U0,UDOT0)
  function determines the transient response history of inelastic bilinear SDOF system(s)
 with eigenfrequency(ies) in row vector OMEGA, to acceleration history (force/mass) in vector P,
  for damping ratio(s) in row vector ZETA (default=0),
  and initial conditions in row vectors U0 (displacement) and UDOT0 (velocity) (default values=0);
  the time step of integration is DELTAT;
  N.M. Newmark's method from 1959 is used for the numerical integration of the equations of motion;
  the properties of the force-deformation relation are supplied in data structure MATDATA;
  the function returns the displacement history(ies) in array U, the velocity history(ies)
  in array UDOT, the acceleration history(ies) in array UDDOT,
  and the resisting force history(ies) in array PR (also in the form force/mass!);
  these arrays are arranged columnwise (column no=frequency no)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->