
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; InelSDOF_Newmark</div>

--------------------------

# `InelSDOF_Newmark`


## <a name="_name"></a>Purpose

inelastic response of SDOF system to acceleration history with Newmark's method


## <a name="_synopsis"></a>Synopsis

`[u,udot,uddot,pr] = InelSDOF_Newmark (Deltat,omega,p,InelSDFData,zeta,u0,udot0)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INELSDOF_NEWMARK inelastic response of SDOF system to acceleration history with Newmark's method
  [U,UDOT,UDDOT,PR] = INELSDOF_NEWMARK (DELT,OMEGA,P,INELSDFDATA,ZETA,U0,UDOT0)
  the function determines the transient response history of an inelastic SDOF system
  to the acceleration history (force/mass) in vector P
  with Newmark's constant average acceleration method (1959)
  with time step of integration DELTAT;
  row vector OMEGA contains the eigenfrequency(ies) of the SDOF system,
  and row vector ZETA the optional damping ratio(s) (default = 0);
  the optional initial conditions are specified in row vectors U0 for the displacement
  and UDOT0 for the velocity (default values for both = 0);
  INELSDFDATA carries the force-deformation properties for the inelastic SDOF system:
  MatName = function name for 1d relation (default = InelLPwLH1dMat)
  uy      = yield displacement         (default = 1)
  eta     = post-yield stiffness ratio (default = 0)
  the function returns the displacement history(ies) in array U,
  the velocity history(ies) in array UDOT,
  the acceleration history(ies) in array UDDOT,
  and the resisting force history(ies) in array PR (also in the form force/mass!);
  these arrays are arranged columnwise (column no=frequency no)</pre>
<!-- <div class="fragment"><pre class="comment">INELSDOF_NEWMARK inelastic response of SDOF system to acceleration history with Newmark's method
  [U,UDOT,UDDOT,PR] = INELSDOF_NEWMARK (DELT,OMEGA,P,INELSDFDATA,ZETA,U0,UDOT0)
  the function determines the transient response history of an inelastic SDOF system
  to the acceleration history (force/mass) in vector P
  with Newmark's constant average acceleration method (1959)
  with time step of integration DELTAT;
  row vector OMEGA contains the eigenfrequency(ies) of the SDOF system,
  and row vector ZETA the optional damping ratio(s) (default = 0);
  the optional initial conditions are specified in row vectors U0 for the displacement
  and UDOT0 for the velocity (default values for both = 0);
  INELSDFDATA carries the force-deformation properties for the inelastic SDOF system:
  MatName = function name for 1d relation (default = InelLPwLH1dMat)
  uy      = yield displacement         (default = 1)
  eta     = post-yield stiffness ratio (default = 0)
  the function returns the displacement history(ies) in array U,
  the velocity history(ies) in array UDOT,
  the acceleration history(ies) in array UDDOT,
  and the resisting force history(ies) in array PR (also in the form force/mass!);
  these arrays are arranged columnwise (column no=frequency no)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../DuctilityDemandSpectrum" class="code" title="mu = DuctilityDemandSpectrum (Acceleration,Ry,T,zeta)">DuctilityDemandSpectrum</a>	determines the ductility demand spectrum for given acceleration history</li><li><a href="../InelasticResponseSpectrum" class="code" title="[D,V,A] = InelasticResponseSpectrum (Acceleration,MatData,T,zeta)">InelasticResponseSpectrum</a>	determines the inelastic response spectrum for given acceleration history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->