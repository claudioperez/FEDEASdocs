
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; InelasticResponseSpectrum</div>

--------------------------

# `InelasticResponseSpectrum`


## <a name="_name"></a>Purpose

determines the inelastic response spectrum for given acceleration history


## <a name="_synopsis"></a>Synopsis

`[D,V,A] = InelasticResponseSpectrum (Acceleration,MatData,T,zeta)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">INELASTICRESPONSESPECTRUM determines the inelastic response spectrum for given acceleration history
  [D,V,A] = INELASTICRESPONSESPECTRUM (ACCELERATION,MATDATA,T,ZETA)
  the function determines the inelastic response spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value);
  the properties of the force-deformation relation are supplied in data structure MATDATA;
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 );
  the response spectrum values for the periods in row vector T
  are returned in arrays D for displacement, V for velocity, and A for acceleration
  with the row number corresponding to the period and the column number to the damping ratio</pre>
<!-- <div class="fragment"><pre class="comment">INELASTICRESPONSESPECTRUM determines the inelastic response spectrum for given acceleration history
  [D,V,A] = INELASTICRESPONSESPECTRUM (ACCELERATION,MATDATA,T,ZETA)
  the function determines the inelastic response spectrum for a given acceleration history in
  data structure ACCELERATION with fields Deltat (time step size) and Value (acceleration value);
  the properties of the force-deformation relation are supplied in data structure MATDATA;
  the periods for the spectrum are specified in row vector T ( default= [0.001 0.1:0.1:5] );
  the row vector ZETA contains the damping ratio(s) ( default=0 );
  the response spectrum values for the periods in row vector T
  are returned in arrays D for displacement, V for velocity, and A for acceleration
  with the row number corresponding to the period and the column number to the damping ratio</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../InelSDOF_Newmark" class="code" title="[u,udot,uddot,pr] = InelSDOF_Newmark (Deltat,omega,p,InelSDFData,zeta,u0,udot0)">InelSDOF_Newmark</a>	inelastic response of SDOF system to acceleration history with Newmark's method</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->