
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; LDRitzVectors</div>

--------------------------

# `LDRitzVectors`


## <a name="_name"></a>Purpose

generation of mass and stiffness orthogonal Load Dependent Ritz vectors


## <a name="_synopsis"></a>Synopsis

`[LDR,omega] = LDRitzVectors (Kf,M,Pref,nov)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LDRITZVECTORS generation of mass and stiffness orthogonal Load Dependent Ritz vectors
  generation of nov Load Dependent Ritz vectors that are orthonormal to
  the lumped mass matrix M and orthogonal to the stiffenss matrix Kf
  INPUT -----------------------------
  Kf   : nf x nf stiffness matrix
  M    : mass matrix or lumped mass vector
  Pref : vector of applied force distribution 
  nov  : number of Load Dependent Ritz vectors
  OUTPUT ----------------------------
  LDR   : Load-Dependent Ritz vectors
  omega : eigenfrequencies of reduced problem</pre>
<!-- <div class="fragment"><pre class="comment">LDRITZVECTORS generation of mass and stiffness orthogonal Load Dependent Ritz vectors
  generation of nov Load Dependent Ritz vectors that are orthonormal to
  the lumped mass matrix M and orthogonal to the stiffenss matrix Kf
  INPUT -----------------------------
  Kf   : nf x nf stiffness matrix
  M    : mass matrix or lumped mass vector
  Pref : vector of applied force distribution 
  nov  : number of Load Dependent Ritz vectors
  OUTPUT ----------------------------
  LDR   : Load-Dependent Ritz vectors
  omega : eigenfrequencies of reduced problem</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../ModalAnalysis" class="code" title="[omega,Ueig,Y_t,Ydot_t,Yddot_t] = ModalAnalysis (option,Kf,M,Loading,Deltat,zeta,nmod)">ModalAnalysis</a>	determines modal response history for given transient loading</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->