
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; LSDOF_CentralDifference</div>

--------------------------

# `LSDOF_CentralDifference`


## <a name="_name"></a>Purpose

determines the response of linear SDOF system to acceleration history with central difference method


## <a name="_synopsis"></a>Synopsis

`[u,udot,uddot] = LSDOF_CentralDifference (Deltat,omega,p,zeta,u0,udot0)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LSDOF_CENTRALDIFFERENCE determines the response of linear SDOF system to acceleration history with central difference method
  [U,UDOT,UDDOT] = LSDOF_CENTRALDIFFERENCE (DELTAT,OMEGA,P,ZETA,U0,UDOT0)
  function determines the transient response history of linear SDOF system(s) with eigenfrequency(ies)
  in row vector OMEGA, to acceleration history (force/mass) in vector P,
  for damping ratio(s) in row vector ZETA (default=0),
  and initial conditions in row vectors U0 (displacement) and UDOT0 (velocity) (default values=0);
  the time step of integration is DELTAT;
  the central difference method is used for the numerical integration of the equations of motion;
  the function returns the displacement history(ies) in array U, the velocity history(ies)
  in array UDOT and the acceleration history(ies) in array UDDOT arranged columnwise (column no=frequency no);
  Reference: A.K.Chopra, Dynamics of Structures, 2nd edition, pp. 171-174</pre>
<!-- <div class="fragment"><pre class="comment">LSDOF_CENTRALDIFFERENCE determines the response of linear SDOF system to acceleration history with central difference method
  [U,UDOT,UDDOT] = LSDOF_CENTRALDIFFERENCE (DELTAT,OMEGA,P,ZETA,U0,UDOT0)
  function determines the transient response history of linear SDOF system(s) with eigenfrequency(ies)
  in row vector OMEGA, to acceleration history (force/mass) in vector P,
  for damping ratio(s) in row vector ZETA (default=0),
  and initial conditions in row vectors U0 (displacement) and UDOT0 (velocity) (default values=0);
  the time step of integration is DELTAT;
  the central difference method is used for the numerical integration of the equations of motion;
  the function returns the displacement history(ies) in array U, the velocity history(ies)
  in array UDOT and the acceleration history(ies) in array UDDOT arranged columnwise (column no=frequency no);
  Reference: A.K.Chopra, Dynamics of Structures, 2nd edition, pp. 171-174</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->