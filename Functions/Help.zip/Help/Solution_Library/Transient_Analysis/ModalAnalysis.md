
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; ModalAnalysis</div>

--------------------------

# `ModalAnalysis`


## <a name="_name"></a>Purpose

determines modal response history for given transient loading


## <a name="_synopsis"></a>Synopsis

`[omega,Ueig,Y_t,Ydot_t,Yddot_t] = ModalAnalysis (option,Kf,M,Loading,Deltat,zeta,nmod)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MODALANALYSIS determines modal response history for given transient loading
  [OMEGA,UEIG,Y_T,YDOT_T,YDDOT_T] = MODALANALYSIS (OPTION,KF,M,LOADING,DELTAT,ZETA,NMOD)
  the function determines the response history of a multi-dof structural model
  with stiffness matrix at free dofs KF and consistent mass matrix or lumped mass vector M
  under given transient loading in data structure LOADING
  for the lowest NMOD (default=all) eigenmodes or NMOD Ritz vectors
  with damping ratios in row vector ZETA (default=0);
  the time step of integration is DELTAT;
        OPTION = 'eig'  uses nmod eigenvectors,
  while OPTION = 'Ritz' uses nmod Ritz vectors in the modal analysis; 
  the function returns NMOD eigenfrequencies of the structural model in row vector OMEGA,
  the eigenmode or Ritz vector shapes in array UEIG arranged columnwise (column no=mode no),
  and the response history of each eigenmode or Ritz vector
  in array Y_T arranged columnwise (column no=mode no),
  the velocity history of each eigenmode or Ritz vector in array YDOT_t, and
  the acceleration history of each eigenmode or Ritz vector in array YDDOT_t
  the data structure LOADING has the following fields
  LOADING.Uddref = vector of reference acceleration values at model dofs
          Pref   = vector of reference load         values at model dofs
          U0     = vector of initial displacement   values at model dofs
          Udot0  = vector of initial velocity       values at model dofs
          FrcHst = force time history in field Value
          AccHst = acceleration time history in field Value</pre>
<!-- <div class="fragment"><pre class="comment">MODALANALYSIS determines modal response history for given transient loading
  [OMEGA,UEIG,Y_T,YDOT_T,YDDOT_T] = MODALANALYSIS (OPTION,KF,M,LOADING,DELTAT,ZETA,NMOD)
  the function determines the response history of a multi-dof structural model
  with stiffness matrix at free dofs KF and consistent mass matrix or lumped mass vector M
  under given transient loading in data structure LOADING
  for the lowest NMOD (default=all) eigenmodes or NMOD Ritz vectors
  with damping ratios in row vector ZETA (default=0);
  the time step of integration is DELTAT;
        OPTION = 'eig'  uses nmod eigenvectors,
  while OPTION = 'Ritz' uses nmod Ritz vectors in the modal analysis; 
  the function returns NMOD eigenfrequencies of the structural model in row vector OMEGA,
  the eigenmode or Ritz vector shapes in array UEIG arranged columnwise (column no=mode no),
  and the response history of each eigenmode or Ritz vector
  in array Y_T arranged columnwise (column no=mode no),
  the velocity history of each eigenmode or Ritz vector in array YDOT_t, and
  the acceleration history of each eigenmode or Ritz vector in array YDDOT_t
  the data structure LOADING has the following fields
  LOADING.Uddref = vector of reference acceleration values at model dofs
          Pref   = vector of reference load         values at model dofs
          U0     = vector of initial displacement   values at model dofs
          Udot0  = vector of initial velocity       values at model dofs
          FrcHst = force time history in field Value
          AccHst = acceleration time history in field Value</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../EigenMode" class="code" title="[omega,Ueig] = EigenMode (Kf,M,nmod)">EigenMode</a>	determines eigenfrequencies and eigenmodes of structural model</li><li><a href="../LDRitzVectors" class="code" title="[LDR,omega] = LDRitzVectors (Kf,M,Pref,nov)">LDRitzVectors</a>	generation of mass and stiffness orthogonal Load Dependent Ritz vectors</li><li><a href="../LSDOF_LinearWilson" class="code" title="[u,udot,uddot] = LSDOF_LinearWilson (Deltat,omega,p,zeta,u0,udot0)">LSDOF_LinearWilson</a>	transient response of linear SDOF system by exact integration of piecewise linear excitation</li><li><a href="../ModeDecomposition" class="code" title="[Mmod,Ymod,Vmod] = ModeDecomposition (M,Ueig,V)">ModeDecomposition</a>	determines eigenmode participation factors of given vector V</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->