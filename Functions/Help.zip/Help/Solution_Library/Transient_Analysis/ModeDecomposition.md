
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; ModeDecomposition</div>

--------------------------

# `ModeDecomposition`


## <a name="_name"></a>Purpose

determines eigenmode participation factors of given vector V


## <a name="_synopsis"></a>Synopsis

`[Mmod,Ymod,Vmod] = ModeDecomposition (M,Ueig,V)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">MODEDECOMPOSITION determines eigenmode participation factors of given vector V
  [MMOD,YMOD,VMOD] = MODEDECOMPOSITION (M,UEIG,V)
  the function determines the mode participation factors of vector V
  for a structural model with consistent mass matrix or lumped mass vector M at free DOFs
  for the modes in array UEIG arranged columnwise (column no=mode no);
  the function returns the modal mass terms in row vector MMOD,
  the mode participation factors in row vector YMOD and the
  inertial force decomposition vectors in array VMOD arranged columwise
  the size of the consistent mass matrix or the length of lumped mass vector M,
  the length of vector V and the number of rows of arrays UEIG
  and VMOD is equal to the number of free dofs of the structural model;
  the length of row vectors MMOD and YMOD is equal
  to the number of non-zero mass terms in the lumped mass vector M or
  the number of free dofs of the structural model for the case of consistent mass matrix M</pre>
<!-- <div class="fragment"><pre class="comment">MODEDECOMPOSITION determines eigenmode participation factors of given vector V
  [MMOD,YMOD,VMOD] = MODEDECOMPOSITION (M,UEIG,V)
  the function determines the mode participation factors of vector V
  for a structural model with consistent mass matrix or lumped mass vector M at free DOFs
  for the modes in array UEIG arranged columnwise (column no=mode no);
  the function returns the modal mass terms in row vector MMOD,
  the mode participation factors in row vector YMOD and the
  inertial force decomposition vectors in array VMOD arranged columwise
  the size of the consistent mass matrix or the length of lumped mass vector M,
  the length of vector V and the number of rows of arrays UEIG
  and VMOD is equal to the number of free dofs of the structural model;
  the length of row vectors MMOD and YMOD is equal
  to the number of non-zero mass terms in the lumped mass vector M or
  the number of free dofs of the structural model for the case of consistent mass matrix M</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../ModalAnalysis" class="code" title="[omega,Ueig,Y_t,Ydot_t,Yddot_t] = ModalAnalysis (option,Kf,M,Loading,Deltat,zeta,nmod)">ModalAnalysis</a>	determines modal response history for given transient loading</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->