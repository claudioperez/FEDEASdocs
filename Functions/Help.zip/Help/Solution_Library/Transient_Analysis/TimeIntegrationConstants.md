
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; TimeIntegrationConstants</div>

--------------------------

# `TimeIntegrationConstants`


## <a name="_name"></a>Purpose

constants of time integration strategy


## <a name="_synopsis"></a>Synopsis

`Int_Constants = TimeIntegrationConstants (TimeStrat,option)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TIMEINTEGRATIONCONSTANTS constants of time integration strategy
  INT_CONSTANTS = TIMEINTEGRATIONCONSTANTS (TIMESTRAT)
  the function determines the constants of the time integration strategy speficied in field
  Type of data structure TIMESTRAT and returns them in vector INT_CONSTRANTS
  the data structure TIMESTRAT contains information about the integration strategy in fiels
      DELTAT = time step (scalar)
      TYPE   = name of integration method (character variable)
      PARAM  = parameters of integration method (vector)</pre>
<!-- <div class="fragment"><pre class="comment">TIMEINTEGRATIONCONSTANTS constants of time integration strategy
  INT_CONSTANTS = TIMEINTEGRATIONCONSTANTS (TIMESTRAT)
  the function determines the constants of the time integration strategy speficied in field
  Type of data structure TIMESTRAT and returns them in vector INT_CONSTRANTS
  the data structure TIMESTRAT contains information about the integration strategy in fiels
      DELTAT = time step (scalar)
      TYPE   = name of integration method (character variable)
      PARAM  = parameters of integration method (vector)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../OneTransientIteration" class="code" title="[State,SolStrat] = OneTransientIteration (Model,ElemData,Loading,State,SolStrat)">OneTransientIteration</a>	single equilibrium iteration under transient conditions</li><li><a href="../TransientIncrement" class="code" title="[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)">TransientIncrement</a>	load incrementation and state advance under transient conditions</li><li><a href="../Update_TransientState" class="code" title="State = Update_TransientState (Model,ElemData,State,SolStrat)">Update_TransientState</a>	final state determination under transient conditions, reset increments and history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->