
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; TransientIncrement</div>

--------------------------

# `TransientIncrement`


## <a name="_name"></a>Purpose

load incrementation and state advance under transient conditions


## <a name="_synopsis"></a>Synopsis

`[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSIENTINCREMENT load incrementation and state advance under transient conditions
  [STATE,SOLSTRAT] = TRANSIENTINCREMENT(MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function increments the applied loading and determines the corresponding displacement
  increments under transient conditions;
  information about the state of the structure is updated in STATE and
  information about parameters of solution strategy are updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns and corresponding load histories</pre>
<!-- <div class="fragment"><pre class="comment">TRANSIENTINCREMENT load incrementation and state advance under transient conditions
  [STATE,SOLSTRAT] = TRANSIENTINCREMENT(MODEL,ELEMDATA,LOADING,STATE,SOLSTRAT)
  the function increments the applied loading and determines the corresponding displacement
  increments under transient conditions;
  information about the state of the structure is updated in STATE and
  information about parameters of solution strategy are updated in SOLSTRAT;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force and imposed displacement patterns and corresponding load histories</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Static_Analysis/LoadFactorIncrement" class="code" title="Dlam = LoadFactorIncrement (History,Time,Deltat)">LoadFactorIncrement</a>	load factor increment(s) for given load histories</li><li><a href="../TimeIntegrationConstants" class="code" title="Int_Constants = TimeIntegrationConstants (TimeStrat,option)">TimeIntegrationConstants</a>	constants of time integration strategy</li><li><a href="../TransientStateDetermination" class="code" title="State = TransientStateDetermination (StifUpdt,Model,ElemData,State,Int_Constants)">TransientStateDetermination</a>	structure state determination under transient conditions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep" class="code" title="">S_Transient_MultiStep</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep_Cont" class="code" title="">S_Transient_MultiStep_Cont</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep_ContwSD" class="code" title="">S_Transient_MultiStep_ContwSD</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStepwSD" class="code" title="">S_Transient_MultiStepwSD</a>	script for multi-step transient analysis under given load history(ies)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->