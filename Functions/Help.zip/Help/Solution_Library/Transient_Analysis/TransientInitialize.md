
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; TransientInitialize</div>

--------------------------

# `TransientInitialize`


## <a name="_name"></a>Purpose

initialize State variables for transient response analysis


## <a name="_synopsis"></a>Synopsis

`State = TransientInitialize (Model,ElemData,Loading,State)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSIENTINITIALIZE initialize State variables for transient response analysis
  STATE = TRANSIENTINITIALIZE(MODEL,ELEMDATA,LOADING,STATE)
  the function initializes variables in STATE relevant for transient response analysis and
  returns an updated data structure STATE;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force, imposed displacement, and imposed acceleration patterns
  with corresponding load histories;
  specifically the function adds the following fields to STATE needed for transient analysis
  STATE
       lamda   = row vector of current load factors
       Pi      = initial force vector (for load sequences)
       Time    = pseudo-or real time counter
       Ugddot  = support acceleration vector
       C       = damping matrix</pre>
<!-- <div class="fragment"><pre class="comment">TRANSIENTINITIALIZE initialize State variables for transient response analysis
  STATE = TRANSIENTINITIALIZE(MODEL,ELEMDATA,LOADING,STATE)
  the function initializes variables in STATE relevant for transient response analysis and
  returns an updated data structure STATE;
  MODEL is a data structure with information about the structural model, ELEMDATA is
  a cell array with element properties, and LOADING is a data structure with information
  about applied force, imposed displacement, and imposed acceleration patterns
  with corresponding load histories;
  specifically the function adds the following fields to STATE needed for transient analysis
  STATE
       lamda   = row vector of current load factors
       Pi      = initial force vector (for load sequences)
       Time    = pseudo-or real time counter
       Ugddot  = support acceleration vector
       C       = damping matrix</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep" class="code" title="">S_Transient_MultiStep</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStepwSD" class="code" title="">S_Transient_MultiStepwSD</a>	script for multi-step transient analysis under given load history(ies)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->