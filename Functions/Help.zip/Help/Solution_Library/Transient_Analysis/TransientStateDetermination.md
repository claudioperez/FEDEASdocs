
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; TransientStateDetermination</div>

--------------------------

# `TransientStateDetermination`


## <a name="_name"></a>Purpose

structure state determination under transient conditions


## <a name="_synopsis"></a>Synopsis

`State = TransientStateDetermination (StifUpdt,Model,ElemData,State,Int_Constants)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSIENTSTATEDETERMINATION structure state determination under transient conditions
  STATE = TRANSIENTSTATEDETERMINATION (STIFUPDT,MODEL,ELEMDATA,STATE)
  the function updates the structure resisting force vector in STATE for the current
  state of the structure as described by the displacement vector and its increments as
  as well as by the history variables in STATE; the effective resisting force and tangent
  stiffness matrix depend on integration constants in cell array INT_CONSTANTS
  depending on the value of character variable STIFUPDT the function also updates
  the tangent stiffness matrix in STATE
  MODEL is a data structure with information about the structural model,
  ELEMDATA is a cell array with element properties</pre>
<!-- <div class="fragment"><pre class="comment">TRANSIENTSTATEDETERMINATION structure state determination under transient conditions
  STATE = TRANSIENTSTATEDETERMINATION (STIFUPDT,MODEL,ELEMDATA,STATE)
  the function updates the structure resisting force vector in STATE for the current
  state of the structure as described by the displacement vector and its increments as
  as well as by the history variables in STATE; the effective resisting force and tangent
  stiffness matrix depend on integration constants in cell array INT_CONSTANTS
  depending on the value of character variable STIFUPDT the function also updates
  the tangent stiffness matrix in STATE
  MODEL is a data structure with information about the structural model,
  ELEMDATA is a cell array with element properties</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../OneTransientIteration" class="code" title="[State,SolStrat] = OneTransientIteration (Model,ElemData,Loading,State,SolStrat)">OneTransientIteration</a>	single equilibrium iteration under transient conditions</li><li><a href="../TransientIncrement" class="code" title="[State,SolStrat] = TransientIncrement(Model,ElemData,Loading,State,SolStrat)">TransientIncrement</a>	load incrementation and state advance under transient conditions</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->