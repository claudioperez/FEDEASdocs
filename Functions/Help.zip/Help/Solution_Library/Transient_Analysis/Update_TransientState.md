
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Transient_Analysis</a> &gt; Update_TransientState</div>

--------------------------

# `Update_TransientState`


## <a name="_name"></a>Purpose

final state determination under transient conditions, reset increments and history


## <a name="_synopsis"></a>Synopsis

`State = Update_TransientState (Model,ElemData,State,SolStrat)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">UPDATE_TRANSIENTSTATE final state determination under transient conditions, reset increments and history
  STATE = UPDATE_TRANSIENTSTATE (MODEL,ELEMDATA,STATE,SOLSTRAT)
  the function performs a final state determination for the current state of the structure
  as described by the displacement vector and its increments as well as by the history
  variables in STATE; it then updates the structure resisting forces, and history variables
  as well as the nodal velocities and accelerations in STATE and then
  sets the displacement increments in STATE to zero
  data structure SOLSTRAT carries information about the time integration scheme in field TimeStrat</pre>
<!-- <div class="fragment"><pre class="comment">UPDATE_TRANSIENTSTATE final state determination under transient conditions, reset increments and history
  STATE = UPDATE_TRANSIENTSTATE (MODEL,ELEMDATA,STATE,SOLSTRAT)
  the function performs a final state determination for the current state of the structure
  as described by the displacement vector and its increments as well as by the history
  variables in STATE; it then updates the structure resisting forces, and history variables
  as well as the nodal velocities and accelerations in STATE and then
  sets the displacement increments in STATE to zero
  data structure SOLSTRAT carries information about the time integration scheme in field TimeStrat</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Structure" class="code" title="Resp = Structure (action,Model,ElemData,State,ElemList)">Structure</a>	performs requested action on group of elements</li><li><a href="../TimeIntegrationConstants" class="code" title="Int_Constants = TimeIntegrationConstants (TimeStrat,option)">TimeIntegrationConstants</a>	constants of time integration strategy</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep" class="code" title="">S_Transient_MultiStep</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep_Cont" class="code" title="">S_Transient_MultiStep_Cont</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStep_ContwSD" class="code" title="">S_Transient_MultiStep_ContwSD</a>	script for multi-step transient analysis under given load history(ies)</li><li><a href="../../../Solution_Library/Strategies/S_Transient_MultiStepwSD" class="code" title="">S_Transient_MultiStepwSD</a>	script for multi-step transient analysis under given load history(ies)</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->