
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; CleanStart</div>

--------------------------

# `CleanStart`


## <a name="_name"></a>Purpose

clear all variables from the base workspace and close any open windows


## <a name="_synopsis"></a>Synopsis

`CleanStart`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CLEANSTART clear all variables from the base workspace and close any open windows
  CLEANSTART
  the function initializes the workspace for a new analysis by clearing all existing variables
  and closing any open windows</pre>
<!-- <div class="fragment"><pre class="comment">CLEANSTART clear all variables from the base workspace and close any open windows
  CLEANSTART
  the function initializes the workspace for a new analysis by clearing all existing variables
  and closing any open windows</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_MomCurvAnalysis" class="code" title="">S_MomCurvAnalysis</a>	script for moment-curvature analysis under constant axial force</li><li><a href="../../../Solution_Library/Scripts/S_NMAnalysis" class="code" title="">S_NMAnalysis</a>	script for incremental application of N-M pair on section</li><li><a href="../../../Solution_Library/Scripts/S_NMAnalysiswSepLoadHist" class="code" title="">S_NMAnalysiswSepLoadHist</a>	script for application N and M with separate load histories</li><li><a href="../S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../S_Process_EQRecordO" class="code" title="">S_Process_EQRecordO</a>	% script for processing ground motion records in PEER database format</li><li><a href="../../../Utilities/Plotting/Plot_EQRecord" class="code" title="">Plot_EQRecord</a>	% script for processing ground motion records</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->