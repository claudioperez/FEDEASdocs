
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Create_LoadHistory</div>

--------------------------

# `Create_LoadHistory`


## <a name="_name"></a>Purpose

generate time and value pairs of a displacement cycle with normal force


## <a name="_synopsis"></a>Synopsis

`LoadHist = Create_LoadHistory (RevVal,LHCase,T_Rev)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_LOADHIST generate time and value pairs of a displacement cycle with normal force    
  LOADHIST = CREATE_LOADHIST (REVVAL,LHCASE,T_REV)
  the function creates load history time and value pairs in fields Time and Value of the
  structure LOADHIST, respectively; the row vector REVVAL contains the load reversal values
  and the variable T_REV the period of reversals;
  the character variable LHCASE supports two cases:
  'A' stands for the case that the Nth reversal occurs at N*T_REV,
  'B' stands for the case that the reversal times are adjusted so that the rate of change
  for the load value is constant between reversals</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_LOADHIST generate time and value pairs of a displacement cycle with normal force    
  LOADHIST = CREATE_LOADHIST (REVVAL,LHCASE,T_REV)
  the function creates load history time and value pairs in fields Time and Value of the
  structure LOADHIST, respectively; the row vector REVVAL contains the load reversal values
  and the variable T_REV the period of reversals;
  the character variable LHCASE supports two cases:
  'A' stands for the case that the Nth reversal occurs at N*T_REV,
  'B' stands for the case that the reversal times are adjusted so that the rate of change
  for the load value is constant between reversals</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->