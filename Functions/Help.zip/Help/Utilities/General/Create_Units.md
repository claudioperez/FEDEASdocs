
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Create_Units</div>

--------------------------

# `Create_Units`


## <a name="_name"></a>Purpose

create time, length, mass and force units


## <a name="_synopsis"></a>Synopsis

`Units = Create_Units (UnOption)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_UNITS create time, length, mass and force units
  UNITS = CREATE_UNITS (UNOPTION)
  the function creates the data structure UNITS with time, length, mass and force units
  including the value of the acceleration of gravity g for both the SI and the U.S. system;
  the optional input argument UNOPTION specifies the unit system to select for unit values:
  UNOPTION = 'US' means that sec, in and kip have unit value for deriving the remaining units
  UNOPTION = 'SI' means that sec, m and kg   have unit value for deriving the remaining units</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_UNITS create time, length, mass and force units
  UNITS = CREATE_UNITS (UNOPTION)
  the function creates the data structure UNITS with time, length, mass and force units
  including the value of the acceleration of gravity g for both the SI and the U.S. system;
  the optional input argument UNOPTION specifies the unit system to select for unit values:
  UNOPTION = 'US' means that sec, in and kip have unit value for deriving the remaining units
  UNOPTION = 'SI' means that sec, m and kg   have unit value for deriving the remaining units</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../ElasticSpectra4EQRecord" class="code" title="Fig = ElasticSpectra4EQRecord(AccHst,Options)">ElasticSpectra4EQRecord</a>	generates elastic response spectra for earthquake record</li><li><a href="../S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../../../Utilities/Plotting/Plot_EQRecord" class="code" title="">Plot_EQRecord</a>	% script for processing ground motion records</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->