
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; ElasticSpectra4EQRecord</div>

--------------------------

# `ElasticSpectra4EQRecord`


## <a name="_name"></a>Purpose

generates elastic response spectra for earthquake record


## <a name="_synopsis"></a>Synopsis

`Fig = ElasticSpectra4EQRecord(AccHst,Options)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ELASTICSPECTRA4EQRECORD generates elastic response spectra for earthquake record
  FIG = ELASTICSPECTRA4EQRECORD (RECNAME,OPTIONS)
  the function generates and displays in a window the elastic response spectra
  for the accerelation record in the data structure ACCHST;
  the optional data structure OPTIONS carries parameters for spectra generation and some plot attributes;
  the function returns the figure handle FIG for further customization of the plot appearance;
  the data structure ACCHST has the following fields
     Time:   vector of time steps of acceleration history
     Value:  vector of corresponding acceleration values in g
     Deltat: time increment of recorded motion
     Title : information about the acceleration history with the following subfields (these
             are available for records in the PEER ground motion database)
        .Event     : event of earthquake record 
        .Date      : date  of earthquake record
        .Station   : recording station
        .Direction : direction of ground acceleration
  the optional data structure OPTIONS has the following fields
     T    : SDOF period range for spectra generation (default = 0:0.01:5)
     zeta : damping values for spectra generalation  (default = [ 0 0.02 0.05 0.10 ] )
     LUnit: unit system for length (options = 'SI' (cm) or 'US' (in), default = 'SI')
     FntSz: font size for axes and labels (default = 18)
     LnWth: line width                    (default = 1.5)
     LgFSz: font size for legends         (default = 18)
     TlFSz: font size for plot title      (default = 20)
     LnClr: specify the line colors for the plots as cell array, e.g. {'k';'b';'r';'m'}
            default color order uses the built-in function 'colororder' in Matlab 2019b or later</pre>
<!-- <div class="fragment"><pre class="comment">ELASTICSPECTRA4EQRECORD generates elastic response spectra for earthquake record
  FIG = ELASTICSPECTRA4EQRECORD (RECNAME,OPTIONS)
  the function generates and displays in a window the elastic response spectra
  for the accerelation record in the data structure ACCHST;
  the optional data structure OPTIONS carries parameters for spectra generation and some plot attributes;
  the function returns the figure handle FIG for further customization of the plot appearance;
  the data structure ACCHST has the following fields
     Time:   vector of time steps of acceleration history
     Value:  vector of corresponding acceleration values in g
     Deltat: time increment of recorded motion
     Title : information about the acceleration history with the following subfields (these
             are available for records in the PEER ground motion database)
        .Event     : event of earthquake record 
        .Date      : date  of earthquake record
        .Station   : recording station
        .Direction : direction of ground acceleration
  the optional data structure OPTIONS has the following fields
     T    : SDOF period range for spectra generation (default = 0:0.01:5)
     zeta : damping values for spectra generalation  (default = [ 0 0.02 0.05 0.10 ] )
     LUnit: unit system for length (options = 'SI' (cm) or 'US' (in), default = 'SI')
     FntSz: font size for axes and labels (default = 18)
     LnWth: line width                    (default = 1.5)
     LgFSz: font size for legends         (default = 18)
     TlFSz: font size for plot title      (default = 20)
     LnClr: specify the line colors for the plots as cell array, e.g. {'k';'b';'r';'m'}
            default color order uses the built-in function 'colororder' in Matlab 2019b or later</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Transient_Analysis/ElasticResponseSpectrum" class="code" title="[D,Psv,Psa] = ElasticResponseSpectrum (Acceleration,T,zeta)">ElasticResponseSpectrum</a>	determines the elastic response spectrum for given acceleration history</li><li><a href="../Create_Units" class="code" title="Units = Create_Units (UnOption)">Create_Units</a>	create time, length, mass and force units</li><li><a href="../../../Utilities/Plotting/Create_Window" class="code" title="FigH = Create_Window (dx,dy)">Create_Window</a>	creates new window with given dimensions</li><li><a href="../../../Utilities/Plotting/Plot_XYData" class="code" title="AxHndl = Plot_XYData (Xp,Yp,PlotOpt,AxHndl)">Plot_XYData</a>	plots one or more pairs of X and Y array columns</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->