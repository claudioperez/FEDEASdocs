
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Export_Figs2File</div>

--------------------------

# `Export_Figs2File`


## <a name="_name"></a>Purpose

prints some or all open figures to file


## <a name="_synopsis"></a>Synopsis

`Export_Figs2File (Figure,FigName,FigOpt,PrOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PRINT_FIGS2FILE prints some or all open figures to file 
  PRINT_FIGS2FILE(FIGURE,FNAME,FIGOPT,PROPT)
  the function prints some or all figures with handles FIGURE to files with the name
  FNAME and suffix Fn with n as the numeric identifier;
  if FNAME is missing, it is replaced by 'PFile';
  the optional arguments FIGOPT and PROPT are data structures
  with the following fields for controlling the display and the output:
  FIGOPT.Pos   : position of figure(s) relative to display (1x4 numeric array)
                 ( default = [ 0.10 0.10 0.88 0.88 ] )
        .Ornt  : figure orientation ('landscape' or 'portrait'; default='landscape')
   PROPT.Format: file format      (default=-dpdf for PDF file)
        .Reso  : print resolution (default=-r600 for PDF file)
        .Render: plot renderer    (default=-painters)
   Example: Print_Fig2File(Fig([1 4]),'Response') prints the first and the fourth figure
            with handles in data structure Fig to the PDF files ResponseF1 and ResponseF2</pre>
<!-- <div class="fragment"><pre class="comment">PRINT_FIGS2FILE prints some or all open figures to file 
  PRINT_FIGS2FILE(FIGURE,FNAME,FIGOPT,PROPT)
  the function prints some or all figures with handles FIGURE to files with the name
  FNAME and suffix Fn with n as the numeric identifier;
  if FNAME is missing, it is replaced by 'PFile';
  the optional arguments FIGOPT and PROPT are data structures
  with the following fields for controlling the display and the output:
  FIGOPT.Pos   : position of figure(s) relative to display (1x4 numeric array)
                 ( default = [ 0.10 0.10 0.88 0.88 ] )
        .Ornt  : figure orientation ('landscape' or 'portrait'; default='landscape')
   PROPT.Format: file format      (default=-dpdf for PDF file)
        .Reso  : print resolution (default=-r600 for PDF file)
        .Render: plot renderer    (default=-painters)
   Example: Print_Fig2File(Fig([1 4]),'Response') prints the first and the fourth figure
            with handles in data structure Fig to the PDF files ResponseF1 and ResponseF2</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->