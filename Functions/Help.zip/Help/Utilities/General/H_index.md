
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; H_index</div>

--------------------------

# `H_index`


## <a name="_name"></a>Purpose

cell array of indices into structure arrays for continuous element deformations


## <a name="_synopsis"></a>Synopsis

`iced = H_index (Model,ElemData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">H_INDEX cell array of indices into structure arrays for continuous element deformations
  ICED = H_INDEX (MODEL,ELEMDATA)
  the function sets up the cell array ICED of indices for continuous element deformations
  based on release information for elements of the structural model in data structure MODEL;
  the location of element releases is specified in field RELEASE of cell array ELEMDATA
  ELEMDATA{2}.RELEASE = [0;1;0] :   a flexural release is present at end i of element 2
  ELEMDATA{3}.RELEASE = [1;0;1] : an axial and a flexural release at end j of element 3
  the function supports only truss and 2d frame elements at present</pre>
<!-- <div class="fragment"><pre class="comment">H_INDEX cell array of indices into structure arrays for continuous element deformations
  ICED = H_INDEX (MODEL,ELEMDATA)
  the function sets up the cell array ICED of indices for continuous element deformations
  based on release information for elements of the structural model in data structure MODEL;
  the location of element releases is specified in field RELEASE of cell array ELEMDATA
  ELEMDATA{2}.RELEASE = [0;1;0] :   a flexural release is present at end i of element 2
  ELEMDATA{3}.RELEASE = [1;0;1] : an axial and a flexural release at end j of element 3
  the function supports only truss and 2d frame elements at present</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../General/Bbar_matrix" class="code" title="[Bbar,Bvbar,ind_x] = Bbar_matrix (Model,ElemData)">Bbar_matrix</a>	function for determining force influence matrices of structural model</li><li><a href="../../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li><li><a href="../../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../../Solution_Library/Scripts/S_GeneralForceMethod" class="code" title="">S_GeneralForceMethod</a>	script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf</li><li><a href="../../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li><li><a href="../../../Utilities/PostProcessing/Complete_QV" class="code" title="[Q,Ve] = Complete_QV (Model,ElemData,Qin)">Complete_QV</a>	complete basic force QIN and element deformation vector VE with values at releases</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->