
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; ImplicitData3</div>

--------------------------

# `ImplicitData3`


## <a name="_name"></a>Purpose

% 3D Implicit Plot Data Generator


## <a name="_synopsis"></a>Synopsis

`[x,y,z] = ImplicitData3(fun, Lims, MeshDensity)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">% 3D Implicit Plot Data Generator
  [x,y,z] = ImplicitData3(Function, Lims MeshDensity)
  This funciton works around the lack of support for exporting discrete
  data from a 3D implicit surface plot. This is accomplished by changing
  the problem into a series of 2D implicit problems, which do support
  exporting data.

  Inputs: 
   Function    -- The same 3D function handle that you would pass to the
                   implicit surface function fimplicit3. This is the 
                   function that we're getting data from
   Lims        -- An array of coordinate limits [X-,X+,Y-,Y+,Z-,Z+] or
                   [Lower Upper] for a cubic region. This is the same as 
                   the &quot;LIMS&quot; argument for fimplicit3
   MeshDensity -- The number of points evaluated along each axis. This is 
                   the same as the &quot;MeshDensity&quot; name-value parameter for 
                   fimplicit3

  Outputs:    
   x,y,z       -- Vectors of the X, Y, and Z-coordinates of points on the 
                   implicit surface 

 V1.0 (9/12/2019 Philip Bean)</pre>
<!-- <div class="fragment"><pre class="comment">% 3D Implicit Plot Data Generator
  [x,y,z] = ImplicitData3(Function, Lims MeshDensity)
  This funciton works around the lack of support for exporting discrete
  data from a 3D implicit surface plot. This is accomplished by changing
  the problem into a series of 2D implicit problems, which do support
  exporting data.

  Inputs: 
   Function    -- The same 3D function handle that you would pass to the
                   implicit surface function fimplicit3. This is the 
                   function that we're getting data from
   Lims        -- An array of coordinate limits [X-,X+,Y-,Y+,Z-,Z+] or
                   [Lower Upper] for a cubic region. This is the same as 
                   the &quot;LIMS&quot; argument for fimplicit3
   MeshDensity -- The number of points evaluated along each axis. This is 
                   the same as the &quot;MeshDensity&quot; name-value parameter for 
                   fimplicit3

  Outputs:    
   x,y,z       -- Vectors of the X, Y, and Z-coordinates of points on the 
                   implicit surface 

 V1.0 (9/12/2019 Philip Bean)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->