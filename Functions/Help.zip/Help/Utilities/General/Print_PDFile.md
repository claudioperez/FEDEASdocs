
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Print_PDFile</div>

--------------------------

# `Print_PDFile`


## <a name="_name"></a>Purpose

sends the current figure to file


## <a name="_synopsis"></a>Synopsis

`Print_PDFile (FName,FigOpt,PrOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PRINT_PDFILE sends the current figure to file 
  PRINT_PDFILE(FNAME,FIGOPT,PROPT)
  the function generates the FNAME.EXT file from the current figure; if FNAME is missing,
  it is replaced by 'PFile'; the optional arguments FIGOPT and PROPT are data structures
  with the following fields for controlling the display and the output:
  FIGOPT.Pos   : position of figure relative to display (1x4 numeric array)
                 ( default = [ 0.10 0.10 0.88 0.88 ] )
        .Ornt  : figure orientation ('landscape' or 'portrait'; default='landscape')
   PROPT.Format: file format      (default=-dpdf for PDF file)
        .Reso  : print resolution (default=-r600 for PDF file)
        .Render: plot renderer    (default=-painters)</pre>
<!-- <div class="fragment"><pre class="comment">PRINT_PDFILE sends the current figure to file 
  PRINT_PDFILE(FNAME,FIGOPT,PROPT)
  the function generates the FNAME.EXT file from the current figure; if FNAME is missing,
  it is replaced by 'PFile'; the optional arguments FIGOPT and PROPT are data structures
  with the following fields for controlling the display and the output:
  FIGOPT.Pos   : position of figure relative to display (1x4 numeric array)
                 ( default = [ 0.10 0.10 0.88 0.88 ] )
        .Ornt  : figure orientation ('landscape' or 'portrait'; default='landscape')
   PROPT.Format: file format      (default=-dpdf for PDF file)
        .Reso  : print resolution (default=-r600 for PDF file)
        .Render: plot renderer    (default=-painters)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->