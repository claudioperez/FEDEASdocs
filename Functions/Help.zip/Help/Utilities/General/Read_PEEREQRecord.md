
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Read_PEEREQRecord</div>

--------------------------

# `Read_PEEREQRecord`


## <a name="_name"></a>Purpose

reads ground motions in the format of the PEER database


## <a name="_synopsis"></a>Synopsis

`AccHst = Read_PEEREQRecord (RecName)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">READ_PEEREQRECORD reads ground motions in the format of the PEER database
  ACCHST = READ_PEEREQRECORD (RECNAME)
  the function reads ground acceleration records in the format of the PEER
  database found in http://ngawest2.berkeley.edu/;
  if the name of the record is NOT specified in the character variable RECNAME,
  the function prompts for the directory with interactive selection of the record;
  if the RECNAME does not have an extension, the function adds the extension AT2;
  the function generates the data structure ACCHST with the following fields
     Title:  general information about the record with subfields
             Event:      earthquake name
             Date:       date
             Station:    recording station
             Direction:  from record header
             PGA:        peak ground acceleration in g
             AriasInt:   Arias intensity in m/s
             Duration:   significant duration (5-95% of AI)
             OutputUnit: acceleration in g
             FileName:   filename of record
     Value:  vector of acceleration values in g
     Time:   vector of time steps
     Deltat: time increment of recorded motion</pre>
<!-- <div class="fragment"><pre class="comment">READ_PEEREQRECORD reads ground motions in the format of the PEER database
  ACCHST = READ_PEEREQRECORD (RECNAME)
  the function reads ground acceleration records in the format of the PEER
  database found in http://ngawest2.berkeley.edu/;
  if the name of the record is NOT specified in the character variable RECNAME,
  the function prompts for the directory with interactive selection of the record;
  if the RECNAME does not have an extension, the function adds the extension AT2;
  the function generates the data structure ACCHST with the following fields
     Title:  general information about the record with subfields
             Event:      earthquake name
             Date:       date
             Station:    recording station
             Direction:  from record header
             PGA:        peak ground acceleration in g
             AriasInt:   Arias intensity in m/s
             Duration:   significant duration (5-95% of AI)
             OutputUnit: acceleration in g
             FileName:   filename of record
     Value:  vector of acceleration values in g
     Time:   vector of time steps
     Deltat: time increment of recorded motion</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../S_Process_EQRecordO" class="code" title="">S_Process_EQRecordO</a>	% script for processing ground motion records in PEER database format</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->