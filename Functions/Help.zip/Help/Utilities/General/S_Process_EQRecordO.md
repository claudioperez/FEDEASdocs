
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; S_Process_EQRecordO</div>

--------------------------

# `S_Process_EQRecordO`


## <a name="_name"></a>Purpose

% script for processing ground motion records in PEER database format


## <a name="_synopsis"></a>Synopsis

`This is a script file.`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">% script for processing ground motion records in PEER database format
  the script generates elastic, inelastic and ductility response spectra</pre>
<!-- <div class="fragment"><pre class="comment">% script for processing ground motion records in PEER database format
  the script generates elastic, inelastic and ductility response spectra</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Transient_Analysis/ElasticResponseSpectrum" class="code" title="[D,Psv,Psa] = ElasticResponseSpectrum (Acceleration,T,zeta)">ElasticResponseSpectrum</a>	determines the elastic response spectrum for given acceleration history</li><li><a href="../CleanStart" class="code" title="CleanStart">CleanStart</a>	clear all variables from the base workspace and close any open windows</li><li><a href="../Read_PEEREQRecord" class="code" title="AccHst = Read_PEEREQRecord (RecName)">Read_PEEREQRecord</a>	reads ground motions in the format of the PEER database</li><li><a href="../../../Utilities/Plotting/Create_Window" class="code" title="FigH = Create_Window (dx,dy)">Create_Window</a>	creates new window with given dimensions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->