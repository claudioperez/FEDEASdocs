
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">General</a> &gt; Select_M2PFileConversion</div>

--------------------------

# `Select_M2PFileConversion`


## <a name="_name"></a>Purpose

converts Matlab files in DIRECTORY not in MFILELIST to p-format


## <a name="_synopsis"></a>Synopsis

`Select_M2PFileConversion (Directory,MFileList)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SELECT_M2PFILECONVERSION converts Matlab files in DIRECTORY not in MFILELIST to p-format
  the function converts any Matlab files in DIRECTORY that are not included in MFILELIST
  to encoded p-format and deletes the original files;
  DIRECTORY is a character variable with the full directory path and MFILELIST is a cellarray
  with the list of Matlab file names in rows, e.g. MFILELIST = {'FileA.m' ; 'FileB.m' }</pre>
<!-- <div class="fragment"><pre class="comment">SELECT_M2PFILECONVERSION converts Matlab files in DIRECTORY not in MFILELIST to p-format
  the function converts any Matlab files in DIRECTORY that are not included in MFILELIST
  to encoded p-format and deletes the original files;
  DIRECTORY is a character variable with the full directory path and MFILELIST is a cellarray
  with the list of Matlab file names in rows, e.g. MFILELIST = {'FileA.m' ; 'FileB.m' }</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->