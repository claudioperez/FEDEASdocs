---
title: General
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `General`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# General

<table>
<tr><td><a href="Append_Fields">Append_Fields</a></td><td>append the fields of structure A to structure B </td></tr><tr><td><a href="CleanStart">CleanStart</a></td><td>clear all variables from the base workspace and close any open windows </td></tr><tr><td><a href="Create_DispCyclewN">Create_DispCyclewN</a></td><td>generate time and value pairs for a single displacement cycle with normal force </td></tr><tr><td><a href="Create_LoadHistory">Create_LoadHistory</a></td><td>generate time and value pairs of a displacement cycle with normal force </td></tr><tr><td><a href="Create_MultDispCycleswN">Create_MultDispCycleswN</a></td><td>sequence of full, half or quarter displacement cycles with axial force </td></tr><tr><td><a href="Create_Units">Create_Units</a></td><td>create time, length, mass and force units </td></tr><tr><td><a href="D_index">D_index</a></td><td>cell array of indices into structure arrays for non-zero element deformations </td></tr><tr><td><a href="ElasticSpectra4EQRecord">ElasticSpectra4EQRecord</a></td><td>generates elastic response spectra for earthquake record </td></tr><tr><td><a href="Export_Figs2File">Export_Figs2File</a></td><td>prints some or all open figures to file </td></tr><tr><td><a href="Extract_Fields">Extract_Fields</a></td><td>Summary of this function goes here </td></tr><tr><td><a href="H_index">H_index</a></td><td>cell array of indices into structure arrays for continuous element deformations </td></tr><tr><td><a href="ImplicitData3">ImplicitData3</a></td><td>% 3D Implicit Plot Data Generator </td></tr><tr><td><a href="Print_Figs2File">Print_Figs2File</a></td><td>prints some or all open figures to file </td></tr><tr><td><a href="Print_PDFile">Print_PDFile</a></td><td>sends the current figure to file </td></tr><tr><td><a href="Read_PEEREQRecord">Read_PEEREQRecord</a></td><td>reads ground motions in the format of the PEER database </td></tr><tr><td><a href="SIUnits_Old">SIUnits_Old</a></td><td>% Script file for common unit definition with SI units as default </td></tr><tr><td><a href="S_Process_EQRecord">S_Process_EQRecord</a></td><td>% script for processing ground motion records in PEER database format </td></tr><tr><td><a href="S_Process_EQRecordO">S_Process_EQRecordO</a></td><td>% script for processing ground motion records in PEER database format </td></tr><tr><td><a href="Select_M2PFileConversion">Select_M2PFileConversion</a></td><td>converts Matlab files in DIRECTORY not in MFILELIST to p-format </td></tr><tr><td><a href="Units_Old">Units_Old</a></td><td>% Script file for common unit definition with Imperial units as default </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->