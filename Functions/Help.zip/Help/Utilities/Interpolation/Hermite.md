
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; Hermite</div>

--------------------------

# `Hermite`


## <a name="_name"></a>Purpose

Hermite interpolation polynomials in interval -1&lt;xi&lt;1


## <a name="_synopsis"></a>Synopsis

`hp = Hermite (degree,deriv,xi)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">HERMITE Hermite interpolation polynomials in interval -1&lt;xi&lt;1
  HP = HERMITE (DEGREE,DERIV,XI)
  the function determines the values of Hermite interpolation polynomials of degree DEGREE
  and derivative order DERIV at integration points in vector XI;
  the values are returned in array HP with rows representing the different Hermite
  polynomials of degree DEGREE and columns representing the values at points XI
  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: Hermite(3,2,xi) returns the second derivative of cubic Hermite polynomials at xi

  If degree is even, one node of the equispaced grid used to evaluate the
  polynomials considers only the value of ordinate, without the
  derivative. This node is always the last node of the grid, considering
  that the end nodes are located in the first two positions.

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     hp(1:2:size(hp,1),:) = hp(1:2:size(hp,1),:)./(Jac^deriv);
     hp(2:2:size(hp,1),:) = hp(2:2:size(hp,1),:)./(Jac^(deriv-1));</pre>
<!-- <div class="fragment"><pre class="comment">HERMITE Hermite interpolation polynomials in interval -1&lt;xi&lt;1
  HP = HERMITE (DEGREE,DERIV,XI)
  the function determines the values of Hermite interpolation polynomials of degree DEGREE
  and derivative order DERIV at integration points in vector XI;
  the values are returned in array HP with rows representing the different Hermite
  polynomials of degree DEGREE and columns representing the values at points XI
  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: Hermite(3,2,xi) returns the second derivative of cubic Hermite polynomials at xi

  If degree is even, one node of the equispaced grid used to evaluate the
  polynomials considers only the value of ordinate, without the
  derivative. This node is always the last node of the grid, considering
  that the end nodes are located in the first two positions.

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     hp(1:2:size(hp,1),:) = hp(1:2:size(hp,1),:)./(Jac^deriv);
     hp(2:2:size(hp,1),:) = hp(2:2:size(hp,1),:)./(Jac^(deriv-1));</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Mass4Taper2dFrm_wDF" class="code" title="ElemMass = Mass4Taper2dFrm_wDF (xyz,ElemData)">Mass4Taper2dFrm_wDF</a>	consistent mass matrix for tapered 2d frame element with displ interpolation</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_w2ndOrdDF" class="code" title="ElemResp = LE2dFrm_w2ndOrdDF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_w2ndOrdDF</a>	2d LE frame element with moderate deformations under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wVarIDF" class="code" title="ElemResp = LE2dFrm_wVarIDF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wVarIDF</a>	2d LE frame element with variable cross section under linear or NL geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->