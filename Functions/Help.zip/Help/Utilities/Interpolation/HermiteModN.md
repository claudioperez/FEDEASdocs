
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; HermiteModN</div>

--------------------------

# `HermiteModN`


## <a name="_name"></a>Purpose

Hermite interpolation polynomials in interval -1&lt;xi&lt;1


## <a name="_synopsis"></a>Synopsis

`hp = HermiteModN(nn,deriv,xi)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">HERMITEMODN Hermite interpolation polynomials in interval -1&lt;xi&lt;1
  HP = HERMITEMODN (NN,DERIV,XI)
  the function determines the values of Hermite interpolation polynomials of degree
  DEGREE = 2*NN - 1 - NI, where NN is number of equally spaced nodes used to
  compute the polynomilas and NI = NN - 2 &gt; 0 is the number of internal
  node considered.
  At the end nodes, both the value of the required polynomial and its derivative
  are considered for its evaluation. Whereas, at the internal nodes, only
  the value of the required polynomial is considered.
  The functions provides the derivative of order DERIV at integration points in the vector XI;
  The values are returned in array LP with 2*NN - NI rows representing the
  different Hermite polynomials (2 per each end node and 1 per each internal one)
  and columns representing the values at points XI;
  The polynomial associated to the end nodes of the interval are located in
  the first 4 rows of lp and the other locations are reserved for the polynomial
  associated to internal nodes;

  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: HermiteN(3,2,xi) returns the second derivative of quartic Hermite polynomials at xi

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     hp(1:2:min(4,size(hp,1)),:) = hp(1:2:min(4,size(hp,1)),:)./(Jac^deriv);
     hp(2:2:min(4,size(hp,1)),:) = hp(2:2:min(4,size(hp,1)),:)./(Jac^(deriv-1));
     if size(hp,1) &gt; 4,
         hp(5:size(hp,1),:) = hp(5:size(hp,1),:)./(Jac^deriv);
     end</pre>
<!-- <div class="fragment"><pre class="comment">HERMITEMODN Hermite interpolation polynomials in interval -1&lt;xi&lt;1
  HP = HERMITEMODN (NN,DERIV,XI)
  the function determines the values of Hermite interpolation polynomials of degree
  DEGREE = 2*NN - 1 - NI, where NN is number of equally spaced nodes used to
  compute the polynomilas and NI = NN - 2 &gt; 0 is the number of internal
  node considered.
  At the end nodes, both the value of the required polynomial and its derivative
  are considered for its evaluation. Whereas, at the internal nodes, only
  the value of the required polynomial is considered.
  The functions provides the derivative of order DERIV at integration points in the vector XI;
  The values are returned in array LP with 2*NN - NI rows representing the
  different Hermite polynomials (2 per each end node and 1 per each internal one)
  and columns representing the values at points XI;
  The polynomial associated to the end nodes of the interval are located in
  the first 4 rows of lp and the other locations are reserved for the polynomial
  associated to internal nodes;

  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: HermiteN(3,2,xi) returns the second derivative of quartic Hermite polynomials at xi

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     hp(1:2:min(4,size(hp,1)),:) = hp(1:2:min(4,size(hp,1)),:)./(Jac^deriv);
     hp(2:2:min(4,size(hp,1)),:) = hp(2:2:min(4,size(hp,1)),:)./(Jac^(deriv-1));
     if size(hp,1) &gt; 4,
         hp(5:size(hp,1),:) = hp(5:size(hp,1),:)./(Jac^deriv);
     end</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->