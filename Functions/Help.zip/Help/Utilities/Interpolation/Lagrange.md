
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; Lagrange</div>

--------------------------

# `Lagrange`


## <a name="_name"></a>Purpose

Lagrange interpolation polynomials in interval -1&lt;xi&lt;1


## <a name="_synopsis"></a>Synopsis

`lp = Lagrange (degree,deriv,xi)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LAGRANGE Lagrange interpolation polynomials in interval -1&lt;xi&lt;1
  LP = LAGRANGE(DEGREE,DERIV,XI)
  the function determines the values of Lagrange interpolation polynomials of degree DEGREE
  and derivative order DERIV at integration points in vector XI;
  the values are returned in array LP with rows representing the different Lagrange
  polynomials of degree DEGREE and columns representing the values at points XI
  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: Lagrange(2,1,xi) returns the first derivative of quadratic Lagrange polynomials at xi

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     lp  = lp./(Jac^deriv);</pre>
<!-- <div class="fragment"><pre class="comment">LAGRANGE Lagrange interpolation polynomials in interval -1&lt;xi&lt;1
  LP = LAGRANGE(DEGREE,DERIV,XI)
  the function determines the values of Lagrange interpolation polynomials of degree DEGREE
  and derivative order DERIV at integration points in vector XI;
  the values are returned in array LP with rows representing the different Lagrange
  polynomials of degree DEGREE and columns representing the values at points XI
  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: Lagrange(2,1,xi) returns the first derivative of quadratic Lagrange polynomials at xi

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     lp  = lp./(Jac^deriv);</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../LagrangeN" class="code" title="lp = LagrangeN (nn,deriv,xi)">LagrangeN</a>	Lagrange interpolation polynomials in interval -1<xi<1</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_EB2ndOrdwdirFF" class="code" title="ElemResp = Dinel2dFrm_EB2ndOrdwdirFF (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_EB2ndOrdwdirFF</a>	2d nonlinear frame element with moderate deformations under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_EB2ndOrdwiterFF" class="code" title="ElemResp = Dinel2dFrm_EB2ndOrdwiterFF (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_EB2ndOrdwiterFF</a>	2d nonlinear frame element with moderate deformations under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel2dFrm_wMFwSecInv" class="code" title="ElemResp = Dinel2dFrm_wMFwSecInv (action,el_no,xyz,ElemData,ElemState)">Dinel2dFrm_wMFwSecInv</a>	DINEL2dFRM_wMFWSECINV</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Dinel3dFrm_EBwiterMFCL" class="code" title="ElemResp = Dinel3dFrm_EBwiterMFCL (action,el_no,xyz,ElemData,ElemState)">Dinel3dFrm_EBwiterMFCL</a>	3d-frame element with distributed inelasticity (direct force formulation)</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Mass4Taper2dFrm_wDF" class="code" title="ElemMass = Mass4Taper2dFrm_wDF (xyz,ElemData)">Mass4Taper2dFrm_wDF</a>	consistent mass matrix for tapered 2d frame element with displ interpolation</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_w2ndOrdDF" class="code" title="ElemResp = LE2dFrm_w2ndOrdDF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_w2ndOrdDF</a>	2d LE frame element with moderate deformations under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_w2ndOrdFF" class="code" title="ElemResp = LE2dFrm_w2ndOrdFF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_w2ndOrdFF</a>	2d LE frame element with moderate deformations under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wVarIDF" class="code" title="ElemResp = LE2dFrm_wVarIDF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wVarIDF</a>	2d LE frame element with variable cross section under linear or NL geometry</li><li><a href="../../../Element_Library/Frame_Elements/Linear/LE2dFrm_wVarIFF" class="code" title="ElemResp = LE2dFrm_wVarIFF (action,el_no,xyz,ElemData,ElemState)">LE2dFrm_wVarIFF</a>	2d LE frame element with variable cross section under linear or NL geometry</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->