
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; PolyIntLib</div>

--------------------------

# `PolyIntLib`


## <a name="_name"></a>Purpose

=========================================================================================


## <a name="_synopsis"></a>Synopsis

`y = PolyIntLib (Fname)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">  =========================================================================================
  FEDEASLab - Release 5.2, July 2021
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2021. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  function by Paolo Di Re                                                           09-2015
  -----------------------------------------------------------------------------------------</pre>
<!-- <div class="fragment"><pre class="comment">  =========================================================================================
  FEDEASLab - Release 5.2, July 2021
  Matlab Finite Elements for Design, Evaluation and Analysis of Structures
  Professor Filip C. Filippou (filippou@berkeley.edu)
  Department of Civil and Environmental Engineering, UC Berkeley
  Copyright(c) 1998-2021. The Regents of the University of California. All Rights Reserved.
  =========================================================================================
  function by Paolo Di Re                                                           09-2015
  -----------------------------------------------------------------------------------------</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../LagrangeN" class="code" title="lp = LagrangeN (nn,deriv,xi)">LagrangeN</a>	Lagrange interpolation polynomials in interval -1<xi<1</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->