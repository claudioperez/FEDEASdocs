
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; SplineN</div>

--------------------------

# `SplineN`


## <a name="_name"></a>Purpose

Spline interpolation polynomials in interval -1&lt;xi&lt;1


## <a name="_synopsis"></a>Synopsis

`sp = SplineN (nn,deriv,xi,degree)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SPLINEN Spline interpolation polynomials in interval -1&lt;xi&lt;1
  SP = SPLINEN(NN,DERIV,XI)
  the function determines the values of the Spline interpolation polynomials of degree
  DEGREE.
  NN is the number of equally spaced nodes used to compute the polynomilas.
  DEGREE is an optional parameter, set by default as 3 (cubic spline)
  The breaks considered for the spline polynomial coincide with the NN nodes.
  The functions provides the derivative of order DERIV at integration points in the vector XI;
  the values are returned in array SP with NN rows representing the
  different Spline polynomials and columns representing the values at points XI;
  The polynomial associated to the end nodes of the interval are located in
  the first 2 rows of sp and the other locations are reserved for the polynomial
  associated to internal nodes;

  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: SplineN(6,1,xi,4) returns the first derivative of quartic
  Spline polynomials at xi, evaluated on the 6 equally spaced nodes

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     sp  = sp./(Jac^deriv);</pre>
<!-- <div class="fragment"><pre class="comment">SPLINEN Spline interpolation polynomials in interval -1&lt;xi&lt;1
  SP = SPLINEN(NN,DERIV,XI)
  the function determines the values of the Spline interpolation polynomials of degree
  DEGREE.
  NN is the number of equally spaced nodes used to compute the polynomilas.
  DEGREE is an optional parameter, set by default as 3 (cubic spline)
  The breaks considered for the spline polynomial coincide with the NN nodes.
  The functions provides the derivative of order DERIV at integration points in the vector XI;
  the values are returned in array SP with NN rows representing the
  different Spline polynomials and columns representing the values at points XI;
  The polynomial associated to the end nodes of the interval are located in
  the first 2 rows of sp and the other locations are reserved for the polynomial
  associated to internal nodes;

  NOTE: XI need to be supplied in the interval -1&lt;xi&lt;1
  EXAMPLE: SplineN(6,1,xi,4) returns the first derivative of quartic
  Spline polynomials at xi, evaluated on the 6 equally spaced nodes

  To go from the interval [-1;+1] to the interval [0;L]:
     Jac = 0.5*L;    xP = Jac.*(1.+xi);
     sp  = sp./(Jac^deriv);</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../splinefit" class="code" title="pp = splinefit(varargin)">splinefit</a>	Fit a spline to noisy data.</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->