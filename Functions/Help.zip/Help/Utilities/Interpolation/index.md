---
title: Interpolation
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Interpolation`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Interpolation

<table>
<tr><td><a href="Hermite">Hermite</a></td><td>Hermite interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="HermiteModN">HermiteModN</a></td><td>Hermite interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="HermiteN">HermiteN</a></td><td>Hermite interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="Lagrange">Lagrange</a></td><td>Lagrange interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="LagrangeN">LagrangeN</a></td><td>Lagrange interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="PolyIntLib">PolyIntLib</a></td><td>========================================================================================= </td></tr><tr><td><a href="SplineN">SplineN</a></td><td>Spline interpolation polynomials in interval -1<xi<1 </td></tr><tr><td><a href="hermitepoly">hermitepoly</a></td><td> Hermite interpolation polynomial fitting a set of points </td></tr><tr><td><a href="lagrangepoly">lagrangepoly</a></td><td> Lagrange interpolation polynomial fitting a set of points </td></tr><tr><td><a href="splinefit">splinefit</a></td><td>Fit a spline to noisy data. </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->