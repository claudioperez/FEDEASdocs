
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; lagrangepoly</div>

--------------------------

# `lagrangepoly`


## <a name="_name"></a>Purpose

 Lagrange interpolation polynomial fitting a set of points


## <a name="_synopsis"></a>Synopsis

`[P,R,S] = lagrangepoly(X,Y,XX)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LAGRANGEPOLY  Lagrange interpolation polynomial fitting a set of points
   [P,R,S] = LAGRANGEPOLY(X,Y)  where X and Y are row vectors
   defining a set of N points uses Lagrange's method to find 
   the N-1th order polynomial in X that passes through these 
   points.  P returns the N coefficients defining the polynomial, 
   in the same order as used by POLY and POLYVAL (highest order first).
   Then, polyval(P,X) = Y.  R returns the x-coordinates of the N-1
   extrema of the resulting polynomial (roots of its derivative),
   and S returns the y-values  at those extrema.

   YY = LAGRANGEPOLY(X,Y,XX) returns the values of the polynomial
   sampled at the points specified in XX -- the same as
   YY = POLYVAL(LAGRANGEPOLY(X,Y)). 

   Example:
   To find the 4th-degree polynomial that oscillates between 
   1 and 0 across 5 points around zero, then plot the interpolation
   on a denser grid in between:
     X = -2:2;  Y = [1 0 1 0 1];
     P = lagrangepoly(X,Y);
     xx = -2.5:.01:2.5;
     plot(xx,polyval(P,xx),X,Y,'or');
     grid;
   Or simply:
     plot(xx,lagrangepoly(X,Y,xx));

   Note: if you are just looking for a smooth curve passing through 
   a set of points, you can get a better fit with SPLINE, which 
   fits piecewise polynomials rather than a single polynomial.

   See also: POLY, POLYVAL, SPLINE</pre>
<!-- <div class="fragment"><pre class="comment">LAGRANGEPOLY  Lagrange interpolation polynomial fitting a set of points
   [P,R,S] = LAGRANGEPOLY(X,Y)  where X and Y are row vectors
   defining a set of N points uses Lagrange's method to find 
   the N-1th order polynomial in X that passes through these 
   points.  P returns the N coefficients defining the polynomial, 
   in the same order as used by POLY and POLYVAL (highest order first).
   Then, polyval(P,X) = Y.  R returns the x-coordinates of the N-1
   extrema of the resulting polynomial (roots of its derivative),
   and S returns the y-values  at those extrema.

   YY = LAGRANGEPOLY(X,Y,XX) returns the values of the polynomial
   sampled at the points specified in XX -- the same as
   YY = POLYVAL(LAGRANGEPOLY(X,Y)). 

   Example:
   To find the 4th-degree polynomial that oscillates between 
   1 and 0 across 5 points around zero, then plot the interpolation
   on a denser grid in between:
     X = -2:2;  Y = [1 0 1 0 1];
     P = lagrangepoly(X,Y);
     xx = -2.5:.01:2.5;
     plot(xx,polyval(P,xx),X,Y,'or');
     grid;
   Or simply:
     plot(xx,lagrangepoly(X,Y,xx));

   Note: if you are just looking for a smooth curve passing through 
   a set of points, you can get a better fit with SPLINE, which 
   fits piecewise polynomials rather than a single polynomial.

   See also: POLY, POLYVAL, SPLINE</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/Extract_El2SecDispFF_T3D" class="code" title="u = Extract_El2SecDispFF_T3D(sec,L,nIP,xIP,wIP,ElemPost,ue)">Extract_El2SecDispFF_T3D</a>	extract section state from element state for Force Formulation element</li><li><a href="../../../Element_Library/Frame_Elements/DistrInelastic/WarpShpFun4Elem" class="code" title="[xWP,Nwx,DNwx] = WarpShpFun4Elem (ElemData)">WarpShpFun4Elem</a>	computes the 1d shape functions for section with warping</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->