
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Interpolation</a> &gt; splinefit</div>

--------------------------

# `splinefit`


## <a name="_name"></a>Purpose

Fit a spline to noisy data.


## <a name="_synopsis"></a>Synopsis

`pp = splinefit(varargin)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">SPLINEFIT Fit a spline to noisy data.
   PP = SPLINEFIT(X,Y,BREAKS) fits a piecewise cubic spline with breaks
   (knots) BREAKS to the noisy data (X,Y). X is a vector and Y is a vector
   or an ND array. If Y is an ND array, then X(j) and Y(:,...,:,j) are
   matched. Use PPVAL to evaluate PP.

   PP = SPLINEFIT(X,Y,P) where P is a positive integer interpolates the
   breaks linearly from the sorted locations of X. P is the number of
   spline pieces and P+1 is the number of breaks.

   OPTIONAL INPUT
   Argument places 4 to 8 are reserved for optional input.
   These optional arguments can be given in any order:

   PP = SPLINEFIT(...,'p') applies periodic boundary conditions to
   the spline. The period length is MAX(BREAKS)-MIN(BREAKS).

   PP = SPLINEFIT(...,'r') uses robust fitting to reduce the influence
   from outlying data points. Three iterations of weighted least squares
   are performed. Weights are computed from previous residuals.

   PP = SPLINEFIT(...,BETA), where 0 &lt; BETA &lt; 1, sets the robust fitting
   parameter BETA and activates robust fitting ('r' can be omitted).
   Default is BETA = 1/2. BETA close to 0 gives all data equal weighting.
   Increase BETA to reduce the influence from outlying data. BETA close
   to 1 may cause instability or rank deficiency.

   PP = SPLINEFIT(...,N) sets the spline order to N. Default is a cubic
   spline with order N = 4. A spline with P pieces has P+N-1 degrees of
   freedom. With periodic boundary conditions the degrees of freedom are
   reduced to P.

   PP = SPLINEFIT(...,CON) applies linear constraints to the spline.
   CON is a structure with fields 'xc', 'yc' and 'cc':
       'xc', x-locations (vector)
       'yc', y-values (vector or ND array)
       'cc', coefficients (matrix).

   Constraints are linear combinations of derivatives of order 0 to N-2
   according to

     cc(1,j)*y(x) + cc(2,j)*y'(x) + ... = yc(:,...,:,j),  x = xc(j).

   The maximum number of rows for 'cc' is N-1. If omitted or empty 'cc'
   defaults to a single row of ones. Default for 'yc' is a zero array.

   EXAMPLES

       % Noisy data
       x = linspace(0,2*pi,100);
       y = sin(x) + 0.1*randn(size(x));
       % Breaks
       breaks = [0:5,2*pi];

       % Fit a spline of order 5
       pp = splinefit(x,y,breaks,5);

       % Fit a spline of order 3 with periodic boundary conditions
       pp = splinefit(x,y,breaks,3,'p');

       % Constraints: y(0) = 0, y'(0) = 1 and y(3) + y&quot;(3) = 0
       xc = [0 0 3];
       yc = [0 1 0];
       cc = [1 0 1; 0 1 0; 0 0 1];
       con = struct('xc',xc,'yc',yc,'cc',cc);

       % Fit a cubic spline with 8 pieces and constraints
       pp = splinefit(x,y,8,con);

       % Fit a spline of order 6 with constraints and periodicity
       pp = splinefit(x,y,breaks,con,6,'p');

   See also SPLINE, PPVAL, PPDIFF, PPINT

 OTHER EXAMPLES
 %%% <a href="splinefit.md" class="code" title="pp = splinefit(varargin)">SPLINEFIT</a> EXAMPLES


 %% EXAMPLE 1: Breaks and pieces

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(x) + sin(2*x) + 0.2*randn(size(x));

 % Uniform breaks
 breaks = linspace(0,2*pi,41); % 41 breaks, 40 pieces
 pp1 = splinefit(x,y,breaks);

 % Breaks interpolated from data
 pp2 = splinefit(x,y,10);  % 11 breaks, 10 pieces

 % Plot
 figure(1)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2])
 axis([0,2*pi,-2.5,2.5]), grid on
 legend('data','41 breaks, 40 pieces','11 breaks, 10 pieces')
 title('EXAMPLE 1: Breaks and pieces')



 %% EXAMPLE 2: Spline orders

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(x) + sin(2*x) + 0.1*randn(size(x));

 % Splines
 pp1 = splinefit(x,y,8,1);  % Piecewise constant
 pp2 = splinefit(x,y,8,2);  % Piecewise linear
 pp3 = splinefit(x,y,8,3);  % Piecewise quadratic
 pp4 = splinefit(x,y,8,4);  % Piecewise cubic
 pp5 = splinefit(x,y,8,5);  % Etc.

 % Plot
 figure(2)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 y3 = ppval(pp3,xx);
 y4 = ppval(pp4,xx);
 y5 = ppval(pp5,xx);
 plot(x,y,'.',xx,[y1;y2;y3;y4;y5]), grid on
 legend('data','order 1','order 2','order 3','order 4','order 5')
 title('EXAMPLE 2: Spline orders')



 %% EXAMPLE 3: Periodic boundary conditions

 % Data (100 points)
 x = 2*pi*[0,rand(1,98),1];
 y = sin(x) - cos(2*x) + 0.2*randn(size(x));

 % No constraints
 pp1 = splinefit(x,y,10,5);
 % Periodic boundaries
 pp2 = splinefit(x,y,10,5,'p');

 % Plot
 figure(3)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2]), grid on
 legend('data','no constraints','periodic')
 title('EXAMPLE 3: Periodic boundary conditions')

 % Check boundary conditions
 y0 = ppval(pp2,[0,2*pi]);             % y
 y1 = ppval(ppdiff(pp2,1),[0,2*pi]);   % y'
 y2 = ppval(ppdiff(pp2,2),[0,2*pi]);   % y''
 y3 = ppval(ppdiff(pp2,3),[0,2*pi]);   % y'''
 disp('Endpoint derivatives:')
 disp([y0;y1;y2;y3])



 %% EXAMPLE 4: Endpoint conditions

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(2*x) + 0.1*randn(size(x));

 % Breaks
 breaks = linspace(0,2*pi,10);

 % Clamped endpoints, y = y' = 0
 xc = [0,0,2*pi,2*pi];
 cc = [eye(2),eye(2)];
 con = struct('xc',xc,'cc',cc);
 pp1 = splinefit(x,y,breaks,con);

 % Hinged periodic endpoints, y = 0
 con = struct('xc',0);
 pp2 = splinefit(x,y,breaks,con,'p');

 % Plot
 figure(4)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2]), grid on
 legend('data','clamped','hinged periodic')
 title('EXAMPLE 4: Endpoint conditions')



 %% EXAMPLE 5: Airfoil data

 % Truncated data
 x = [0,1,2,4,8,16,24,40,56,72,80]/80;
 y = [0,28,39,53,70,86,90,79,55,22,2]/1000;
 xy = [x;y];

 % Curve length parameter
 ds = sqrt(diff(x).^2 + diff(y).^2);
 s = [0, cumsum(ds)];

 % Constraints at s = 0: (x,y) = (0,0), (dx/ds,dy/ds) = (0,1)
 con = struct('xc',[0 0],'yc',[0 0; 0 1],'cc',eye(2));

 % Fit a spline with 4 pieces
 pp = splinefit(s,xy,4,con);

 % Plot
 figure(5)
 ss = linspace(0,s(end),400);
 xyfit = ppval(pp,ss);
 xyb = ppval(pp,pp.breaks);
 plot(x,y,'.',xyfit(1,:),xyfit(2,:),'r',xyb(1,:),xyb(2,:),'ro')
 legend('data','spline','breaks')
 grid on, axis equal
 title('EXAMPLE 5: Airfoil data')



 %% EXAMPLE 6: Robust fitting

 % Data
 x = linspace(0,2*pi,200);
 y = sin(x) + sin(2*x) + 0.05*randn(size(x));

 % Add outliers
 x = [x, linspace(0,2*pi,60)];
 y = [y, -ones(1,60)];

 % Fit splines with hinged conditions
 con = struct('xc',[0,2*pi]);
 pp1 = splinefit(x,y,8,con,0.25); % Robust fitting
 pp2 = splinefit(x,y,8,con,0.75); % Robust fitting
 pp3 = splinefit(x,y,8,con); % No robust fitting

 % Plot
 figure(6)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 y3 = ppval(pp3,xx);
 plot(x,y,'.',xx,[y1;y2;y3]), grid on
 legend('data with outliers','robust, beta = 0.25','robust, beta = 0.75',...
     'no robust fitting')
 title('EXAMPLE 6: Robust fitting')</pre>
<!-- <div class="fragment"><pre class="comment">SPLINEFIT Fit a spline to noisy data.
   PP = SPLINEFIT(X,Y,BREAKS) fits a piecewise cubic spline with breaks
   (knots) BREAKS to the noisy data (X,Y). X is a vector and Y is a vector
   or an ND array. If Y is an ND array, then X(j) and Y(:,...,:,j) are
   matched. Use PPVAL to evaluate PP.

   PP = SPLINEFIT(X,Y,P) where P is a positive integer interpolates the
   breaks linearly from the sorted locations of X. P is the number of
   spline pieces and P+1 is the number of breaks.

   OPTIONAL INPUT
   Argument places 4 to 8 are reserved for optional input.
   These optional arguments can be given in any order:

   PP = SPLINEFIT(...,'p') applies periodic boundary conditions to
   the spline. The period length is MAX(BREAKS)-MIN(BREAKS).

   PP = SPLINEFIT(...,'r') uses robust fitting to reduce the influence
   from outlying data points. Three iterations of weighted least squares
   are performed. Weights are computed from previous residuals.

   PP = SPLINEFIT(...,BETA), where 0 &lt; BETA &lt; 1, sets the robust fitting
   parameter BETA and activates robust fitting ('r' can be omitted).
   Default is BETA = 1/2. BETA close to 0 gives all data equal weighting.
   Increase BETA to reduce the influence from outlying data. BETA close
   to 1 may cause instability or rank deficiency.

   PP = SPLINEFIT(...,N) sets the spline order to N. Default is a cubic
   spline with order N = 4. A spline with P pieces has P+N-1 degrees of
   freedom. With periodic boundary conditions the degrees of freedom are
   reduced to P.

   PP = SPLINEFIT(...,CON) applies linear constraints to the spline.
   CON is a structure with fields 'xc', 'yc' and 'cc':
       'xc', x-locations (vector)
       'yc', y-values (vector or ND array)
       'cc', coefficients (matrix).

   Constraints are linear combinations of derivatives of order 0 to N-2
   according to

     cc(1,j)*y(x) + cc(2,j)*y'(x) + ... = yc(:,...,:,j),  x = xc(j).

   The maximum number of rows for 'cc' is N-1. If omitted or empty 'cc'
   defaults to a single row of ones. Default for 'yc' is a zero array.

   EXAMPLES

       % Noisy data
       x = linspace(0,2*pi,100);
       y = sin(x) + 0.1*randn(size(x));
       % Breaks
       breaks = [0:5,2*pi];

       % Fit a spline of order 5
       pp = splinefit(x,y,breaks,5);

       % Fit a spline of order 3 with periodic boundary conditions
       pp = splinefit(x,y,breaks,3,'p');

       % Constraints: y(0) = 0, y'(0) = 1 and y(3) + y&quot;(3) = 0
       xc = [0 0 3];
       yc = [0 1 0];
       cc = [1 0 1; 0 1 0; 0 0 1];
       con = struct('xc',xc,'yc',yc,'cc',cc);

       % Fit a cubic spline with 8 pieces and constraints
       pp = splinefit(x,y,8,con);

       % Fit a spline of order 6 with constraints and periodicity
       pp = splinefit(x,y,breaks,con,6,'p');

   See also SPLINE, PPVAL, PPDIFF, PPINT

 OTHER EXAMPLES
 %%% <a href="splinefit.md" class="code" title="pp = splinefit(varargin)">SPLINEFIT</a> EXAMPLES


 %% EXAMPLE 1: Breaks and pieces

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(x) + sin(2*x) + 0.2*randn(size(x));

 % Uniform breaks
 breaks = linspace(0,2*pi,41); % 41 breaks, 40 pieces
 pp1 = splinefit(x,y,breaks);

 % Breaks interpolated from data
 pp2 = splinefit(x,y,10);  % 11 breaks, 10 pieces

 % Plot
 figure(1)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2])
 axis([0,2*pi,-2.5,2.5]), grid on
 legend('data','41 breaks, 40 pieces','11 breaks, 10 pieces')
 title('EXAMPLE 1: Breaks and pieces')



 %% EXAMPLE 2: Spline orders

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(x) + sin(2*x) + 0.1*randn(size(x));

 % Splines
 pp1 = splinefit(x,y,8,1);  % Piecewise constant
 pp2 = splinefit(x,y,8,2);  % Piecewise linear
 pp3 = splinefit(x,y,8,3);  % Piecewise quadratic
 pp4 = splinefit(x,y,8,4);  % Piecewise cubic
 pp5 = splinefit(x,y,8,5);  % Etc.

 % Plot
 figure(2)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 y3 = ppval(pp3,xx);
 y4 = ppval(pp4,xx);
 y5 = ppval(pp5,xx);
 plot(x,y,'.',xx,[y1;y2;y3;y4;y5]), grid on
 legend('data','order 1','order 2','order 3','order 4','order 5')
 title('EXAMPLE 2: Spline orders')



 %% EXAMPLE 3: Periodic boundary conditions

 % Data (100 points)
 x = 2*pi*[0,rand(1,98),1];
 y = sin(x) - cos(2*x) + 0.2*randn(size(x));

 % No constraints
 pp1 = splinefit(x,y,10,5);
 % Periodic boundaries
 pp2 = splinefit(x,y,10,5,'p');

 % Plot
 figure(3)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2]), grid on
 legend('data','no constraints','periodic')
 title('EXAMPLE 3: Periodic boundary conditions')

 % Check boundary conditions
 y0 = ppval(pp2,[0,2*pi]);             % y
 y1 = ppval(ppdiff(pp2,1),[0,2*pi]);   % y'
 y2 = ppval(ppdiff(pp2,2),[0,2*pi]);   % y''
 y3 = ppval(ppdiff(pp2,3),[0,2*pi]);   % y'''
 disp('Endpoint derivatives:')
 disp([y0;y1;y2;y3])



 %% EXAMPLE 4: Endpoint conditions

 % Data (200 points)
 x = 2*pi*rand(1,200);
 y = sin(2*x) + 0.1*randn(size(x));

 % Breaks
 breaks = linspace(0,2*pi,10);

 % Clamped endpoints, y = y' = 0
 xc = [0,0,2*pi,2*pi];
 cc = [eye(2),eye(2)];
 con = struct('xc',xc,'cc',cc);
 pp1 = splinefit(x,y,breaks,con);

 % Hinged periodic endpoints, y = 0
 con = struct('xc',0);
 pp2 = splinefit(x,y,breaks,con,'p');

 % Plot
 figure(4)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 plot(x,y,'.',xx,[y1;y2]), grid on
 legend('data','clamped','hinged periodic')
 title('EXAMPLE 4: Endpoint conditions')



 %% EXAMPLE 5: Airfoil data

 % Truncated data
 x = [0,1,2,4,8,16,24,40,56,72,80]/80;
 y = [0,28,39,53,70,86,90,79,55,22,2]/1000;
 xy = [x;y];

 % Curve length parameter
 ds = sqrt(diff(x).^2 + diff(y).^2);
 s = [0, cumsum(ds)];

 % Constraints at s = 0: (x,y) = (0,0), (dx/ds,dy/ds) = (0,1)
 con = struct('xc',[0 0],'yc',[0 0; 0 1],'cc',eye(2));

 % Fit a spline with 4 pieces
 pp = splinefit(s,xy,4,con);

 % Plot
 figure(5)
 ss = linspace(0,s(end),400);
 xyfit = ppval(pp,ss);
 xyb = ppval(pp,pp.breaks);
 plot(x,y,'.',xyfit(1,:),xyfit(2,:),'r',xyb(1,:),xyb(2,:),'ro')
 legend('data','spline','breaks')
 grid on, axis equal
 title('EXAMPLE 5: Airfoil data')



 %% EXAMPLE 6: Robust fitting

 % Data
 x = linspace(0,2*pi,200);
 y = sin(x) + sin(2*x) + 0.05*randn(size(x));

 % Add outliers
 x = [x, linspace(0,2*pi,60)];
 y = [y, -ones(1,60)];

 % Fit splines with hinged conditions
 con = struct('xc',[0,2*pi]);
 pp1 = splinefit(x,y,8,con,0.25); % Robust fitting
 pp2 = splinefit(x,y,8,con,0.75); % Robust fitting
 pp3 = splinefit(x,y,8,con); % No robust fitting

 % Plot
 figure(6)
 xx = linspace(0,2*pi,400);
 y1 = ppval(pp1,xx);
 y2 = ppval(pp2,xx);
 y3 = ppval(pp3,xx);
 plot(x,y,'.',xx,[y1;y2;y3]), grid on
 legend('data with outliers','robust, beta = 0.25','robust, beta = 0.75',...
     'no robust fitting')
 title('EXAMPLE 6: Robust fitting')</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../SplineN" class="code" title="sp = SplineN (nn,deriv,xi,degree)">SplineN</a>	Spline interpolation polynomials in interval -1<xi<1</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->