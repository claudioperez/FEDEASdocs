
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Create_TickLabels</div>

--------------------------

# `Create_TickLabels`


## <a name="_name"></a>Purpose

creates cell array of tick labels with custom label skipping


## <a name="_synopsis"></a>Synopsis

`TickLabel = Create_TickLabels (TickNum,TickOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_TICKLABELS creates cell array of tick labels with custom label skipping
  TICKLABEL = CREATE_TICKLABELS (TICKNUM,TICKOPT)
  the function creates the cell array of tick labels TICKLABEL by converting the numbers
  in the numerical array TICKNUM to labels
  the structure TICKOPT has the following fields:
    TICKOPT.TLStrt: specifies the cell number for the first label (default=1)
           .TLSpac: specifies the cell spacing of sequential numbers
                    (default=2 i.e. one empty cell between labels)
  Example: Create_TickLabels( 1:5 ) generates a 9x1 cell array with the characters
           1,2,3,4,5 in cells 1,3,5,7,9 while the other cells are empty
  Example: Create_TickLabels( 1:5 , TickOpt) with TickOpt.TLStrt = 2 and TLSpac = 3
           generates a 16x1 cell array with the character 1 in the second cell and the
           characters 2,3,4,5 in the cells 5,8,11,14 respectively</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_TICKLABELS creates cell array of tick labels with custom label skipping
  TICKLABEL = CREATE_TICKLABELS (TICKNUM,TICKOPT)
  the function creates the cell array of tick labels TICKLABEL by converting the numbers
  in the numerical array TICKNUM to labels
  the structure TICKOPT has the following fields:
    TICKOPT.TLStrt: specifies the cell number for the first label (default=1)
           .TLSpac: specifies the cell spacing of sequential numbers
                    (default=2 i.e. one empty cell between labels)
  Example: Create_TickLabels( 1:5 ) generates a 9x1 cell array with the characters
           1,2,3,4,5 in cells 1,3,5,7,9 while the other cells are empty
  Example: Create_TickLabels( 1:5 , TickOpt) with TickOpt.TLStrt = 2 and TLSpac = 3
           generates a 16x1 cell array with the character 1 in the second cell and the
           characters 2,3,4,5 in the cells 5,8,11,14 respectively</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->