
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Create_Window</div>

--------------------------

# `Create_Window`


## <a name="_name"></a>Purpose

creates new window with given dimensions


## <a name="_synopsis"></a>Synopsis

`FigH = Create_Window (dx,dy)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_WINDOW creates new window with given dimensions
  FIGH = CREATE_WINDOW (DX,DY)
  the function creates a new window with figure handle FIGH
  and dimensions DX and DY as proportions of the screen size
  in the horizontal and vertical direction, respectively</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_WINDOW creates new window with given dimensions
  FIGH = CREATE_WINDOW (DX,DY)
  the function creates a new window with figure handle FIGH
  and dimensions DX and DY as proportions of the screen size
  in the horizontal and vertical direction, respectively</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/General/ElasticSpectra4EQRecord" class="code" title="Fig = ElasticSpectra4EQRecord(AccHst,Options)">ElasticSpectra4EQRecord</a>	generates elastic response spectra for earthquake record</li><li><a href="../../../Utilities/General/S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../../../Utilities/General/S_Process_EQRecordO" class="code" title="">S_Process_EQRecordO</a>	% script for processing ground motion records in PEER database format</li><li><a href="../Plot_EQRecord" class="code" title="">Plot_EQRecord</a>	% script for processing ground motion records</li><li><a href="../Tripartite_Plot" class="code" title="Tripartite_Plot">Tripartite_Plot</a>	% THIS SHOULD MAKE A TRI-PARTITE PLOT</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->