
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Draw_3dAxisCross</div>

--------------------------

# `Draw_3dAxisCross`


## <a name="_name"></a>Purpose

draw cross through the axes origin of the x-y-z data


## <a name="_synopsis"></a>Synopsis

`Draw_3dAxisCross (Xlim,Ylim,Zlim,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DRAW_3DAXISCROSS draw cross through the axes origin of the x-y-z data
  DRAW_3DAXISCROSS (XLIM,YLIM, ZLIM, PLOTOPT)
  the function draws a cross through the axes origin of the x-y-z data
  with a gray, solid line style and 1.5 pt line width;
  these properties can be controlled by specifying the fields LnStl, LnWth and Color
  of the optional argument PLOTOPT;
  XLIM, YLIM, ZLIM are 1x2 numerical arrays for the specification of the axes endpoints</pre>
<!-- <div class="fragment"><pre class="comment">DRAW_3DAXISCROSS draw cross through the axes origin of the x-y-z data
  DRAW_3DAXISCROSS (XLIM,YLIM, ZLIM, PLOTOPT)
  the function draws a cross through the axes origin of the x-y-z data
  with a gray, solid line style and 1.5 pt line width;
  these properties can be controlled by specifying the fields LnStl, LnWth and Color
  of the optional argument PLOTOPT;
  XLIM, YLIM, ZLIM are 1x2 numerical arrays for the specification of the axes endpoints</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->