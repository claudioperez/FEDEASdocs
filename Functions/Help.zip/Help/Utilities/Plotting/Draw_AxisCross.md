
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Draw_AxisCross</div>

--------------------------

# `Draw_AxisCross`


## <a name="_name"></a>Purpose

draw cross through the axes origin of the x-y data


## <a name="_synopsis"></a>Synopsis

`Draw_AxisCross (Xlim,Ylim,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DRAW_AXISCROSS draw cross through the axes origin of the x-y data
  DRAW_AXISCROSS (XLIM,YLIM,PLOTOPT)
  the function draws a cross through the axes origin of the x-y data
  with a gray, solid line style and 1.5 pt line width;
  these properties can be controlled by specifying the fields LnStl, LnWth and LnClr
  of the optional argument PLOTOPT;
  XLIM and YLIM are 1x2 numerical arrays for the specification of the axes endpoints</pre>
<!-- <div class="fragment"><pre class="comment">DRAW_AXISCROSS draw cross through the axes origin of the x-y data
  DRAW_AXISCROSS (XLIM,YLIM,PLOTOPT)
  the function draws a cross through the axes origin of the x-y data
  with a gray, solid line style and 1.5 pt line width;
  these properties can be controlled by specifying the fields LnStl, LnWth and LnClr
  of the optional argument PLOTOPT;
  XLIM and YLIM are 1x2 numerical arrays for the specification of the axes endpoints</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Plot_DispPath" class="code" title="AxHndl = Plot_DispPath (DspHst,PlotOpt)">Plot_DispPath</a>	plots biaxial displacement path in current window</li><li><a href="../Plot_LoadHistory" class="code" title="AxHndl = Plot_LoadHistory(DspHst,FrcHst,PlotOpt)">Plot_LoadHistory</a>	plots uniaxial or biaxial displacement and axial force history in current window</li><li><a href="../Plot_StoryDistr" class="code" title="AxHndl = Plot_StoryDistr (Xp,PlotOpt)">Plot_StoryDistr</a>	plots all columns of array XP against the row index</li><li><a href="../Plot_XYData" class="code" title="AxHndl = Plot_XYData (Xp,Yp,PlotOpt,AxHndl)">Plot_XYData</a>	plots one or more pairs of X and Y array columns</li><li><a href="../Plot_XYData_Mark" class="code" title="AxHndl = Plot_XYData (Xp,Yp,PlotOpt,AxHndl)">Plot_XYData_Mark</a>	plots one or more pairs of X and Y array columns</li><li><a href="../../../Utilities/Plotting/Sections/Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->