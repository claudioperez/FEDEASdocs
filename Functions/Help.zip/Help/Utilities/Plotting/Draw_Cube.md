
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Draw_Cube</div>

--------------------------

# `Draw_Cube`


## <a name="_name"></a>Purpose

draws cube in current window


## <a name="_synopsis"></a>Synopsis

`Draw_Cube (XYZc,Size,Color)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">DRAW_CUBE draws cube in current window
  DRAW_CUBE (XYZC,SIZE,COLOR)
  the function draws a cube of size SIZE with center coordinates XYZc
  and assigns COLOR to cube faces and edges</pre>
<!-- <div class="fragment"><pre class="comment">DRAW_CUBE draws cube in current window
  DRAW_CUBE (XYZC,SIZE,COLOR)
  the function draws a cube of size SIZE with center coordinates XYZc
  and assigns COLOR to cube faces and edges</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/Plotting/Structure/Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->