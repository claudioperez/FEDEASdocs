
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; Label_2dMoments</div>

--------------------------

# `Label_2dMoments`


## <a name="_name"></a>Purpose

label end moment values for 2d frame elements in current window


## <a name="_synopsis"></a>Synopsis

`Label_2dMoments (Model,Post,ElemList,Digit,Units)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LABEL_2dMOMENTS label end moment values for 2d frame elements in current window
  LABEL_2dMOMENTS (MODEL,POST,ELEMLIST,DIGIT,UNITS)
  the function displays in the current window the end moment values of 2d frame elements
  in ELEMLIST for the structural model in data structure MODEL;
  POST is either the vector of basic forces Q, or
  a cell array with post-processing information for the basic element forces in POST.ELEM{el}.Q;
  the optional row vector ELEMLIST contains the numbers of elements to include for labeling,
  e.g. [1:4 7 9] selects elements 1 through 4, 7 and 9;
  the optional integer DIGIT controls the number of digits after the comma (default=1)
  the optional integer UNITS scales the output values by the UNITS value</pre>
<!-- <div class="fragment"><pre class="comment">LABEL_2dMOMENTS label end moment values for 2d frame elements in current window
  LABEL_2dMOMENTS (MODEL,POST,ELEMLIST,DIGIT,UNITS)
  the function displays in the current window the end moment values of 2d frame elements
  in ELEMLIST for the structural model in data structure MODEL;
  POST is either the vector of basic forces Q, or
  a cell array with post-processing information for the basic element forces in POST.ELEM{el}.Q;
  the optional row vector ELEMLIST contains the numbers of elements to include for labeling,
  e.g. [1:4 7 9] selects elements 1 through 4, 7 and 9;
  the optional integer DIGIT controls the number of digits after the comma (default=1)
  the optional integer UNITS scales the output values by the UNITS value</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Utilities/PostProcessing/Q2Post" class="code" title="Post = Q2Post (Model,Q)">Q2Post</a>	converts the vector of basic forces Q to cell array Post.Elem{}</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->