
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; Plot_2dMomntDistr</div>

--------------------------

# `Plot_2dMomntDistr`


## <a name="_name"></a>Purpose

plots moment distribution for 2d frame elements in current window


## <a name="_synopsis"></a>Synopsis

`Plot_2dMomntDistr (Model,ElemData,Post,ElemList,UserScale)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_2dMOMNTDISTR plots moment distribution for 2d frame elements in current window
  PLOT_2dMOMNTDISTR (MODEL,ELEMDATA,POST,ELEMLIST,USERSCALE)
  the function plots in the current window the moment distribution for 2d frame elements
  in ELEMLIST for the structural model in data structure MODEL;
  the cell array ELEMDATA carries information about element loading;
  POST is either the vector of basic forces Q, or 
  a cell array with post-processing information for the basic element forces in POST.ELEM{el}.Q;
  the optional row vector ELEMLIST contains the numbers of elements to include for plotting,
  e.g. [1:4 7 9] selects elements 1 through 4, 7 and 9;
  the optional scalar argument USERSCALE is a magnification factor for the diagram (default=1)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_2dMOMNTDISTR plots moment distribution for 2d frame elements in current window
  PLOT_2dMOMNTDISTR (MODEL,ELEMDATA,POST,ELEMLIST,USERSCALE)
  the function plots in the current window the moment distribution for 2d frame elements
  in ELEMLIST for the structural model in data structure MODEL;
  the cell array ELEMDATA carries information about element loading;
  POST is either the vector of basic forces Q, or 
  a cell array with post-processing information for the basic element forces in POST.ELEM{el}.Q;
  the optional row vector ELEMLIST contains the numbers of elements to include for plotting,
  e.g. [1:4 7 9] selects elements 1 through 4, 7 and 9;
  the optional scalar argument USERSCALE is a magnification factor for the diagram (default=1)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Utilities/Plotting/Structure/Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li><li><a href="../../../../Utilities/PostProcessing/Q2Post" class="code" title="Post = Q2Post (Model,Q)">Q2Post</a>	converts the vector of basic forces Q to cell array Post.Elem{}</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->