
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; Plot_ForcDistr</div>

--------------------------

# `Plot_ForcDistr`


## <a name="_name"></a>Purpose

plots internal force distribution for truss and frame elements in ElemList


## <a name="_synopsis"></a>Synopsis

`Plot_ForcDistr (Model,ElemData,Post,Component,ElemList,UserScale)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_FORCDISTR plots internal force distribution for truss and frame elements in ElemList
  PLOT_FORCDISTR (MODEL,ELEMDATA,POST,COMPONENT,ELEMLIST,USERSCALE)
  function plots the distribution of the internal force identified by COMPONENT
  for the truss and frame elements in ELEMLIST in the current window; the model information
  is available in data structure MODEL and the element properties in cell array ELEMDATA;
  the current response of the model is supplied in data structure POST;
  COMPONENT is a character variable with one of the following values:
  N for axial force, Mx for torsional moment, My for bending moment about y-axis
  and Mz for bending moment about z-axis; ELEMLIST is optional (default is all elements)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_FORCDISTR plots internal force distribution for truss and frame elements in ElemList
  PLOT_FORCDISTR (MODEL,ELEMDATA,POST,COMPONENT,ELEMLIST,USERSCALE)
  function plots the distribution of the internal force identified by COMPONENT
  for the truss and frame elements in ELEMLIST in the current window; the model information
  is available in data structure MODEL and the element properties in cell array ELEMDATA;
  the current response of the model is supplied in data structure POST;
  COMPONENT is a character variable with one of the following values:
  N for axial force, Mx for torsional moment, My for bending moment about y-axis
  and Mz for bending moment about z-axis; ELEMLIST is optional (default is all elements)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->