
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; Plot_IPStressField</div>

--------------------------

# `Plot_IPStressField`


## <a name="_name"></a>Purpose

plots stress field for all elements in the Model


## <a name="_synopsis"></a>Synopsis

`FldNd = Plot_IPStressField (Model,U,Post,Type,Comp,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_STRESSFIELD plots stress field for all elements in the Model
  FLDND = PLOT_STRESSFIELD (MODEL,STATE,POST,TYPE,COMP,PLOTOPT)
  the function plots in the current window the distribution of component COMP
  for the stress field TYPE for all finite elements in the model;
  the function uses the Matlab function scatteredInterpolant to inter-extra polate from the
  stress field values at the integration points of the elements to the nodal values
  and returns the resulting nodal values in vector FLDND;
  TYPE is a character variable with values 'Axial', 'Shear' or 'Momnt';
  COMP is a character variable with values 'xx','yy','zz','xy',yz','zx', '1', '2' or '3'
  for the axial and moment field, and values 'xy','yz','zx' for the shear field;
  COMP equal to '1', '2' or '3' plots the principal values of the corresponding field
  the model information is supplied in data structure MODEL;
  U are the global dof displacements; when present
  the function plots the stress field in the deformed configuration;
  POST is a data structure with the stress values of element e at integration point m in fields
    Elem{e}.Mat{m}.sig: for the membrane stresses
    Elem{e}.Mat{m}.M  : for the bending moments
    Elem{e}.Mat{m}.V  : for the shear forces
  PLOTOPT is an optional data structure with the following fields:
    Coord: coordinate system for stress field ('Carte','Polar','Spher') (default = 'Carte')
    MAGF : magnification factor for deformed shape (default=10)
    StrSF: scale factor for stress field (default=1)
    DirSF: scale factor for principal stress director line (default=1)
    LnWth: line width (default=1)
    LnClr: wireframe color (default = [0.6 0.6 0.6])
    IntMd: interpolation method ('linear','nearest','natural'; default='natural')
    ExtMd: extrapolation method ('linear','nearest','none'   ; default='nearest')</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_STRESSFIELD plots stress field for all elements in the Model
  FLDND = PLOT_STRESSFIELD (MODEL,STATE,POST,TYPE,COMP,PLOTOPT)
  the function plots in the current window the distribution of component COMP
  for the stress field TYPE for all finite elements in the model;
  the function uses the Matlab function scatteredInterpolant to inter-extra polate from the
  stress field values at the integration points of the elements to the nodal values
  and returns the resulting nodal values in vector FLDND;
  TYPE is a character variable with values 'Axial', 'Shear' or 'Momnt';
  COMP is a character variable with values 'xx','yy','zz','xy',yz','zx', '1', '2' or '3'
  for the axial and moment field, and values 'xy','yz','zx' for the shear field;
  COMP equal to '1', '2' or '3' plots the principal values of the corresponding field
  the model information is supplied in data structure MODEL;
  U are the global dof displacements; when present
  the function plots the stress field in the deformed configuration;
  POST is a data structure with the stress values of element e at integration point m in fields
    Elem{e}.Mat{m}.sig: for the membrane stresses
    Elem{e}.Mat{m}.M  : for the bending moments
    Elem{e}.Mat{m}.V  : for the shear forces
  PLOTOPT is an optional data structure with the following fields:
    Coord: coordinate system for stress field ('Carte','Polar','Spher') (default = 'Carte')
    MAGF : magnification factor for deformed shape (default=10)
    StrSF: scale factor for stress field (default=1)
    DirSF: scale factor for principal stress director line (default=1)
    LnWth: line width (default=1)
    LnClr: wireframe color (default = [0.6 0.6 0.6])
    IntMd: interpolation method ('linear','nearest','natural'; default='natural')
    ExtMd: extrapolation method ('linear','nearest','none'   ; default='nearest')</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Plotting/elNodCON" class="code" title="indx = elNodCON (ndm,nodix,ElemName)">elNodCON</a>	generates a connectivity index array for each type of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->