
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; Plot_StressField</div>

--------------------------

# `Plot_StressField`


## <a name="_name"></a>Purpose

plots stress field for all elements in the Model


## <a name="_synopsis"></a>Synopsis

`Plot_StressField (Model,U,Plot,Type,Comp,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_STRESSFIELD plots stress field for all elements in the Model
  PLOT_STRESSFIELD (MODEL,STATE,PLOT,TYPE,COMP,PLOTOPT)
  the function plots in the current window the distribution of component COMP
  for the stress field TYPE for all finite elements in the model;
  TYPE is a character variable with values 'Axial', 'Shear' or 'Momnt';
  COMP is a character variable with values 'xx','yy','zz','xy',yz','zx', '1', '2' or '3'
  for the axial and moment field, and values 'xy','yz','zx' for the shear field;
  COMP equal to '1', '2' or '3' plots the principal values of the corresponding field
  the model information is supplied in data structure MODEL;
  U are the global dof displacements; when present
  the function plots the stress field in the deformed configuration;
  PLOT is a data structure with the nodal stress values in fields
    sigNd: for the membrane stresses
    MomNd: for the bending moments
    ShrNd: for the shear forces
  PLOTOPT is an optional data structure with the following fields:
    Coord: coordinate system for stress field ('Carte','Polar','Spher') (default = 'Carte')
    MAGF : magnification factor for deformed shape (default=10)
    StrSF: scale factor for stress field (default=1)
    DirSF: scale factor for principal stress director line (default=1)
    LnWth: line width (default=1)
    LnClr: wireframe color (default = [0.6 0.6 0.6])</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_STRESSFIELD plots stress field for all elements in the Model
  PLOT_STRESSFIELD (MODEL,STATE,PLOT,TYPE,COMP,PLOTOPT)
  the function plots in the current window the distribution of component COMP
  for the stress field TYPE for all finite elements in the model;
  TYPE is a character variable with values 'Axial', 'Shear' or 'Momnt';
  COMP is a character variable with values 'xx','yy','zz','xy',yz','zx', '1', '2' or '3'
  for the axial and moment field, and values 'xy','yz','zx' for the shear field;
  COMP equal to '1', '2' or '3' plots the principal values of the corresponding field
  the model information is supplied in data structure MODEL;
  U are the global dof displacements; when present
  the function plots the stress field in the deformed configuration;
  PLOT is a data structure with the nodal stress values in fields
    sigNd: for the membrane stresses
    MomNd: for the bending moments
    ShrNd: for the shear forces
  PLOTOPT is an optional data structure with the following fields:
    Coord: coordinate system for stress field ('Carte','Polar','Spher') (default = 'Carte')
    MAGF : magnification factor for deformed shape (default=10)
    StrSF: scale factor for stress field (default=1)
    DirSF: scale factor for principal stress director line (default=1)
    LnWth: line width (default=1)
    LnClr: wireframe color (default = [0.6 0.6 0.6])</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Plotting/elNodCON" class="code" title="indx = elNodCON (ndm,nodix,ElemName)">elNodCON</a>	generates a connectivity index array for each type of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->