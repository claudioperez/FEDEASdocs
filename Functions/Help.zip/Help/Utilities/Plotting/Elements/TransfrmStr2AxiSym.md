
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Elements</a> &gt; TransfrmStr2AxiSym</div>

--------------------------

# `TransfrmStr2AxiSym`


## <a name="_name"></a>Purpose

transform stress tensor field to axi-symmetric


## <a name="_synopsis"></a>Synopsis

`Post = TransfrmStr2AxiSym (Model,Post,Type,SymAx,AxOr,ElemList)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">TRANSFRM2AXISYM transform stress tensor field to axi-symmetric</pre>
<!-- <div class="fragment"><pre class="comment">TRANSFRM2AXISYM transform stress tensor field to axi-symmetric</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->