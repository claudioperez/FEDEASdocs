---
title: Elements
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Elements`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Elements

<table>
<tr><td><a href="Cart2PolarTensorTrans">Cart2PolarTensorTrans</a></td><td>tensor component transformation from cartesian to polar coordinates </td></tr><tr><td><a href="Get_IPVarDistr">Get_IPVarDistr</a></td><td>plots distribution of integration point variables of elements with sections </td></tr><tr><td><a href="Label_2dMoments">Label_2dMoments</a></td><td>label end moment values for 2d frame elements in current window </td></tr><tr><td><a href="Label_AxialForces">Label_AxialForces</a></td><td>label axial force values in current window </td></tr><tr><td><a href="Plot_2dCurvDistr">Plot_2dCurvDistr</a></td><td>plot curvature distribution of 2d linear elastic frame elements </td></tr><tr><td><a href="Plot_2dMomntDistr">Plot_2dMomntDistr</a></td><td>plots moment distribution for 2d frame elements in current window </td></tr><tr><td><a href="Plot_AxialForces">Plot_AxialForces</a></td><td>plot axial forces in current window </td></tr><tr><td><a href="Plot_ForcDistr">Plot_ForcDistr</a></td><td>plots internal force distribution for truss and frame elements in ElemList </td></tr><tr><td><a href="Plot_IPStressField">Plot_IPStressField</a></td><td>plots stress field for all elements in the Model </td></tr><tr><td><a href="Plot_IPVarDistr">Plot_IPVarDistr</a></td><td>plots distribution of integration point variables of elements with sections </td></tr><tr><td><a href="Plot_StressField">Plot_StressField</a></td><td>plots stress field for all elements in the Model </td></tr><tr><td><a href="TransfrmStr2AxiSym">TransfrmStr2AxiSym</a></td><td>transform stress tensor field to axi-symmetric </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->