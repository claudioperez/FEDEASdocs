
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Plot_DispPath</div>

--------------------------

# `Plot_DispPath`


## <a name="_name"></a>Purpose

plots biaxial displacement path in current window


## <a name="_synopsis"></a>Synopsis

`AxHndl = Plot_DispPath (DspHst,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_DISPPATH plots biaxial displacement path in current window
  AXHNDL = PLOT_DISPPATH (DSPHST,PLOTOPT)
  the function plots the biaxial displacement history in the structure array DSPHST
  in the current window and returns the axis handle in AXHNDL;
  the arrow on the displacement path corresponds to increasing pseudo-time;
  DSPHST has two entries with fields Time and Value;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth : line width for 2 or 3 plots (default=3)
         .LnStl : line style sequence for 2 or 3 plots (default='s-','o-','h-')
         .Color : color      sequence for 2 or 3 plots (default='k','b','r') 
         .MrkSz : marker size for 2 or 3 plots (default=5)
         .MFClr : marker face color sequence for 2 or 3 plots (default='k','b','r')
         .TipSF : scale factor for controlling the size of the arrow tip (default = 1);
         .ArWth : line width of arrow shaft (default = 1);
         .ArClr : color of arrow shaft and tip (default = 'k');
         .AbsSF : true or false to indicate absolute or relative to arrow length scaling</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_DISPPATH plots biaxial displacement path in current window
  AXHNDL = PLOT_DISPPATH (DSPHST,PLOTOPT)
  the function plots the biaxial displacement history in the structure array DSPHST
  in the current window and returns the axis handle in AXHNDL;
  the arrow on the displacement path corresponds to increasing pseudo-time;
  DSPHST has two entries with fields Time and Value;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth : line width for 2 or 3 plots (default=3)
         .LnStl : line style sequence for 2 or 3 plots (default='s-','o-','h-')
         .Color : color      sequence for 2 or 3 plots (default='k','b','r') 
         .MrkSz : marker size for 2 or 3 plots (default=5)
         .MFClr : marker face color sequence for 2 or 3 plots (default='k','b','r')
         .TipSF : scale factor for controlling the size of the arrow tip (default = 1);
         .ArWth : line width of arrow shaft (default = 1);
         .ArClr : color of arrow shaft and tip (default = 'k');
         .AbsSF : true or false to indicate absolute or relative to arrow length scaling</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Draw_Arrow" class="code" title="varargout = Draw_Arrow (Astr,Aend,Aln,PlotOpt)">Draw_Arrow</a>	draws 2d or 3d arrow</li><li><a href="../Draw_AxisCross" class="code" title="Draw_AxisCross (Xlim,Ylim,PlotOpt)">Draw_AxisCross</a>	draw cross through the axes origin of the x-y data</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->