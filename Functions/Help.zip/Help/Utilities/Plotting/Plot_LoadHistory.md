
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Plot_LoadHistory</div>

--------------------------

# `Plot_LoadHistory`


## <a name="_name"></a>Purpose

plots uniaxial or biaxial displacement and axial force history in current window


## <a name="_synopsis"></a>Synopsis

`AxHndl = Plot_LoadHistory(DspHst,FrcHst,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_LOADHISTORY plots uniaxial or biaxial displacement and axial force history in current window
  AXHNDL = PLOT_LOADHISTORY(DSPHST,FRCHST,PLOTOPT)
  the function plots the uniaxial or biaxial displacement history in the data structure DSPHST
  and the axial force history in the data structure FRCHST in the current window and
  returns the axis handle in AXHNDL;
  DSPHST has one entry for uniaxial and 2 entries for biaxial displacement patterns and
  has the fields Time and Value; FRCHST also has the fields Time and Value;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth  : line width for 2 or 3 plots (default=3)
         .LnStl  : line style sequence for 2 or 3 plots (default='s-','o-','h-')
         .LnClr  : color      sequence for 2 or 3 plots (default='k','b','r') 
         .MrkSz  : marker size for 2 or 3 plots (default=3)
         .MrkClr : marker face color sequence for 2 or 3 plots (default='k','b','r')</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_LOADHISTORY plots uniaxial or biaxial displacement and axial force history in current window
  AXHNDL = PLOT_LOADHISTORY(DSPHST,FRCHST,PLOTOPT)
  the function plots the uniaxial or biaxial displacement history in the data structure DSPHST
  and the axial force history in the data structure FRCHST in the current window and
  returns the axis handle in AXHNDL;
  DSPHST has one entry for uniaxial and 2 entries for biaxial displacement patterns and
  has the fields Time and Value; FRCHST also has the fields Time and Value;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth  : line width for 2 or 3 plots (default=3)
         .LnStl  : line style sequence for 2 or 3 plots (default='s-','o-','h-')
         .LnClr  : color      sequence for 2 or 3 plots (default='k','b','r') 
         .MrkSz  : marker size for 2 or 3 plots (default=3)
         .MrkClr : marker face color sequence for 2 or 3 plots (default='k','b','r')</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Draw_AxisCross" class="code" title="Draw_AxisCross (Xlim,Ylim,PlotOpt)">Draw_AxisCross</a>	draw cross through the axes origin of the x-y data</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->