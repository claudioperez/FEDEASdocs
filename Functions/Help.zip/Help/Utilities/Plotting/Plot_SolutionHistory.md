
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Plot_SolutionHistory</div>

--------------------------

# `Plot_SolutionHistory`


## <a name="_name"></a>Purpose

plots force-displacent pairs during iterative incremental solution


## <a name="_synopsis"></a>Synopsis

`AxHndl = Plot_SolutionHistory (PUFinl,PUIncr,PUIter,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_SOLUTIONHISTORY plots force-displacent pairs during iterative incremental solution
  AXHNDL = PLOT_SOLUTIONHISTORY (PUFINL,PUINCR,PUITER,PLOTOPT)
  the function plots in the current window the force-displacent pairs for specified DOFs
  during the iterative incremental solution;
  PUFINL, PUINCR and PUITER are data structures with the fields Uf, Pf and Pr
  for the free DOF displacements and the applied and resisting force vectors, respectively;
  if PUINCR is empty, the function plots only the final force-displacement pair for each step;
  PLOTOPT is a data structure with the following fields:
  PLOTOPT.LnWth  : line width            for plot ( default = [ 2 2 2 ]) 
         .LnStl  : line style sequence   for plot ( default = {'none';'none';':'} )
         .LnClr  : color      sequence   for plot ( default = {'b';'m';'k'} ) 
         .MrkSz  : marker size           for plot ( default = [ 6 15 10 ] )
         .MrkClr : marker color sequence for plot ( default = {'b';'m';'r'} )
         .MrkTyp : marker type sequence  for plot ( default = {'o';'s';'s'} )
         .XLbl   : character variable for X-Label ( default = 'X-data')
         .YLbl   : character variable for Y-Label ( default = 'X-data')
         .FntSz  : font size for plot elements    ( default = 30)
         .PScl   : scalar factor for scaling the applied forces (e.g. to get load factor)
         .ShwFin : logical variable for including the final solution (default = true)
         .Udof   : displacement DOF (negative to reverse direction in plot)
         .Pdof   : force        DOF (negative to reverse direction in plot)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_SOLUTIONHISTORY plots force-displacent pairs during iterative incremental solution
  AXHNDL = PLOT_SOLUTIONHISTORY (PUFINL,PUINCR,PUITER,PLOTOPT)
  the function plots in the current window the force-displacent pairs for specified DOFs
  during the iterative incremental solution;
  PUFINL, PUINCR and PUITER are data structures with the fields Uf, Pf and Pr
  for the free DOF displacements and the applied and resisting force vectors, respectively;
  if PUINCR is empty, the function plots only the final force-displacement pair for each step;
  PLOTOPT is a data structure with the following fields:
  PLOTOPT.LnWth  : line width            for plot ( default = [ 2 2 2 ]) 
         .LnStl  : line style sequence   for plot ( default = {'none';'none';':'} )
         .LnClr  : color      sequence   for plot ( default = {'b';'m';'k'} ) 
         .MrkSz  : marker size           for plot ( default = [ 6 15 10 ] )
         .MrkClr : marker color sequence for plot ( default = {'b';'m';'r'} )
         .MrkTyp : marker type sequence  for plot ( default = {'o';'s';'s'} )
         .XLbl   : character variable for X-Label ( default = 'X-data')
         .YLbl   : character variable for Y-Label ( default = 'X-data')
         .FntSz  : font size for plot elements    ( default = 30)
         .PScl   : scalar factor for scaling the applied forces (e.g. to get load factor)
         .ShwFin : logical variable for including the final solution (default = true)
         .Udof   : displacement DOF (negative to reverse direction in plot)
         .Pdof   : force        DOF (negative to reverse direction in plot)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Plot_XYData" class="code" title="AxHndl = Plot_XYData (Xp,Yp,PlotOpt,AxHndl)">Plot_XYData</a>	plots one or more pairs of X and Y array columns</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->