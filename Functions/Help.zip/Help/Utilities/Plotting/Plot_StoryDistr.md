
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Plot_StoryDistr</div>

--------------------------

# `Plot_StoryDistr`


## <a name="_name"></a>Purpose

plots all columns of array XP against the row index


## <a name="_synopsis"></a>Synopsis

`AxHndl = Plot_StoryDistr (Xp,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_STORYDISTR plots all columns of array XP against the row index
  AXHNDL = PLOT_STORYDISTR (XP,PLOTOPT)
  the function plots in the current window all columns of the array XP against the row index
  which is supposed to correspond to the story number and returns the axis handle in AXHNDL;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth : line width             for plot   (default = 2)
         .LnStl  : line style sequence   for plot   (default = {'-','--',':','-.',':','--'} )
         .LnClr  : color      sequence   for plot   (default = {'b','r','k','b','r','k'} ) 
         .MrkSz  : marker size           for plot   (default = 3)
         .MrkClr : marker color sequence for plot   (default = {'b','r','k','b','r','k'} )
         .MrkTyp : marker type sequence  for plot   (default = {'o','s','d','p','+','*'} )
         .NoXTk  : number of tick marks on X-axis (default = 5 including end points)
         .NoYTk  : number of tick marks on Y-axis (default = 5 including end points)
         .FntSz  : font size for plot elements    (default = 30)
         .XLbl   : character variable for X-Label (default = 'X-data')
         .YLbl   : character variable for Y-Label (default = 'X-data')
         .Legnd  : cell array of characters for plot legend (default: 1.Data, 2.Data, etc)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_STORYDISTR plots all columns of array XP against the row index
  AXHNDL = PLOT_STORYDISTR (XP,PLOTOPT)
  the function plots in the current window all columns of the array XP against the row index
  which is supposed to correspond to the story number and returns the axis handle in AXHNDL;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth : line width             for plot   (default = 2)
         .LnStl  : line style sequence   for plot   (default = {'-','--',':','-.',':','--'} )
         .LnClr  : color      sequence   for plot   (default = {'b','r','k','b','r','k'} ) 
         .MrkSz  : marker size           for plot   (default = 3)
         .MrkClr : marker color sequence for plot   (default = {'b','r','k','b','r','k'} )
         .MrkTyp : marker type sequence  for plot   (default = {'o','s','d','p','+','*'} )
         .NoXTk  : number of tick marks on X-axis (default = 5 including end points)
         .NoYTk  : number of tick marks on Y-axis (default = 5 including end points)
         .FntSz  : font size for plot elements    (default = 30)
         .XLbl   : character variable for X-Label (default = 'X-data')
         .YLbl   : character variable for Y-Label (default = 'X-data')
         .Legnd  : cell array of characters for plot legend (default: 1.Data, 2.Data, etc)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Draw_AxisCross" class="code" title="Draw_AxisCross (Xlim,Ylim,PlotOpt)">Draw_AxisCross</a>	draw cross through the axes origin of the x-y data</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->