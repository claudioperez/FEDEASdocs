
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Plot_XYData</div>

--------------------------

# `Plot_XYData`


## <a name="_name"></a>Purpose

plots one or more pairs of X and Y array columns


## <a name="_synopsis"></a>Synopsis

`AxHndl = Plot_XYData (Xp,Yp,PlotOpt,AxHndl)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_XYDATA plots one or more pairs of X and Y array columns
  AXHNDL = PLOT_XYDATA (XP,YP,PLOTOPT)
  the function plots in the current window one or more pairs of data in arrays XP and YP 
  and returns the axis handle in AXHNDL;
  the arrays XP and YP must have the same number of rows and columns;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth  : line width            for plot   (default = [ 2 no of X-Y pairs ]) 
         .LnStl  : line style sequence   for plot   (default = {'-','--',':','-.',':','--'} )
         .LnClr  : color      sequence   for plot   (default = {'b','r','k','b','r','k'} ) 
         .MrkSz  : marker size           for plot   (default = [ 3 no of X-Y pairs )
         .MrkClr : marker color sequence for plot   (default = {'b','r','k','b','r','k'} )
         .MrkTyp : marker type sequence  for plot   (default = {'o','s','d','p','+','*'} )
         .NoXTk  : number of tick marks on X-axis (default automatic)
         .NoYTk  : number of tick marks on Y-axis (default automatic)
         .FntSz  : font size for plot elements    (default = 27)
         .XLbl   : character variable for X-Label (default = 'X-data')
         .YLbl   : character variable for Y-Label (default = 'X-data')
         .Legnd  : cell array of characters for plot legend (default: 1.Data, 2.Data, etc)
         .ShwLg  : logical variable for showing the plot legend (default = false)
         .MltClr : logical variable for color cycling of different data pairs (default = false)
         .AxStl  : line style for coordinate cross (default '-')
         .AxClr  : line color for coordinate cross (default [0.25 0.25 0.25] )
         .AxWth  : line width for coordinate cross (default 1.5 )</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_XYDATA plots one or more pairs of X and Y array columns
  AXHNDL = PLOT_XYDATA (XP,YP,PLOTOPT)
  the function plots in the current window one or more pairs of data in arrays XP and YP 
  and returns the axis handle in AXHNDL;
  the arrays XP and YP must have the same number of rows and columns;
  the optional argument PLOTOPT is a structure with the following fields:
  PLOTOPT.LnWth  : line width            for plot   (default = [ 2 no of X-Y pairs ]) 
         .LnStl  : line style sequence   for plot   (default = {'-','--',':','-.',':','--'} )
         .LnClr  : color      sequence   for plot   (default = {'b','r','k','b','r','k'} ) 
         .MrkSz  : marker size           for plot   (default = [ 3 no of X-Y pairs )
         .MrkClr : marker color sequence for plot   (default = {'b','r','k','b','r','k'} )
         .MrkTyp : marker type sequence  for plot   (default = {'o','s','d','p','+','*'} )
         .NoXTk  : number of tick marks on X-axis (default automatic)
         .NoYTk  : number of tick marks on Y-axis (default automatic)
         .FntSz  : font size for plot elements    (default = 27)
         .XLbl   : character variable for X-Label (default = 'X-data')
         .YLbl   : character variable for Y-Label (default = 'X-data')
         .Legnd  : cell array of characters for plot legend (default: 1.Data, 2.Data, etc)
         .ShwLg  : logical variable for showing the plot legend (default = false)
         .MltClr : logical variable for color cycling of different data pairs (default = false)
         .AxStl  : line style for coordinate cross (default '-')
         .AxClr  : line color for coordinate cross (default [0.25 0.25 0.25] )
         .AxWth  : line width for coordinate cross (default 1.5 )</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Draw_AxisCross" class="code" title="Draw_AxisCross (Xlim,Ylim,PlotOpt)">Draw_AxisCross</a>	draw cross through the axes origin of the x-y data</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/General/ElasticSpectra4EQRecord" class="code" title="Fig = ElasticSpectra4EQRecord(AccHst,Options)">ElasticSpectra4EQRecord</a>	generates elastic response spectra for earthquake record</li><li><a href="../../../Utilities/General/S_Process_EQRecord" class="code" title="">S_Process_EQRecord</a>	% script for processing ground motion records in PEER database format</li><li><a href="../Plot_SolutionHistory" class="code" title="AxHndl = Plot_SolutionHistory (PUFinl,PUIncr,PUIter,PlotOpt)">Plot_SolutionHistory</a>	plots force-displacent pairs during iterative incremental solution</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->