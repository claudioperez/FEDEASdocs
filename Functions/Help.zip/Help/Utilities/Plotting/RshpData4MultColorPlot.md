
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; RshpData4MultColorPlot</div>

--------------------------

# `RshpData4MultColorPlot`


## <a name="_name"></a>Purpose

reshapes column vectors x and y to arrays for multi-color plotting


## <a name="_synopsis"></a>Synopsis

`[Xplot,Yplot] = RshpData4MultColorPlot (x,y,noRev,NoRwSC)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">RSHPDATA4MULTCOLORPLOT reshapes column vectors x and y to arrays for multi-color plotting
  [XPLOT,YPLOT] = RSHPDATA4MULTCOLORPLOT (X,Y,NOREV,NORWSC)
  X, Y  : column vectors for X-data and Y-data
  NOREV : number of load reversals in x and y
  NORWSC: number of reversals with single color (default=2)</pre>
<!-- <div class="fragment"><pre class="comment">RSHPDATA4MULTCOLORPLOT reshapes column vectors x and y to arrays for multi-color plotting
  [XPLOT,YPLOT] = RSHPDATA4MULTCOLORPLOT (X,Y,NOREV,NORWSC)
  X, Y  : column vectors for X-data and Y-data
  NOREV : number of load reversals in x and y
  NORWSC: number of reversals with single color (default=2)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->