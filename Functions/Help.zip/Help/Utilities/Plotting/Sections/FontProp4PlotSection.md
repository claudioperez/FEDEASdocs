
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; FontProp4PlotSection</div>

--------------------------

# `FontProp4PlotSection`


## <a name="_name"></a>Purpose

set up font attributes for section plot


## <a name="_synopsis"></a>Synopsis

`[Font,lt,ls] = FontProp4PlotSection()`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">FONTPROP4PLOTSECTION set up font attributes for section plot
  [FONT,LT,LS] = FONTPROP4PLOTSECTION ()
  the function sets up font attributes for section plot</pre>
<!-- <div class="fragment"><pre class="comment">FONTPROP4PLOTSECTION set up font attributes for section plot
  [FONT,LT,LS] = FONTPROP4PLOTSECTION ()
  the function sets up font attributes for section plot</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li><li><a href="../Plot_SectionStress" class="code" title="Plot_SectionStress (SecData,Post,field,PlotOpt)">Plot_SectionStress</a>	structure SECDATA supplies the section property data;</li><li><a href="../Plot_SectionStressA" class="code" title="Plot_SectionStressA (SecData,Post)">Plot_SectionStressA</a>	</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->