
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; LineProp4PlotSection</div>

--------------------------

# `LineProp4PlotSection`


## <a name="_name"></a>Purpose

set up graphic attributes for line elements of section plot


## <a name="_synopsis"></a>Synopsis

`[Line] = LineProp4PlotSection()`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LINEPROP4PLOTSECTION set up graphic attributes for line elements of section plot
  LINE = LINEPROP4PLOTSECTION ()
  the function sets up graphic attributes for line elements of section plot</pre>
<!-- <div class="fragment"><pre class="comment">LINEPROP4PLOTSECTION set up graphic attributes for line elements of section plot
  LINE = LINEPROP4PLOTSECTION ()
  the function sets up graphic attributes for line elements of section plot</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_Mesh4Circ" class="code" title="Plot_Mesh4Circ (SecData)">Plot_Mesh4Circ</a>	plots mesh for a circular disc or annulus in current window</li><li><a href="../Plot_Mesh4MultRectShape" class="code" title="Plot_Mesh4MultRectShape (SecData)">Plot_Mesh4MultRectShape</a>	plot the mesh for section of several rectangular patches</li><li><a href="../Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li><li><a href="../Plot_SectionStressA" class="code" title="Plot_SectionStressA (SecData,Post)">Plot_SectionStressA</a>	</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->