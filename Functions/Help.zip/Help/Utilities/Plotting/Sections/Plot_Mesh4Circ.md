
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; Plot_Mesh4Circ</div>

--------------------------

# `Plot_Mesh4Circ`


## <a name="_name"></a>Purpose

plots mesh for a circular disc or annulus in current window


## <a name="_synopsis"></a>Synopsis

`Plot_Mesh4Circ (SecData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_MESH4CIRC plots mesh for a circular disc or annulus in current window
  PLOT_MESH4CIRC (SECDATA)
  the function plots in the current window the mesh for a circular disk or annulus
  whose properties are defined in data structure SECDATA;
  the function uses the line properties #12 in the line property script LineProp4PlotSection</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_MESH4CIRC plots mesh for a circular disc or annulus in current window
  PLOT_MESH4CIRC (SECDATA)
  the function plots in the current window the mesh for a circular disk or annulus
  whose properties are defined in data structure SECDATA;
  the function uses the line properties #12 in the line property script LineProp4PlotSection</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../LineProp4PlotSection" class="code" title="[Line] = LineProp4PlotSection()">LineProp4PlotSection</a>	set up graphic attributes for line elements of section plot</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_MPMesh4Circ" class="code" title="[R1,R2,thfib,dth] = Create_MPMesh4Circ (Ri,Ro,nrfib,nthfib,MeshOpt)">Create_MPMesh4Circ</a>	generate the mesh for a circular disc or annulus</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->