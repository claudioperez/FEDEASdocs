
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; Plot_Mesh4MultRectShape</div>

--------------------------

# `Plot_Mesh4MultRectShape`


## <a name="_name"></a>Purpose

plot the mesh for section of several rectangular patches


## <a name="_synopsis"></a>Synopsis

`Plot_Mesh4MultRectShape (SecData)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_MESH4MULTRECTSHAPE plot the mesh for section of several rectangular patches
  PLOT_MESH4MULTRECTSHAPE (SECDATA)
  the function plots the mesh for the cross section of several rectangular patches,
  whose properties are defined in data structure SECDATA;
  the function uses the line properties #12 in the line property script LineProp4PlotSection</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_MESH4MULTRECTSHAPE plot the mesh for section of several rectangular patches
  PLOT_MESH4MULTRECTSHAPE (SECDATA)
  the function plots the mesh for the cross section of several rectangular patches,
  whose properties are defined in data structure SECDATA;
  the function uses the line properties #12 in the line property script LineProp4PlotSection</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../LineProp4PlotSection" class="code" title="[Line] = LineProp4PlotSection()">LineProp4PlotSection</a>	set up graphic attributes for line elements of section plot</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_BoxOutline" class="code" title="[Outline,A,sy,sz] = Create_BoxOutline (Data)">Create_BoxOutline</a>	generate geometry outline for box section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_BoxwOvhOutline" class="code" title="[Outline,A,sy,sz] = Create_BoxwOvhOutline (Data)">Create_BoxwOvhOutline</a>	generate geometry outline for box section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_CSecOutline" class="code" title="[Outline,A,sy,sz] = Create_CSecOutline (Data)">Create_CSecOutline</a>	generate geometry outline for C-section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_ISecOutline" class="code" title="[Outline,A,sy,sz] = Create_ISecOutline (Data)">Create_ISecOutline</a>	generate geometry outline for I-section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_LSecOutline" class="code" title="[Outline,A,sy,sz] = Create_LSecOutline (Data)">Create_LSecOutline</a>	generate geometry outline for L-section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_RectOutline" class="code" title="[Outline,A,sy,sz] = Create_RectOutline (Data)">Create_RectOutline</a>	generate geometry outline for rectangular section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_RectwCovOutline" class="code" title="[Outline,A,sy,sz] = Create_RectwCovOutline (Data)">Create_RectwCovOutline</a>	generate geometry outline for rectangular section with cover</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_SSecOutline" class="code" title="[Outline,A,sy,sz] = Create_SSecOutline (Data)">Create_SSecOutline</a>	generate geometry outline for C-section</li><li><a href="../../../../Utilities/PreProcessing/Sections/Create_TSecOutline" class="code" title="[Outline,A,sy,sz] = Create_TSecOutline (Data)">Create_TSecOutline</a>	generate geometry outline for T-section</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->