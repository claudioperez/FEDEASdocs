
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; Plot_NewSectionStress</div>

--------------------------

# `Plot_NewSectionStress`


## <a name="_name"></a>Purpose




## <a name="_synopsis"></a>Synopsis

`Plot_NewSectionStress (SecData,sig)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"></pre>
<!-- <div class="fragment"><pre class="comment"></pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_SectionGeometry" class="code" title="Plot_SectionGeometry (SecData,PlotOpt)">Plot_SectionGeometry</a>	plots cross section geometry in current window</li><li><a href="../../../../Utilities/PreProcessing/Sections/MP1dInt4Circ" class="code" title="[yfib,wfib] = MP1dInt4Circ (R,nrfib)">MP1dInt4Circ</a>	integration points and weights for 1d-midpoint rule of circular disc or annulus</li><li><a href="../../../../Utilities/PreProcessing/Sections/MP2dInt4Circ" class="code" title="[yfib,zfib,wfib] = MP2dInt4Circ (R,nrfib,nthfib,MeshOpt)">MP2dInt4Circ</a>	integration points and weights for 2d-midpoint rule of circular disc or annulus</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->