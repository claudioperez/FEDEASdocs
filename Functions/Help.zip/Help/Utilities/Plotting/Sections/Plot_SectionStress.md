
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; Plot_SectionStress</div>

--------------------------

# `Plot_SectionStress`


## <a name="_name"></a>Purpose

structure SECDATA supplies the section property data;


## <a name="_synopsis"></a>Synopsis

`Plot_SectionStress (SecData,Post,field,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">  data structure SECDATA supplies the section property data;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  PLOTOPT is a data structure with the options for the plot, with the fields:

    geomunit       = unit for plotting geometry (char)
    shape          = plot the shape of section if it is 'on', otherwise if it is 'off'
    reinforcements = plot the reinforcements if it is 'on', otherwise if it is 'off'
    fibers         = plot the fibers of section discretization if it is 'on', otherwise if it is 'off'
    title          = title for the plot (char)</pre>
<!-- <div class="fragment"><pre class="comment">  data structure SECDATA supplies the section property data;
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  PLOTOPT is a data structure with the options for the plot, with the fields:

    geomunit       = unit for plotting geometry (char)
    shape          = plot the shape of section if it is 'on', otherwise if it is 'off'
    reinforcements = plot the reinforcements if it is 'on', otherwise if it is 'off'
    fibers         = plot the fibers of section discretization if it is 'on', otherwise if it is 'off'
    title          = title for the plot (char)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../FontProp4PlotSection" class="code" title="[Font,lt,ls] = FontProp4PlotSection()">FontProp4PlotSection</a>	set up font attributes for section plot</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->