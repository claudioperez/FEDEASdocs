
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Sections</a> &gt; Plot_SectionStressA</div>

--------------------------

# `Plot_SectionStressA`


## <a name="_name"></a>Purpose




## <a name="_synopsis"></a>Synopsis

`Plot_SectionStressA (SecData,Post)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment"></pre>
<!-- <div class="fragment"><pre class="comment"></pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../FontProp4PlotSection" class="code" title="[Font,lt,ls] = FontProp4PlotSection()">FontProp4PlotSection</a>	set up font attributes for section plot</li><li><a href="../LineProp4PlotSection" class="code" title="[Line] = LineProp4PlotSection()">LineProp4PlotSection</a>	set up graphic attributes for line elements of section plot</li><li><a href="../../../../Utilities/PreProcessing/Sections/Rectangle2Fiber" class="code" title="[yfib,zfib,wfib] = Rectangle2Fiber (patcoor,IntTyp,nyfib,nzfib)">Rectangle2Fiber</a>	integration points and weights for 2d-integration of a rectangle</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->