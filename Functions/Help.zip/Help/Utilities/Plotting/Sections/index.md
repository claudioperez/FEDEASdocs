---
title: Sections
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Sections`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Sections

<table>
<tr><td><a href="FontProp4PlotSection">FontProp4PlotSection</a></td><td>set up font attributes for section plot </td></tr><tr><td><a href="LineProp4PlotSection">LineProp4PlotSection</a></td><td>set up graphic attributes for line elements of section plot </td></tr><tr><td><a href="Plot_3dYieldSurface">Plot_3dYieldSurface</a></td><td>plot polynomial function for 3d yield surface </td></tr><tr><td><a href="Plot_Mesh4Circ">Plot_Mesh4Circ</a></td><td>plots mesh for a circular disc or annulus in current window </td></tr><tr><td><a href="Plot_Mesh4MultRectShape">Plot_Mesh4MultRectShape</a></td><td>plot the mesh for section of several rectangular patches </td></tr><tr><td><a href="Plot_NewSectionStress">Plot_NewSectionStress</a></td><td> </td></tr><tr><td><a href="Plot_SectionGeometry">Plot_SectionGeometry</a></td><td>plots cross section geometry in current window </td></tr><tr><td><a href="Plot_SectionStress">Plot_SectionStress</a></td><td>structure SECDATA supplies the section property data; </td></tr><tr><td><a href="Plot_SectionStressA">Plot_SectionStressA</a></td><td> </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../../matlab_logo.png" alt="icon name" class="icon">Auxiliary</li><li><img src="../../../matlab_logo.png" alt="icon name" class="icon">Development</li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->