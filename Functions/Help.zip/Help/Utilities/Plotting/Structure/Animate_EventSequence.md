
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Animate_EventSequence</div>

--------------------------

# `Animate_EventSequence`


## <a name="_name"></a>Purpose

generate plot sequence with location of plastic hinges for each event


## <a name="_synopsis"></a>Synopsis

`Animate_EventSequence (Model,ElemData,Ufh,Qh,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ANIMATE_EVENTSEQUENCE generate plot sequence with location of plastic hinges for each event 
  ANIMATE_EVENTSEQUENCE (MODEL,ELEMDATA,UFH,QH,PLOTOPT)
  the function generates a plot sequence of the deformed structural model with the plastic hinge
  locations at each event, thus animating the plastic hinge formation sequence;
  the free global dof displacement history is provided in array UFH, with one column for each event,
  and the corresponding basic force history in array QH, with one column for each event;
  the data structure MODEL contains information about the structural model, while
  ELEMDATA contains element property information; there are two options for supplying
  the plastic capacities of the structural elements in ELEMDATA:
  (a) as fields Np for axial and Mp for flexural of the cell array ELEMDATA 
  (a) as a column vector
  PLOTOPT is a data structure for controlling the plastic hinge display
  with the following fields:
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    LnClr: line color for deformed shape (default='r' for red)
    CdClr: line color for element chord (default='k' for black)
    PlJnt: switch for plotting joint offsets (default='yes')
    PlCrd: display element chords with deformed shape (default='no')
    NodSF: factor for relative size of node symbol (default=1)  
    tol:   relative tolerance for plastic capacity check;
           absolute tolerance for plastic rotation check
    Inter: switch for interactive animation (yes, default) or video generation (no)
    MovieFN: video file name (default=Movie)
    PauseDur: pause duration for screen animation in sec (default=0)
    FrameRate: frames per second for video recording (default=30)
    Nsub :  number of interpolated intermediate plots between events for movie
    FctX : factor for X-axis limits  (default = 1.2)
    FctY : factor for Y-axis limits  (default = 1.1)</pre>
<!-- <div class="fragment"><pre class="comment">ANIMATE_EVENTSEQUENCE generate plot sequence with location of plastic hinges for each event 
  ANIMATE_EVENTSEQUENCE (MODEL,ELEMDATA,UFH,QH,PLOTOPT)
  the function generates a plot sequence of the deformed structural model with the plastic hinge
  locations at each event, thus animating the plastic hinge formation sequence;
  the free global dof displacement history is provided in array UFH, with one column for each event,
  and the corresponding basic force history in array QH, with one column for each event;
  the data structure MODEL contains information about the structural model, while
  ELEMDATA contains element property information; there are two options for supplying
  the plastic capacities of the structural elements in ELEMDATA:
  (a) as fields Np for axial and Mp for flexural of the cell array ELEMDATA 
  (a) as a column vector
  PLOTOPT is a data structure for controlling the plastic hinge display
  with the following fields:
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    LnClr: line color for deformed shape (default='r' for red)
    CdClr: line color for element chord (default='k' for black)
    PlJnt: switch for plotting joint offsets (default='yes')
    PlCrd: display element chords with deformed shape (default='no')
    NodSF: factor for relative size of node symbol (default=1)  
    tol:   relative tolerance for plastic capacity check;
           absolute tolerance for plastic rotation check
    Inter: switch for interactive animation (yes, default) or video generation (no)
    MovieFN: video file name (default=Movie)
    PauseDur: pause duration for screen animation in sec (default=0)
    FrameRate: frames per second for video recording (default=30)
    Nsub :  number of interpolated intermediate plots between events for movie
    FctX : factor for X-axis limits  (default = 1.2)
    FctY : factor for Y-axis limits  (default = 1.1)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../../../../Utilities/General/D_index" class="code" title="ied = D_index (Model)">D_index</a>	cell array of indices into structure arrays for non-zero element deformations</li><li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->