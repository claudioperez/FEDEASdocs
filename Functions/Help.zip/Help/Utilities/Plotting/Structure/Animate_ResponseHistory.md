
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Animate_ResponseHistory</div>

--------------------------

# `Animate_ResponseHistory`


## <a name="_name"></a>Purpose

interactive or recorded animation of response history


## <a name="_synopsis"></a>Synopsis

`Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ANIMATE_RESPONSEHISTORY interactive or recorded animation of response history  
  ANIMATE_RESPONSEHISTORY (MODEL,ELEMDATA,POST,PLOTOPT) 
  the function animates either interactively or in a recorded video file
  the response history of the model in the data structure MODEL
  with the element properties in the cell array ELEMDATA; 
  the data structure POST contains the response history of the model; it can be either
  a data structure array of size equal to the number of response states with field U for
  the corresponding displacements or an array of size NDOF x NTIME,
  where NDOF is the number of model DOFs and NTIME the number of response states;
  the display of plastic hinges is only possible in the former case, since it requires
  information about the element deformations in Post(step).Elem{el};
  PLOTOPT is a data structure for controlling the response and plastic hinge display
  with the following fields:
    MAGF:  magnification factor for deformed shape (default = 10)
    EList: list of elements in animation (default = 1:Model.ne)
    NodSF: factor for relative size of node symbol (default = 1)  
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of plastic hinge symbol from element end (default = 1)
    ShwPH: switch for displaying active and closed plastic hinges (default = 'no')
    LnClr: line color for deformed shape (default = 'r' for red)
    LnWth: line width for deformed shape (default = 2)
    PlJnt: switch for plotting joint offsets (default = 'yes')
    PlCrd: display element chords with deformed shape (default = 'no')
    Inter: switch for interactive animation (yes) or video generation (default = 'no')
    MovieFN:   video file name (default = 'Movie')
    PauseDur:  pause duration for screen animation in sec (default = 0)
    FrameRate: frames per second for video recording (default = 30)
    Nskip: number of response states to skip (default = 1, i.e. no skipping)
    Nstrt: time step at start of animation   (default = 2, since 1 is initial state)
    Npend: time step at end   of animation   (default = end of data)
    ShowT: show time counter on screen (default = 'no')
    FntSz: font size of time counter   (default = 14)
    FctX : factor for X-axis limits    (default = 1.2)
    FctY : factor for Y-axis limits    (default = 1.1)</pre>
<!-- <div class="fragment"><pre class="comment">ANIMATE_RESPONSEHISTORY interactive or recorded animation of response history  
  ANIMATE_RESPONSEHISTORY (MODEL,ELEMDATA,POST,PLOTOPT) 
  the function animates either interactively or in a recorded video file
  the response history of the model in the data structure MODEL
  with the element properties in the cell array ELEMDATA; 
  the data structure POST contains the response history of the model; it can be either
  a data structure array of size equal to the number of response states with field U for
  the corresponding displacements or an array of size NDOF x NTIME,
  where NDOF is the number of model DOFs and NTIME the number of response states;
  the display of plastic hinges is only possible in the former case, since it requires
  information about the element deformations in Post(step).Elem{el};
  PLOTOPT is a data structure for controlling the response and plastic hinge display
  with the following fields:
    MAGF:  magnification factor for deformed shape (default = 10)
    EList: list of elements in animation (default = 1:Model.ne)
    NodSF: factor for relative size of node symbol (default = 1)  
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of plastic hinge symbol from element end (default = 1)
    ShwPH: switch for displaying active and closed plastic hinges (default = 'no')
    LnClr: line color for deformed shape (default = 'r' for red)
    LnWth: line width for deformed shape (default = 2)
    PlJnt: switch for plotting joint offsets (default = 'yes')
    PlCrd: display element chords with deformed shape (default = 'no')
    Inter: switch for interactive animation (yes) or video generation (default = 'no')
    MovieFN:   video file name (default = 'Movie')
    PauseDur:  pause duration for screen animation in sec (default = 0)
    FrameRate: frames per second for video recording (default = 30)
    Nskip: number of response states to skip (default = 1, i.e. no skipping)
    Nstrt: time step at start of animation   (default = 2, since 1 is initial state)
    Npend: time step at end   of animation   (default = end of data)
    ShowT: show time counter on screen (default = 'no')
    FntSz: font size of time counter   (default = 14)
    FctX : factor for X-axis limits    (default = 1.2)
    FctY : factor for Y-axis limits    (default = 1.1)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../Plot_OpenPlasticHinges" class="code" title="Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)">Plot_OpenPlasticHinges</a>	display plastic hinge locations in original or deformed configuration</li><li><a href="../Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li><li><a href="../../../../Utilities/PostProcessing/Add_OpenPHIndx2Post" class="code" title="Post = Add_OpenPHIndx2Post (Model,Post)">Add_OpenPHIndx2Post</a>	add index to POST for open plastic hinges in elements</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->