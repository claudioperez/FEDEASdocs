
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Get_HngPos4DefoElem</div>

--------------------------

# `Get_HngPos4DefoElem`


## <a name="_name"></a>Purpose

determine axial and flexural hinge position for deformed element


## <a name="_synopsis"></a>Synopsis

`[AxHngCoor,FlHngCoor] = Get_HngPos4DefoElem (XYiod,XYjod,xyd,HngOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_HNGPOS4DEFOELEM determine axial and flexural hinge position for deformed element
  [AXHNGCOOR,FLHNGCOOR] = GET_HNGPOS4DEFOELEM(XYIOD,XYJOD,XYD,HNGOPT)
  the function determines the axial hinge coordinates AXHNGCOOR and the
  flexural hinge coordinates FLHNGCOOR for a deformed truss or frame element
  from the end node coordinates XYIOD and XYJOD of the deformed configuration
  and the local deformed coordinates XYD of the deformed shape;
  the data structure HNGOPT has the fields HngSz for the hinge size and
  HngOf for the offset of the hinge location from the element end</pre>
<!-- <div class="fragment"><pre class="comment">GET_HNGPOS4DEFOELEM determine axial and flexural hinge position for deformed element
  [AXHNGCOOR,FLHNGCOOR] = GET_HNGPOS4DEFOELEM(XYIOD,XYJOD,XYD,HNGOPT)
  the function determines the axial hinge coordinates AXHNGCOOR and the
  flexural hinge coordinates FLHNGCOOR for a deformed truss or frame element
  from the end node coordinates XYIOD and XYJOD of the deformed configuration
  and the local deformed coordinates XYD of the deformed shape;
  the data structure HNGOPT has the fields HngSz for the hinge size and
  HngOf for the offset of the hinge location from the element end</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->