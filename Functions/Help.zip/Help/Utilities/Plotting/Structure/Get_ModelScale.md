
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Get_ModelScale</div>

--------------------------

# `Get_ModelScale`


## <a name="_name"></a>Purpose

determines maximum and minimum element length in Model


## <a name="_synopsis"></a>Synopsis

`[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_MODELSCALE determines maximum and minimum element length in Model
  [MODSC,MAXL,MINL] = GET_MODELSCALE(MODEL,RATIO)
  the function determines a critical scale for the structural model
  in data structure MODEL from the maximum distance MAXL and
  the minimum distance MINL between nodes i and j of line elements;
  the maximum distance MAXL is divided by RATIO (default = 1.5-0.5*MINL/MAXL);
  depending on the value of RATIO the model scale is equal
  to the largest (RATIO&lt;MAXL/MINL) or smallest distance (RATIO&gt;MAXL/MINL)</pre>
<!-- <div class="fragment"><pre class="comment">GET_MODELSCALE determines maximum and minimum element length in Model
  [MODSC,MAXL,MINL] = GET_MODELSCALE(MODEL,RATIO)
  the function determines a critical scale for the structural model
  in data structure MODEL from the maximum distance MAXL and
  the minimum distance MINL between nodes i and j of line elements;
  the maximum distance MAXL is divided by RATIO (default = 1.5-0.5*MINL/MAXL);
  depending on the value of RATIO the model scale is equal
  to the largest (RATIO&lt;MAXL/MINL) or smallest distance (RATIO&gt;MAXL/MINL)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Utilities/Plotting/Elements/Get_IPVarDistr" class="code" title="Line = Get_IPVarDistr (Model,ElemData,Post,Component,ElemList,UserScale)">Get_IPVarDistr</a>	plots distribution of integration point variables of elements with sections</li><li><a href="../../../../Utilities/Plotting/Elements/Plot_2dCurvDistr" class="code" title="Plot_2dCurvDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dCurvDistr</a>	plot curvature distribution of 2d linear elastic frame elements</li><li><a href="../../../../Utilities/Plotting/Elements/Plot_2dMomntDistr" class="code" title="Plot_2dMomntDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dMomntDistr</a>	plots moment distribution for 2d frame elements in current window</li><li><a href="../../../../Utilities/Plotting/Elements/Plot_AxialForces" class="code" title="Plot_AxialForces (Model,Post,ElemList,UserScale)">Plot_AxialForces</a>	plot axial forces in current window</li><li><a href="../../../../Utilities/Plotting/Elements/Plot_IPVarDistr" class="code" title="LineH = Plot_IPVarDistr (Model,ElemData,Post,Component,ElemList,UserScale)">Plot_IPVarDistr</a>	plots distribution of integration point variables of elements with sections</li><li><a href="../Label_Model" class="code" title="Label_Model (Model,LblOpt)">Label_Model</a>	displays element and node numbers and global axes in the current window</li><li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../Plot_ElemLoading" class="code" title="Plot_ElemLoading (Model,ElemData,PlotOpt)">Plot_ElemLoading</a>	display element loading in current window</li><li><a href="../Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li><li><a href="../Plot_NodalForces" class="code" title="Plot_NodalForces (Model,Loading,PlotOpt)">Plot_NodalForces</a>	display nodal forces in current window</li><li><a href="../Plot_OpenPlasticHinges" class="code" title="Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)">Plot_OpenPlasticHinges</a>	display plastic hinge locations in original or deformed configuration</li><li><a href="../Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li><li><a href="../Plot_Releases" class="code" title="Plot_Releases (Model,ElemData,U,PlotOpt)">Plot_Releases</a>	display element releases in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->