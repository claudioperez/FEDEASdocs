
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Label_Model</div>

--------------------------

# `Label_Model`


## <a name="_name"></a>Purpose

displays element and node numbers and global axes in the current window


## <a name="_synopsis"></a>Synopsis

`Label_Model (Model,LblOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">LABEL_MODEL displays element and node numbers and global axes in the current window   
  LABEL_MODEL (MODEL,LBLOPT)
  the function displays in the current window labels for nodes and elements,
  and the global coordinate axes;
  LBLOPT is an optional data structure controlling the display;
  in its absense the function plots all items with default values;
  LBLOPT has the following fields (all optional)
    Item : character variable with values 'node','elem', 'axes' (default='all')
    FntSF: font magnification factor (default = 1)
    AxsSF: axis arrow length magnification factor (default = 1)
    LOfSF: node and element label offset magnification factor (default = 1)
    NList: list of nodes    to label (default all nodes    in the model)
    EList: list of elements to label (default all elements in the model)</pre>
<!-- <div class="fragment"><pre class="comment">LABEL_MODEL displays element and node numbers and global axes in the current window   
  LABEL_MODEL (MODEL,LBLOPT)
  the function displays in the current window labels for nodes and elements,
  and the global coordinate axes;
  LBLOPT is an optional data structure controlling the display;
  in its absense the function plots all items with default values;
  LBLOPT has the following fields (all optional)
    Item : character variable with values 'node','elem', 'axes' (default='all')
    FntSF: font magnification factor (default = 1)
    AxsSF: axis arrow length magnification factor (default = 1)
    LOfSF: node and element label offset magnification factor (default = 1)
    NList: list of nodes    to label (default all nodes    in the model)
    EList: list of elements to label (default all elements in the model)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Utilities/Plotting/Draw_Arrow" class="code" title="varargout = Draw_Arrow (Astr,Aend,Aln,PlotOpt)">Draw_Arrow</a>	draws 2d or 3d arrow</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->