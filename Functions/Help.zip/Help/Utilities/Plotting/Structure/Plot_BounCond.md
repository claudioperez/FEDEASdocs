
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_BounCond</div>

--------------------------

# `Plot_BounCond`


## <a name="_name"></a>Purpose

plots symbols for boundary conditions of structural model


## <a name="_synopsis"></a>Synopsis

`Plot_BounCond (XYZ,BOUN,BsClr,BsSz)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_BOUNCOND plots symbols for boundary conditions of structural model
  PLOT_BOUNCOND (XYZ,BOUN,BSSZ)
  the function plots symbols for the boundary conditions of the structural
  model for the node coordinates in the array XYZ (undeformed or deformed
  configuration and the boundary conditions in the array BOUN;
  BSSZ gives the size of the node and boundary symbol</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_BOUNCOND plots symbols for boundary conditions of structural model
  PLOT_BOUNCOND (XYZ,BOUN,BSSZ)
  the function plots symbols for the boundary conditions of the structural
  model for the node coordinates in the array XYZ (undeformed or deformed
  configuration and the boundary conditions in the array BOUN;
  BSSZ gives the size of the node and boundary symbol</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li><li><a href="../Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->