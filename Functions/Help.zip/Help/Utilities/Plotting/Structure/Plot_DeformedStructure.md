
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_DeformedStructure</div>

--------------------------

# `Plot_DeformedStructure`


## <a name="_name"></a>Purpose

plot deformed shape of the structure


## <a name="_synopsis"></a>Synopsis

`LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_DEFORMEDSTRUCTURE plot deformed shape of the structure
  PLOT_DEFORMEDSTRUCTURE (MODEL,ELEMDATA,U,POST,PLOTOPT)
  the function plots the deformed shape of the structural model in data structure MODEL
  based on the current displacements in vector U and the element deformations;
  the cell array ELEMDATA contains information about element properties and loading;
  POST is either the vector of the element deformations Veps, or
  a cell array with the element deformations in subfield ve of field Elem; this information
  is optional; if not given, the function assumes that all element ends are continuous; 
  PLOTOPT is a data structure for plotting options with the following fields:
    MAGF : magnification factor for deformed shape (default=10)
    EList: list of elements to include in deformed shape (default all elements)
    LnStl: line style for deformed shape (default = '-', i.e. solid line)
    LnWth: line thickness for deformed shape (default = 2)  
    LnClr: color for deformed shape (default = 'r', i.e. red)
    PlJnt: switch for plotting joint offsets (default='yes')
    PlCrd: switch for plotting element chord (default='no')
    PlRel: switch for plotting element releases (defaul='yes')
    HngSF: scale factor for size of release symbol (default = 1)
    HOfSF: scale factor for offset of flexural hinge symbol from element end (default = 1)  
    PlBnd: switch for displaying boundary symbols (default='yes')
    BsClr: color for boundary nodes and symbols (default=[0.6 0 0.6])
    NodSF: scale factor for size of boundary symbol (default = 1)
    AHClr: display color of    axial hinges or releases     (default = light gray)
    FHClr: display color of flexural hinges or releases     (default = white)
    ModSF: switch for adjusting scale factor relative to element size (default = 'yes')</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_DEFORMEDSTRUCTURE plot deformed shape of the structure
  PLOT_DEFORMEDSTRUCTURE (MODEL,ELEMDATA,U,POST,PLOTOPT)
  the function plots the deformed shape of the structural model in data structure MODEL
  based on the current displacements in vector U and the element deformations;
  the cell array ELEMDATA contains information about element properties and loading;
  POST is either the vector of the element deformations Veps, or
  a cell array with the element deformations in subfield ve of field Elem; this information
  is optional; if not given, the function assumes that all element ends are continuous; 
  PLOTOPT is a data structure for plotting options with the following fields:
    MAGF : magnification factor for deformed shape (default=10)
    EList: list of elements to include in deformed shape (default all elements)
    LnStl: line style for deformed shape (default = '-', i.e. solid line)
    LnWth: line thickness for deformed shape (default = 2)  
    LnClr: color for deformed shape (default = 'r', i.e. red)
    PlJnt: switch for plotting joint offsets (default='yes')
    PlCrd: switch for plotting element chord (default='no')
    PlRel: switch for plotting element releases (defaul='yes')
    HngSF: scale factor for size of release symbol (default = 1)
    HOfSF: scale factor for offset of flexural hinge symbol from element end (default = 1)  
    PlBnd: switch for displaying boundary symbols (default='yes')
    BsClr: color for boundary nodes and symbols (default=[0.6 0 0.6])
    NodSF: scale factor for size of boundary symbol (default = 1)
    AHClr: display color of    axial hinges or releases     (default = light gray)
    FHClr: display color of flexural hinges or releases     (default = white)
    ModSF: switch for adjusting scale factor relative to element size (default = 'yes')</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../../../Element_Library/Frame_Elements/DeformShape3dFrm" class="code" title="[XYZd,xyzd] = DeformShape3dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape3dFrm</a>	deformed shape of linear elastic, uniform, prismatic 3d frame element</li><li><a href="../../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li><li><a href="../Get_HngPos4DefoElem" class="code" title="[AxHngCoor,FlHngCoor] = Get_HngPos4DefoElem (XYiod,XYjod,xyd,HngOpt)">Get_HngPos4DefoElem</a>	determine axial and flexural hinge position for deformed element</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li><li><a href="../Plot_BounCond" class="code" title="Plot_BounCond (XYZ,BOUN,BsClr,BsSz)">Plot_BounCond</a>	plots symbols for boundary conditions of structural model</li><li><a href="../Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Animate_EventSequence" class="code" title="Animate_EventSequence (Model,ElemData,Ufh,Qh,PlotOpt)">Animate_EventSequence</a>	generate plot sequence with location of plastic hinges for each event</li><li><a href="../Animate_ResponseHistory" class="code" title="Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)">Animate_ResponseHistory</a>	interactive or recorded animation of response history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->