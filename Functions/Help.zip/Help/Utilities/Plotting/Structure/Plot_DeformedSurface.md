
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_DeformedSurface</div>

--------------------------

# `Plot_DeformedSurface`


## <a name="_name"></a>Purpose

plots the deformed surface of 3d plate and shell models


## <a name="_synopsis"></a>Synopsis

`Plot_DeformedSurface (Model,U,MPlOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_DEFORMEDSURFACE plots the deformed surface of 3d plate and shell models
  PLOT_DEFORMEDSURFACE (MODEL,U,MPLOPT)
  the function plots in the current window the deformed surface of 3d finite element models
  with plate and shell elements under the global dof displacements in vector U
  MPLOPT is an optional data structure which consists of a single field the
  magnification factor MAGF for the deformed geometry (default=10)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_DEFORMEDSURFACE plots the deformed surface of 3d plate and shell models
  PLOT_DEFORMEDSURFACE (MODEL,U,MPLOPT)
  the function plots in the current window the deformed surface of 3d finite element models
  with plate and shell elements under the global dof displacements in vector U
  MPLOPT is an optional data structure which consists of a single field the
  magnification factor MAGF for the deformed geometry (default=10)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../../Utilities/Plotting/elNodCON" class="code" title="indx = elNodCON (ndm,nodix,ElemName)">elNodCON</a>	generates a connectivity index array for each type of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->