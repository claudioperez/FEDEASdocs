
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_ElemLoading</div>

--------------------------

# `Plot_ElemLoading`


## <a name="_name"></a>Purpose

display element loading in current window


## <a name="_synopsis"></a>Synopsis

`Plot_ElemLoading (Model,ElemData,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_ELEMLOADING display element loading in current window
  PLOT_ELEMLOADING (MODEL,ELEMDATA,PLOTOPT)
  the function displays in the current window the distributed element loading
  and the initial deformations in ELEMDATA for the structural model in data structure MODEL;
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  PLOTOPT has the following fields:
    FrcSF: scale factor for shaft of nodal force arrow (default = 1)
    TipSF: scale factor for nodal force arrow tip
    ArWth: width of nodal force arrow shaft (default=3)
    ArClr: color for nodal force arrow shaft and tip (default='r')
    FntSF: scale factor for font size of force label</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_ELEMLOADING display element loading in current window
  PLOT_ELEMLOADING (MODEL,ELEMDATA,PLOTOPT)
  the function displays in the current window the distributed element loading
  and the initial deformations in ELEMDATA for the structural model in data structure MODEL;
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  PLOTOPT has the following fields:
    FrcSF: scale factor for shaft of nodal force arrow (default = 1)
    TipSF: scale factor for nodal force arrow tip
    ArWth: width of nodal force arrow shaft (default=3)
    ArClr: color for nodal force arrow shaft and tip (default='r')
    FntSF: scale factor for font size of force label</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Utilities/Plotting/Draw_Arrow" class="code" title="varargout = Draw_Arrow (Astr,Aend,Aln,PlotOpt)">Draw_Arrow</a>	draws 2d or 3d arrow</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->