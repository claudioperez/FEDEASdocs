
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_Hinge4Elem</div>

--------------------------

# `Plot_Hinge4Elem`


## <a name="_name"></a>Purpose

plot releases or plastic hinges for truss or frame element


## <a name="_synopsis"></a>Synopsis

`Plot_Hinge4Elem (nq,HngId,AxHngCoor,FlHngCoor,Colors)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_HINGE4ELEM plot releases or plastic hinges for truss or frame element
  PLOT_HINGE4ELEM (NQ,HNGID,AXHNGCOOR,FLHNGCOOR,PLOTOPT)
  the function plots the releases or plastic hinges for a truss or frame element
  NQ is the number of basic forces for the element
  HNGID is the index vector for the location of releases/plastic hinges
  AXHNGCOOR are the coordinates for the axial hinge location
  FLHNGCOOR are the coordinates for the flexural hinge location
  COLORS is a data structure with the release/plastic hinge colors in fields
        .AHCrl color for axial release or plastic hinge
        .FHCrl color for flexural release or plastic hinge without N-M interaction
        .CHCrl color for flexural release or plastic hinge with    N-M interaction</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_HINGE4ELEM plot releases or plastic hinges for truss or frame element
  PLOT_HINGE4ELEM (NQ,HNGID,AXHNGCOOR,FLHNGCOOR,PLOTOPT)
  the function plots the releases or plastic hinges for a truss or frame element
  NQ is the number of basic forces for the element
  HNGID is the index vector for the location of releases/plastic hinges
  AXHNGCOOR are the coordinates for the axial hinge location
  FLHNGCOOR are the coordinates for the flexural hinge location
  COLORS is a data structure with the release/plastic hinge colors in fields
        .AHCrl color for axial release or plastic hinge
        .FHCrl color for flexural release or plastic hinge without N-M interaction
        .CHCrl color for flexural release or plastic hinge with    N-M interaction</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->