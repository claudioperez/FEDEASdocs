
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_Model</div>

--------------------------

# `Plot_Model`


## <a name="_name"></a>Purpose

plots the original or deformed geometry of the structural model


## <a name="_synopsis"></a>Synopsis

`Plot_Model (Model,U,MPlOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_MODEL plots the original or deformed geometry of the structural model
  PLOT_MODEL (MODEL,U,MPLOPT)
  the function plots in the current window the original or deformed geometry
  of the structural model in the data structure MODEL depending
  on the presence of the global displacement vector U in the argument list;
  MPLOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  MPLOPT has the following fields:
    MAGF : magnification factor for deformed wireframe (default=10)
    NodSF: scale factor for size of node symbol (default=1)
    LnStl: line style (default = '-' for undeformed, '-.' for deformed configuration)
    LnWth: line width (default = 2)
    LnClr: wireframe and node color (default = 'b' for undeformed,
                                               'k' for deformed configuration)
    PlNod: switch for displaying node symbols (default ='no')
    PlBnd: switch for displaying boundary symbols (default='no')
    BsClr: color for boundary nodes and symbols (default=[0.6 0 0.6])
    PlJnt: switch for plotting joint offsets  (default='yes')
    ModSF: switch for adjusting scale factor relative to element size (default = 'yes')</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_MODEL plots the original or deformed geometry of the structural model
  PLOT_MODEL (MODEL,U,MPLOPT)
  the function plots in the current window the original or deformed geometry
  of the structural model in the data structure MODEL depending
  on the presence of the global displacement vector U in the argument list;
  MPLOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  MPLOPT has the following fields:
    MAGF : magnification factor for deformed wireframe (default=10)
    NodSF: scale factor for size of node symbol (default=1)
    LnStl: line style (default = '-' for undeformed, '-.' for deformed configuration)
    LnWth: line width (default = 2)
    LnClr: wireframe and node color (default = 'b' for undeformed,
                                               'k' for deformed configuration)
    PlNod: switch for displaying node symbols (default ='no')
    PlBnd: switch for displaying boundary symbols (default='no')
    BsClr: color for boundary nodes and symbols (default=[0.6 0 0.6])
    PlJnt: switch for plotting joint offsets  (default='yes')
    ModSF: switch for adjusting scale factor relative to element size (default = 'yes')</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li><li><a href="../../../../Utilities/Plotting/Draw_Cube" class="code" title="Draw_Cube (XYZc,Size,Color)">Draw_Cube</a>	draws cube in current window</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li><li><a href="../Plot_BounCond" class="code" title="Plot_BounCond (XYZ,BOUN,BsClr,BsSz)">Plot_BounCond</a>	plots symbols for boundary conditions of structural model</li><li><a href="../../../../Utilities/Plotting/elNodCON" class="code" title="indx = elNodCON (ndm,nodix,ElemName)">elNodCON</a>	generates a connectivity index array for each type of element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Animate_EventSequence" class="code" title="Animate_EventSequence (Model,ElemData,Ufh,Qh,PlotOpt)">Animate_EventSequence</a>	generate plot sequence with location of plastic hinges for each event</li><li><a href="../Animate_ResponseHistory" class="code" title="Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)">Animate_ResponseHistory</a>	interactive or recorded animation of response history</li><li><a href="../Plot_DeformedStructure" class="code" title="LnHndl = Plot_DeformedStructure (Model,ElemData,U,Post,PlotOpt)">Plot_DeformedStructure</a>	plot deformed shape of the structure</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->