
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_OpenPlasticHinges</div>

--------------------------

# `Plot_OpenPlasticHinges`


## <a name="_name"></a>Purpose

display plastic hinge locations in original or deformed configuration


## <a name="_synopsis"></a>Synopsis

`Plot_OpenPlasticHinges (Model,ElemData,Post,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_OPENPLASTICHINGES display plastic hinge locations in original or deformed configuration
  PLOT_OPENPLASTICHINGES (MODEL,ELEMDATA,POST,PLOTOPT)
  the function displays in the current window the open plastic hinge locations;
  the data structure MODEL contains information about the structural model,
  with element property information provided in cell array ELEMDATA;
  the data structure POST contains all recorded structural response variables for one step
  PLOTOPT is a data structure for controlling the plastic hinge display
  with the following fields:
    EList: list of elements for which plastic hinges are displayed (default all elements)
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    FHClr: color for flexural hinges
    CHClr: color for column hinges with N-M interaction
    AHClr: color for axial hinges in truss elements</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_OPENPLASTICHINGES display plastic hinge locations in original or deformed configuration
  PLOT_OPENPLASTICHINGES (MODEL,ELEMDATA,POST,PLOTOPT)
  the function displays in the current window the open plastic hinge locations;
  the data structure MODEL contains information about the structural model,
  with element property information provided in cell array ELEMDATA;
  the data structure POST contains all recorded structural response variables for one step
  PLOTOPT is a data structure for controlling the plastic hinge display
  with the following fields:
    EList: list of elements for which plastic hinges are displayed (default all elements)
    HngSF: scale factor for size of plastic hinge symbol (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    FHClr: color for flexural hinges
    CHClr: color for column hinges with N-M interaction
    AHClr: color for axial hinges in truss elements</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../../../Element_Library/Frame_Elements/DeformShape2dFrm_wDispIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wDispIntp (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm_wDispIntp</a>	deformed shape of 2d frame element with cubic polynomials</li><li><a href="../../../../Element_Library/Frame_Elements/DistrInelastic/DeformShape2dFrm_wCurvIntp" class="code" title="[XYd,xyd] = DeformShape2dFrm_wCurvIntp (xyz,ElemData,u,EPost,MAGF,nsub)">DeformShape2dFrm_wCurvIntp</a>	deformed shape of 2d frame element from curvatures</li><li><a href="../../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Animate_ResponseHistory" class="code" title="Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)">Animate_ResponseHistory</a>	interactive or recorded animation of response history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->