
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_PlasticHinges</div>

--------------------------

# `Plot_PlasticHinges`


## <a name="_name"></a>Purpose

display plastic hinge locations in current window


## <a name="_synopsis"></a>Synopsis

`Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_PLASTICHINGES display plastic hinge locations in current window
  PLOT_PLASTICHINGES (MODEL,ELEMDATA,U,POST,PLOTOPT)
  the function displays in the current window the plastic hinge locations
  for the elements of the structural model in data structure MODEL (only 2d models for now).
  There are two options for supplying the plastic capacities and basic force values:
      (a) ELEMDATA is a vector of plastic capacities and 
  or, (b) ELEMDATA is a cell array with the plastic capacities in fields Np for the axial,
          and Mp for the flexural capacity.
  In the presence of the global dof displacements U the plastic hinges are displayed
  in the deformed configuration otherwise in the undeformed.
  There are three options for POST:
      (a) POST is the vector of basic forces Q corresponding to case (a) of ELEMDATA 
      (b) POST is the vector of plastic deformation increments DVPL in which case
          ELEMDATA is either empty or a character variable with the N-M interaction option NMOPT;
          NMOPT can be one of three options: 'None' (default), 'Dmnd' or 'AISC';
      (c) POST is a cell array with post-processing information in the fields of POST.ELEM{el}.
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function displays the plastic hinges with default properties;
  PLOTOPT has the following fields:
    EList: list of elements for which plastic hinges are displayed (default all elements)
    HngSF: scale factor for size of plastic hinge symbol                  (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    FHClr: color for flexural hinges                                      (default='r')
    CHClr: color for column hinges with N-M interaction               (default = [1 0.6 0])
    AHClr: color for axial hinges in truss elements                   (default = [1 0.6 0])
    tol:   relative tolerance for plastic capacity check;
           absolute tolerance for plastic rotation check              (default=1e-6)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_PLASTICHINGES display plastic hinge locations in current window
  PLOT_PLASTICHINGES (MODEL,ELEMDATA,U,POST,PLOTOPT)
  the function displays in the current window the plastic hinge locations
  for the elements of the structural model in data structure MODEL (only 2d models for now).
  There are two options for supplying the plastic capacities and basic force values:
      (a) ELEMDATA is a vector of plastic capacities and 
  or, (b) ELEMDATA is a cell array with the plastic capacities in fields Np for the axial,
          and Mp for the flexural capacity.
  In the presence of the global dof displacements U the plastic hinges are displayed
  in the deformed configuration otherwise in the undeformed.
  There are three options for POST:
      (a) POST is the vector of basic forces Q corresponding to case (a) of ELEMDATA 
      (b) POST is the vector of plastic deformation increments DVPL in which case
          ELEMDATA is either empty or a character variable with the N-M interaction option NMOPT;
          NMOPT can be one of three options: 'None' (default), 'Dmnd' or 'AISC';
      (c) POST is a cell array with post-processing information in the fields of POST.ELEM{el}.
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function displays the plastic hinges with default properties;
  PLOTOPT has the following fields:
    EList: list of elements for which plastic hinges are displayed (default all elements)
    HngSF: scale factor for size of plastic hinge symbol                  (default = 1)
    HOfSF: factor for offset of the plastic hinge symbol from element end (default = 1)  
    FHClr: color for flexural hinges                                      (default='r')
    CHClr: color for column hinges with N-M interaction               (default = [1 0.6 0])
    AHClr: color for axial hinges in truss elements                   (default = [1 0.6 0])
    tol:   relative tolerance for plastic capacity check;
           absolute tolerance for plastic rotation check              (default=1e-6)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../Element_Library/Frame_Elements/ConcentrInelastic/Create_PlasticLimitSurface" class="code" title="LimitSurf = Create_PlasticLimitSurface (ElemName,ElemData)">Create_PlasticLimitSurface</a>	pologonal plastic limit surface for truss and 2d frame elements</li><li><a href="../../../../Element_Library/Frame_Elements/DeformShape2dFrm" class="code" title="[XYd,xyd] = DeformShape2dFrm (xyz,ElemData,u,v,MAGF,nsub)">DeformShape2dFrm</a>	deformed shape of linear elastic, uniform, prismatic 2d frame element</li><li><a href="../../../../General/Ac_matrix" class="code" title="[Ac,Acf,ide] = Ac_matrix (Model,ElemData,inddof)">Ac_matrix</a>	function sets up constraint transformation matrix Ac</li><li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../../../../Geometry/TranJnt" class="code" title="aj = TranJnt (JntOff)">TranJnt</a>	sets up transformation matrix for finite size joints</li><li><a href="../../../../Utilities/General/D_index" class="code" title="ied = D_index (Model)">D_index</a>	cell array of indices into structure arrays for non-zero element deformations</li><li><a href="../../../../Utilities/General/H_index" class="code" title="iced = H_index (Model,ElemData)">H_index</a>	cell array of indices into structure arrays for continuous element deformations</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li><li><a href="../Plot_Hinge4Elem" class="code" title="Plot_Hinge4Elem (nq,HngId,AxHngCoor,FlHngCoor,Colors)">Plot_Hinge4Elem</a>	plot releases or plastic hinges for truss or frame element</li><li><a href="../../../../Utilities/PostProcessing/Q2Post" class="code" title="Post = Q2Post (Model,Q)">Q2Post</a>	converts the vector of basic forces Q to cell array Post.Elem{}</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../Animate_EventSequence" class="code" title="Animate_EventSequence (Model,ElemData,Ufh,Qh,PlotOpt)">Animate_EventSequence</a>	generate plot sequence with location of plastic hinges for each event</li><li><a href="../Animate_ResponseHistory" class="code" title="Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)">Animate_ResponseHistory</a>	interactive or recorded animation of response history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->