
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="../../">Plotting</a> &gt; <a href="../">Structure</a> &gt; Plot_Releases</div>

--------------------------

# `Plot_Releases`


## <a name="_name"></a>Purpose

display element releases in current window


## <a name="_synopsis"></a>Synopsis

`Plot_Releases (Model,ElemData,U,PlotOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">PLOT_RELEASES display element releases in current window
  PLOT_RELEASES (MODEL,ELEMDATA,U,PLOTOPT)
  the function displays in the current window internal force releases
  for the elements of the structural model in data structure MODEL;
  flexural releases are inserted for truss elements; for frame elements
  releases are inserted according to entries in the field Release of ELEMDATA
  the releases are displayed in the undeformed or deformed configuration (chords only)
  depending on the presence of the input argument U; 
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  PLOTOPT has the following fields:
    MAGF : magnification factor for deformed configuration   (default=10)
    HngSF: scale factor for size of hinge symbol             (default = 1)
    HOfSF: factor for hinge symbol offset from element end   (default = 1)
    AHClr: display color of    axial releases                (default = light gray)
    FHClr: display color of flexural releases                (default = white)</pre>
<!-- <div class="fragment"><pre class="comment">PLOT_RELEASES display element releases in current window
  PLOT_RELEASES (MODEL,ELEMDATA,U,PLOTOPT)
  the function displays in the current window internal force releases
  for the elements of the structural model in data structure MODEL;
  flexural releases are inserted for truss elements; for frame elements
  releases are inserted according to entries in the field Release of ELEMDATA
  the releases are displayed in the undeformed or deformed configuration (chords only)
  depending on the presence of the input argument U; 
  PLOTOPT is an optional data structure controlling the display;
  in its absense the function plots the model with default values;
  PLOTOPT has the following fields:
    MAGF : magnification factor for deformed configuration   (default=10)
    HngSF: scale factor for size of hinge symbol             (default = 1)
    HOfSF: factor for hinge symbol offset from element end   (default = 1)
    AHClr: display color of    axial releases                (default = light gray)
    FHClr: display color of flexural releases                (default = white)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
<li><a href="../../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li><li><a href="../Get_ModelScale" class="code" title="[ModSc,maxL,minL] = Get_ModelScale (Model,Ratio)">Get_ModelScale</a>	determines maximum and minimum element length in Model</li></ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->