---
title: Structure
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../../index.md"><img alt="<" border="0" src="../../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Structure`&nbsp;<img alt=">" border="0" src="../../../right.png"></a></td></tr></table> -->

# Structure

<table>
<tr><td><a href="Animate_EventSequence">Animate_EventSequence</a></td><td>generate plot sequence with location of plastic hinges for each event </td></tr><tr><td><a href="Animate_ResponseHistory">Animate_ResponseHistory</a></td><td>interactive or recorded animation of response history </td></tr><tr><td><a href="Get_HngPos4DefoElem">Get_HngPos4DefoElem</a></td><td>determine axial and flexural hinge position for deformed element </td></tr><tr><td><a href="Get_ModelScale">Get_ModelScale</a></td><td>determines maximum and minimum element length in Model </td></tr><tr><td><a href="Label_Model">Label_Model</a></td><td>displays element and node numbers and global axes in the current window </td></tr><tr><td><a href="Plot_BounCond">Plot_BounCond</a></td><td>plots symbols for boundary conditions of structural model </td></tr><tr><td><a href="Plot_DeformedStructure">Plot_DeformedStructure</a></td><td>plot deformed shape of the structure </td></tr><tr><td><a href="Plot_DeformedSurface">Plot_DeformedSurface</a></td><td>plots the deformed surface of 3d plate and shell models </td></tr><tr><td><a href="Plot_ElemLoading">Plot_ElemLoading</a></td><td>display element loading in current window </td></tr><tr><td><a href="Plot_Hinge4Elem">Plot_Hinge4Elem</a></td><td>plot releases or plastic hinges for truss or frame element </td></tr><tr><td><a href="Plot_Model">Plot_Model</a></td><td>plots the original or deformed geometry of the structural model </td></tr><tr><td><a href="Plot_NodalForces">Plot_NodalForces</a></td><td>display nodal forces in current window </td></tr><tr><td><a href="Plot_OpenPlasticHinges">Plot_OpenPlasticHinges</a></td><td>display plastic hinge locations in original or deformed configuration </td></tr><tr><td><a href="Plot_PlasticHinges">Plot_PlasticHinges</a></td><td>display plastic hinge locations in current window </td></tr><tr><td><a href="Plot_Releases">Plot_Releases</a></td><td>display element releases in current window </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../../matlab_logo.png" alt="icon name" class="icon">Old Versions</li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->