
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; Tripartite_Plot</div>

--------------------------

# `Tripartite_Plot`


## <a name="_name"></a>Purpose

% THIS SHOULD MAKE A TRI-PARTITE PLOT


## <a name="_synopsis"></a>Synopsis

`Tripartite_Plot`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">% THIS SHOULD MAKE A TRI-PARTITE PLOT
%  IF I DID EVERYTHING CORRECTLY</pre>
<!-- <div class="fragment"><pre class="comment">% THIS SHOULD MAKE A TRI-PARTITE PLOT
%  IF I DID EVERYTHING CORRECTLY</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../Create_Window" class="code" title="FigH = Create_Window (dx,dy)">Create_Window</a>	creates new window with given dimensions</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->