
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">Plotting</a> &gt; elNodCON</div>

--------------------------

# `elNodCON`


## <a name="_name"></a>Purpose

generates a connectivity index array for each type of element


## <a name="_synopsis"></a>Synopsis

`indx = elNodCON (ndm,nodix,ElemName)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ELNODCON generates a connectivity index array for each type of element
  INDX = ELNODCON(NDM,NODIX,ELEMNAME)
  the function generates the connectivity index array INDX for the element of dimension NDM
  and type specified in the character variable ELEMNAME;
  NODIX is a row vector with the sequence of node connectivity for plotting</pre>
<!-- <div class="fragment"><pre class="comment">ELNODCON generates a connectivity index array for each type of element
  INDX = ELNODCON(NDM,NODIX,ELEMNAME)
  the function generates the connectivity index array INDX for the element of dimension NDM
  and type specified in the character variable ELEMNAME;
  NODIX is a row vector with the sequence of node connectivity for plotting</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/Plotting/Elements/Plot_IPStressField" class="code" title="FldNd = Plot_IPStressField (Model,U,Post,Type,Comp,PlotOpt)">Plot_IPStressField</a>	plots stress field for all elements in the Model</li><li><a href="../../../Utilities/Plotting/Elements/Plot_StressField" class="code" title="Plot_StressField (Model,U,Plot,Type,Comp,PlotOpt)">Plot_StressField</a>	plots stress field for all elements in the Model</li><li><a href="../../../Utilities/Plotting/Structure/Plot_DeformedSurface" class="code" title="Plot_DeformedSurface (Model,U,MPlOpt)">Plot_DeformedSurface</a>	plots the deformed surface of 3d plate and shell models</li><li><a href="../../../Utilities/Plotting/Structure/Plot_Model" class="code" title="Plot_Model (Model,U,MPlOpt)">Plot_Model</a>	plots the original or deformed geometry of the structural model</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->