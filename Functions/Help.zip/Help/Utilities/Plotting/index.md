---
title: Plotting
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `Plotting`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# Plotting

<table>
<tr><td><a href="Create_TickLabels">Create_TickLabels</a></td><td>creates cell array of tick labels with custom label skipping </td></tr><tr><td><a href="Create_Window">Create_Window</a></td><td>creates new window with given dimensions </td></tr><tr><td><a href="Draw_3dAxisCross">Draw_3dAxisCross</a></td><td>draw cross through the axes origin of the x-y-z data </td></tr><tr><td><a href="Draw_Arrow">Draw_Arrow</a></td><td>draws 2d or 3d arrow </td></tr><tr><td><a href="Draw_AxisCross">Draw_AxisCross</a></td><td>draw cross through the axes origin of the x-y data </td></tr><tr><td><a href="Draw_Cube">Draw_Cube</a></td><td>draws cube in current window </td></tr><tr><td><a href="Plot_DispPath">Plot_DispPath</a></td><td>plots biaxial displacement path in current window </td></tr><tr><td><a href="Plot_EQRecord">Plot_EQRecord</a></td><td>% script for processing ground motion records </td></tr><tr><td><a href="Plot_LoadHistory">Plot_LoadHistory</a></td><td>plots uniaxial or biaxial displacement and axial force history in current window </td></tr><tr><td><a href="Plot_SolutionHistory">Plot_SolutionHistory</a></td><td>plots force-displacent pairs during iterative incremental solution </td></tr><tr><td><a href="Plot_StoryDistr">Plot_StoryDistr</a></td><td>plots all columns of array XP against the row index </td></tr><tr><td><a href="Plot_XYData">Plot_XYData</a></td><td>plots one or more pairs of X and Y array columns </td></tr><tr><td><a href="Plot_XYData_Mark">Plot_XYData_Mark</a></td><td>plots one or more pairs of X and Y array columns </td></tr><tr><td><a href="RshpData4MultColorPlot">RshpData4MultColorPlot</a></td><td>reshapes column vectors x and y to arrays for multi-color plotting </td></tr><tr><td><a href="Tripartite_Plot">Tripartite_Plot</a></td><td>% THIS SHOULD MAKE A TRI-PARTITE PLOT </td></tr><tr><td><a href="elNodCON">elNodCON</a></td><td>generates a connectivity index array for each type of element </td></tr></table>


<h2>Sub directories</h2>
<ul>
<li><img src="../../matlab_logo.png" alt="icon name" class="icon">Auxiliary</li><li><img src="../../matlab_logo.png" alt="icon name" class="icon">Development</li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Elements">Elements</a></li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Sections">Sections</a></li><li><img src="../../matlab_logo.png" alt="icon name" class="icon"><a href="Structure">Structure</a></li></ul>


<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->