
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Add_OpenPHIndx2Post</div>

--------------------------

# `Add_OpenPHIndx2Post`


## <a name="_name"></a>Purpose

add index to POST for open plastic hinges in elements


## <a name="_synopsis"></a>Synopsis

`Post = Add_OpenPHIndx2Post (Model,Post)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">ADD_OPENPHINDX2POST add index to POST for open plastic hinges in elements
  POST = ADD_OPENPHINDX2POST (MODEL,POST)
  the function adds the field PEi under POST(t).Elem{m} for the open plastic hinges in
  element m at time step t; the data structure POST contains the complete response of
  the structural model in the data structure MODEL</pre>
<!-- <div class="fragment"><pre class="comment">ADD_OPENPHINDX2POST add index to POST for open plastic hinges in elements
  POST = ADD_OPENPHINDX2POST (MODEL,POST)
  the function adds the field PEi under POST(t).Elem{m} for the open plastic hinges in
  element m at time step t; the data structure POST contains the complete response of
  the structural model in the data structure MODEL</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../Geometry/ElmLenOr" class="code" title="[L,dcx] = ElmLenOr (xyz)">ElmLenOr</a>	element length and x-axis orientation (direction cosines)</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/Plotting/Structure/Animate_ResponseHistory" class="code" title="Animate_ResponseHistory (Model,ElemData,Post,PlotOpt)">Animate_ResponseHistory</a>	interactive or recorded animation of response history</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->