
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Complete_QV</div>

--------------------------

# `Complete_QV`


## <a name="_name"></a>Purpose

complete basic force QIN and element deformation vector VE with values at releases


## <a name="_synopsis"></a>Synopsis

`[Q,Ve] = Complete_QV (Model,ElemData,Qin)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">COMPLETE_QV complete basic force QIN and element deformation vector VE with values at releases 
  [Q,VE] = COMPLETE_QV (MODEL,ELEMDATA,QIN)
  the function completes the basic force and element deformation vectors, Q and VE, resp.
  with the values at releases for the elements of the structural model in data structure MODEL;
  the location of element releases is specified in field RELEASE of cell array ELEMDATA;
  QIN is the vector of basic forces without the zero values at releases</pre>
<!-- <div class="fragment"><pre class="comment">COMPLETE_QV complete basic force QIN and element deformation vector VE with values at releases 
  [Q,VE] = COMPLETE_QV (MODEL,ELEMDATA,QIN)
  the function completes the basic force and element deformation vectors, Q and VE, resp.
  with the values at releases for the elements of the structural model in data structure MODEL;
  the location of element releases is specified in field RELEASE of cell array ELEMDATA;
  QIN is the vector of basic forces without the zero values at releases</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Fs_matrix" class="code" title="Fs = Fs_matrix (Model,ElemData,Roption)">Fs_matrix</a>	block diagonal matrix of element flexibity matrices for structural model</li><li><a href="../../../General/V0_vector" class="code" title="V0 = V0_vector (Model,ElemData,Roption)">V0_vector</a>	initial element deformation vector for the structural model</li><li><a href="../../../Utilities/General/H_index" class="code" title="iced = H_index (Model,ElemData)">H_index</a>	cell array of indices into structure arrays for continuous element deformations</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Solution_Library/Scripts/S_DisplMethod" class="code" title="">S_DisplMethod</a>	script for displacement method of structural analysis</li><li><a href="../../../Solution_Library/Scripts/S_DisplMethodwUd" class="code" title="">S_DisplMethodwUd</a>	script for displacement method of structural analysis including support displacements</li><li><a href="../../../Solution_Library/Scripts/S_ForceMethod" class="code" title="">S_ForceMethod</a>	script for force method of structural analysis</li><li><a href="../../../Solution_Library/Scripts/S_GeneralForceMethod" class="code" title="">S_GeneralForceMethod</a>	script for force method of structural analysis using pseudo-inverse and null space of equilibrium matrix Bf</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->