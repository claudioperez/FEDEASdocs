
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Create_NMInterDiagram</div>

--------------------------

# `Create_NMInterDiagram`


## <a name="_name"></a>Purpose

generates the N-Mz interaction diagram of a section


## <a name="_synopsis"></a>Synopsis

`[N,M] = Create_NMInterDiagram (Method,SecType,IntOpt)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">CREATE_NMINTERDIAGRAM generates the N-Mz interaction diagram of a section
  [N,M] = CREATE_NMINTERDIAGRAM (METHOD,SECTYPE,INTOPT)
  the function generates the pairs of normalized axial force N/Np and bending moment M/Mp
  for the normal force N - bending moment M interaction diagram of the section SECTYPE;
  this version supports only rectangular sections and wide flange steel profiles, 
  as specified in the character variable SECTYPE (equal to 'Rect' or Wxxxxx);
  the character variable METHOD is either equal to 'exact' for the analytical solution or
  'num' for the numerical determination of the N-M interaction pairs;
  in the latter case the optional argument INTOPT has the following fields:
      .IntTyp = for quadrature scheme (default = 'Midpoint' for midpoint integration rule);
      .nIP    = no of integration points for rectangular section (default = 10)
      .nIP_fl = no of integration points for flange of W-section (default =  2)
      .nIP_wb = no of integration points for    web of W-section (default =  8)</pre>
<!-- <div class="fragment"><pre class="comment">CREATE_NMINTERDIAGRAM generates the N-Mz interaction diagram of a section
  [N,M] = CREATE_NMINTERDIAGRAM (METHOD,SECTYPE,INTOPT)
  the function generates the pairs of normalized axial force N/Np and bending moment M/Mp
  for the normal force N - bending moment M interaction diagram of the section SECTYPE;
  this version supports only rectangular sections and wide flange steel profiles, 
  as specified in the character variable SECTYPE (equal to 'Rect' or Wxxxxx);
  the character variable METHOD is either equal to 'exact' for the analytical solution or
  'num' for the numerical determination of the N-M interaction pairs;
  in the latter case the optional argument INTOPT has the following fields:
      .IntTyp = for quadrature scheme (default = 'Midpoint' for midpoint integration rule);
      .nIP    = no of integration points for rectangular section (default = 10)
      .nIP_fl = no of integration points for flange of W-section (default =  2)
      .nIP_wb = no of integration points for    web of W-section (default =  8)</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/PreProcessing/Elements/AISC_Section" class="code" title="SecProp = AISC_Section (sect)">AISC_Section</a>	extracts section properties from AISC W-,M-,S-,HP- and HSS-section database</li><li><a href="../../../Utilities/PreProcessing/Sections/Rectangle2Layer" class="code" title="[yfib,wfib] = Rectangle2Layer (patcoor,IntTyp,nfib)">Rectangle2Layer</a>	integration points and weights for 1d-integration of a rectangle</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->