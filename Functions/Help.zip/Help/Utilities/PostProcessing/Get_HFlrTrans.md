
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Get_HFlrTrans</div>

--------------------------

# `Get_HFlrTrans`


## <a name="_name"></a>Purpose

extract the horizontal floor translations of moment resisting frame


## <a name="_synopsis"></a>Synopsis

`HFlrTrans = Get_HFlrTrans ( Model,Frame,Post )`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_HFLRTRANS extract the horizontal floor translations of moment resisting frame
  HFLRTRANS = GET_HFLRTRANS (MODEL,FRAME,POST)
  the function extracts the horizontal floor translations HFLRTRANS from the free DOF
  displacements in POST for the moment resisting frame in FRAME
  with complete structural model information in the data structure MODEL</pre>
<!-- <div class="fragment"><pre class="comment">GET_HFLRTRANS extract the horizontal floor translations of moment resisting frame
  HFLRTRANS = GET_HFLRTRANS (MODEL,FRAME,POST)
  the function extracts the horizontal floor translations HFLRTRANS from the free DOF
  displacements in POST for the moment resisting frame in FRAME
  with complete structural model information in the data structure MODEL</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->