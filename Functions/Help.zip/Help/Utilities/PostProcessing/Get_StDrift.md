
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Get_StDrift</div>

--------------------------

# `Get_StDrift`


## <a name="_name"></a>Purpose

determine the horizontal story drifts for MR frame


## <a name="_synopsis"></a>Synopsis

`StDrift = Get_StDrift ( Model,Frame,Post,UBase )`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_STDRIFT determine the horizontal story drifts for MR frame
  STDRIFT = GET_STDRIFT (MODEL,FRAME,POST,UBASE)
  the function determines the horizontal story drifts STDRIFT from the free DOF
  displacements in POST for the moment resisting frame in FRAME
  with complete structural model information in the data structure MODEL;
  POST is either a data structure with complete response information at a specific time step
  or a numeric array (nDOF,nstep) with the free DOF displacement history;
  UBASE is an optional numeric vector with the base displacement history</pre>
<!-- <div class="fragment"><pre class="comment">GET_STDRIFT determine the horizontal story drifts for MR frame
  STDRIFT = GET_STDRIFT (MODEL,FRAME,POST,UBASE)
  the function determines the horizontal story drifts STDRIFT from the free DOF
  displacements in POST for the moment resisting frame in FRAME
  with complete structural model information in the data structure MODEL;
  POST is either a data structure with complete response information at a specific time step
  or a numeric array (nDOF,nstep) with the free DOF displacement history;
  UBASE is an optional numeric vector with the base displacement history</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->