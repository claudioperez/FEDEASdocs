
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Get_StShear</div>

--------------------------

# `Get_StShear`


## <a name="_name"></a>Purpose

determine the story shears for moment resisting frame


## <a name="_synopsis"></a>Synopsis

`StShear = Get_StShear (Model,ElemData,Frame,Post,GravCol)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_STSHEAR determine the story shears for moment resisting frame
  STSHEAR = GET_STSHEAR (MODEL,ELEMDATA,FRAME,POST,GRAVCOL)
  the function determines the story shears STSHEAR for the moment resisting frame in FRAME
  from the response variables in POST; if GRAVCOL is true, the story shear includes
  the tranvserse forces in gravity columns due to the P-DELTA effect;
  the data structure MODEL provides complete information about the structural model
  and the cell array ELEMDATA contains element property information</pre>
<!-- <div class="fragment"><pre class="comment">GET_STSHEAR determine the story shears for moment resisting frame
  STSHEAR = GET_STSHEAR (MODEL,ELEMDATA,FRAME,POST,GRAVCOL)
  the function determines the story shears STSHEAR for the moment resisting frame in FRAME
  from the response variables in POST; if GRAVCOL is true, the story shear includes
  the tranvserse forces in gravity columns due to the P-DELTA effect;
  the data structure MODEL provides complete information about the structural model
  and the cell array ELEMDATA contains element property information</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/Localize" class="code" title="[xyz,id] = Localize (Model,el)">Localize</a>	returns the node coordinates and id array of element</li><li><a href="../../../Geometry/GeomTran_2dFrm" class="code" title="[ag,bg,ab,v,Dv,DDv] = GeomTran_2dFrm (option,xyz,GeomData,u,Du,DDu)">GeomTran_2dFrm</a>	kinematic matrices and deformations for a 2-node 2d frame element</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->