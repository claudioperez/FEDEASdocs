
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Get_StShearPD</div>

--------------------------

# `Get_StShearPD`


## <a name="_name"></a>Purpose

determine the story shears for MR frame including P-DELTA effect in gravity column


## <a name="_synopsis"></a>Synopsis

` StShearPD = Get_StShearPD (Model,ElemData,Frame,Post,GravCol)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_STSHEAR determine the story shears for MR frame including P-DELTA effect in gravity column
  the function determines the story shears for the moment resisting frame in FRAME
  from the element response in POST under inclusion of the tranvserse forces in
  gravity columns due to the P-DELTA effect
  MODEL carries the DOF numbering in field;
  ELEMDATA is currently not used</pre>
<!-- <div class="fragment"><pre class="comment">GET_STSHEAR determine the story shears for MR frame including P-DELTA effect in gravity column
  the function determines the story shears for the moment resisting frame in FRAME
  from the element response in POST under inclusion of the tranvserse forces in
  gravity columns due to the P-DELTA effect
  MODEL carries the DOF numbering in field;
  ELEMDATA is currently not used</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->