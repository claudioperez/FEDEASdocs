
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Get_Veps</div>

--------------------------

# `Get_Veps`


## <a name="_name"></a>Purpose

determine the elastic deformations from the displacements and plastic deformations


## <a name="_synopsis"></a>Synopsis

` Veps = Get_Veps (Model,Uf,Vpl)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">GET_VEPS determine the elastic deformations from the displacements and plastic deformations
  VEPS = GET_VEPS (MODELm,UF,VPL)
  the function determines the elastic element deformations VEPS from the free DOF
  displacements in UF and the plastic element deformations in VPL;
  the data structure MODEL provides information about the structural model</pre>
<!-- <div class="fragment"><pre class="comment">GET_VEPS determine the elastic deformations from the displacements and plastic deformations
  VEPS = GET_VEPS (MODELm,UF,VPL)
  the function determines the elastic element deformations VEPS from the free DOF
  displacements in UF and the plastic element deformations in VPL;
  the data structure MODEL provides information about the structural model</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../General/A_matrix" class="code" title="A = A_matrix (Model)">A_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li><li><a href="../../../General/Aj_matrix" class="code" title="Aj = Aj_matrix (Model)">Aj_matrix</a>	kinematic matrix of structural model with 2d/3d truss and 2d frame elements</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->