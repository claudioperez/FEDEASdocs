
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Post2Q</div>

--------------------------

# `Post2Q`


## <a name="_name"></a>Purpose

convert basic element forces in POST into vector Q for all elements


## <a name="_synopsis"></a>Synopsis

`Q = Post2Q (Post)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">POST2Q convert basic element forces in POST into vector Q for all elements    
  Q = POST2Q (POST)
  the function converts the basic element forces q in field Elem of POST
  to a single vector Q for all basic element forces of the structure</pre>
<!-- <div class="fragment"><pre class="comment">POST2Q convert basic element forces in POST into vector Q for all elements    
  Q = POST2Q (POST)
  the function converts the basic element forces q in field Elem of POST
  to a single vector Q for all basic element forces of the structure</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->