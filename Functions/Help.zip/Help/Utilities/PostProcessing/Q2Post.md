
<a name="_top"></a>
<div>
<!-- <a href="../../index.md">Home</a> &gt; -->
 <a href="../">PostProcessing</a> &gt; Q2Post</div>

--------------------------

# `Q2Post`


## <a name="_name"></a>Purpose

converts the vector of basic forces Q to cell array Post.Elem{}


## <a name="_synopsis"></a>Synopsis

`Post = Q2Post (Model,Q)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">Q2POST converts the vector of basic forces Q to cell array Post.Elem{}
  POST = Q2POST(MODEL,Q)
  the function converts the basic force values in vector Q to
  the data structure POST consisting of the field Elem{el}
  for each el of the structural model in data structure MODEL
  which, in turn, contains the field Elem{el}.q with the basic forces
  of the particular element; the function uses information
  about missing basic forces in Q based on the field Model.Qmis;
  any missing basic forces are set to zero in Elem{el}.q</pre>
<!-- <div class="fragment"><pre class="comment">Q2POST converts the vector of basic forces Q to cell array Post.Elem{}
  POST = Q2POST(MODEL,Q)
  the function converts the basic force values in vector Q to
  the data structure POST consisting of the field Elem{el}
  for each el of the structural model in data structure MODEL
  which, in turn, contains the field Elem{el}.q with the basic forces
  of the particular element; the function uses information
  about missing basic forces in Q based on the field Model.Qmis;
  any missing basic forces are set to zero in Elem{el}.q</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/General/D_index" class="code" title="ied = D_index (Model)">D_index</a>	cell array of indices into structure arrays for non-zero element deformations</li></ul>
This function is called by:
<ul style="list-style-image:url(../../matlabicon.gif)">
<li><a href="../../../Utilities/Plotting/Elements/Label_2dMoments" class="code" title="Label_2dMoments (Model,Post,ElemList,Digit,Units)">Label_2dMoments</a>	label end moment values for 2d frame elements in current window</li><li><a href="../../../Utilities/Plotting/Elements/Label_AxialForces" class="code" title="Label_AxialForces (Model,Post,ElemList,Digit,Units)">Label_AxialForces</a>	label axial force values in current window</li><li><a href="../../../Utilities/Plotting/Elements/Plot_2dCurvDistr" class="code" title="Plot_2dCurvDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dCurvDistr</a>	plot curvature distribution of 2d linear elastic frame elements</li><li><a href="../../../Utilities/Plotting/Elements/Plot_2dMomntDistr" class="code" title="Plot_2dMomntDistr (Model,ElemData,Post,ElemList,UserScale)">Plot_2dMomntDistr</a>	plots moment distribution for 2d frame elements in current window</li><li><a href="../../../Utilities/Plotting/Elements/Plot_AxialForces" class="code" title="Plot_AxialForces (Model,Post,ElemList,UserScale)">Plot_AxialForces</a>	plot axial forces in current window</li><li><a href="../../../Utilities/Plotting/Structure/Plot_PlasticHinges" class="code" title="Plot_PlasticHinges (Model,ElemData,U,Post,PlotOpt)">Plot_PlasticHinges</a>	display plastic hinge locations in current window</li></ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->