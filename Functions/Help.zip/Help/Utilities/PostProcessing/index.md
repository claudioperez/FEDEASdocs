---
title: PostProcessing
...


<!-- <a name="_top"></a>
<table width="100%"><tr><td align="left"><a href="../../index.md"><img alt="<" border="0" src="../../left.png">&nbsp;Master index</a></td>
<td align="right"><a href="index.md">Index for `PostProcessing`&nbsp;<img alt=">" border="0" src="../../right.png"></a></td></tr></table> -->

# PostProcessing

<table>
<tr><td><a href="Add_OpenPHIndx2Post">Add_OpenPHIndx2Post</a></td><td>add index to POST for open plastic hinges in elements </td></tr><tr><td><a href="Complete_QV">Complete_QV</a></td><td>complete basic force QIN and element deformation vector VE with values at releases </td></tr><tr><td><a href="Create_NMInterDiagram">Create_NMInterDiagram</a></td><td>generates the N-Mz interaction diagram of a section </td></tr><tr><td><a href="Get_HFlrTrans">Get_HFlrTrans</a></td><td>extract the horizontal floor translations of moment resisting frame </td></tr><tr><td><a href="Get_StDrift">Get_StDrift</a></td><td>determine the horizontal story drifts for MR frame </td></tr><tr><td><a href="Get_StShear">Get_StShear</a></td><td>determine the story shears for moment resisting frame </td></tr><tr><td><a href="Get_StShearPD">Get_StShearPD</a></td><td>determine the story shears for MR frame including P-DELTA effect in gravity column </td></tr><tr><td><a href="Get_Veps">Get_Veps</a></td><td>determine the elastic deformations from the displacements and plastic deformations </td></tr><tr><td><a href="Post2Q">Post2Q</a></td><td>convert basic element forces in POST into vector Q for all elements </td></tr><tr><td><a href="Q2Post">Q2Post</a></td><td>converts the vector of basic forces Q to cell array Post.Elem{} </td></tr></table>





<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2005</address> -->