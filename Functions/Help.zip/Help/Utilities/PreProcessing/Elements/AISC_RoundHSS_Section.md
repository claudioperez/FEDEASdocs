
<a name="_top"></a>
<div>
<!-- <a href="../../../index.md">Home</a> &gt; -->
 <a href="#">PreProcessing</a> &gt; <a href="../">Elements</a> &gt; AISC_RoundHSS_Section</div>

--------------------------

# `AISC_RoundHSS_Section`


## <a name="_name"></a>Purpose

extracts section properties from AISC round HSS section database


## <a name="_synopsis"></a>Synopsis

`SecProp = AISC_RoundHSS_Section (sect)`{.matlab} 

## <a name="_description"></a>Description

<pre class="comment">AISC_ROUNDHSS_SECTION extracts section properties from AISC round HSS section database
  SECPROP = AISC_ROUNDHSS_SECTION (SECT)
  the function extracts the following properties from the AISC round HSS database
  for the section with AISC Manual Label in character array SECT:
  W, A, d, t, Ix, Zx, Sx, rx, Iy, Zy, Sy, ry, J, C
  THE UNITS FOR THESE PROPERTIES ARE IN, IN2, IN3 and IN4
  The structure SECPROP contains the properties in fields with the same name
  Example: SecData = AISC_RoundHSS_Section ('HSS20x0.500');</pre>
<!-- <div class="fragment"><pre class="comment">AISC_ROUNDHSS_SECTION extracts section properties from AISC round HSS section database
  SECPROP = AISC_ROUNDHSS_SECTION (SECT)
  the function extracts the following properties from the AISC round HSS database
  for the section with AISC Manual Label in character array SECT:
  W, A, d, t, Ix, Zx, Sx, rx, Iy, Zy, Sy, ry, J, C
  THE UNITS FOR THESE PROPERTIES ARE IN, IN2, IN3 and IN4
  The structure SECPROP contains the properties in fields with the same name
  Example: SecData = AISC_RoundHSS_Section ('HSS20x0.500');</pre></div> -->

<!-- crossreference -->
## <a name="_cross"></a>Cross-Reference Information

This function calls:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
This function is called by:
<ul style="list-style-image:url(../../../matlabicon.gif)">
</ul>
<!-- crossreference -->




<!-- <hr><address>Generated on _DATE_ by <strong><a href="http://www.artefact.tk/software/matlab/m2html/" title="Matlab Documentation in HTML">m2md</a></strong> &copy; 2021</address> -->